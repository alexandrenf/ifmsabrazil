const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/MarkdownPage-Bo-GwOid.js","assets/react-DaPl5ws4.js","assets/@babel-CNkBngnk.js","assets/markdown-to-jsx-CXBEPAoT.js","assets/axios-B4uVmeYG.js","assets/prismjs-DEnDlMkx.js","assets/@mui-D3p2DSY1.js","assets/clsx-B-dksMZM.js","assets/react-is-DcfIKM1A.js","assets/@emotion-Clztb9Oy.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/react-transition-group-cLDJx4Bm.js","assets/react-dom-CWF6clnO.js","assets/scheduler-CzFDRTuY.js","assets/react-router-B_WJkAv4.js","assets/@remix-run-B-RBrVrq.js","assets/react-router-dom-BFBG7k2k.js","assets/styled-components-BD7m8TR7.js","assets/tslib-wbdO-F7s.js","assets/@fortawesome-BOOXKGIM.js","assets/prop-types-15ULSoSZ.js","assets/react-icons-BQxfTaxZ.js","assets/date-fns-X50TK9oK.js","assets/codeStyles-vPv1o2UF.css","assets/GeradorLink-BvzLFz8y.js","assets/Arquivos-ClxVOag6.js","assets/BlogPostListItem-Ch7n76Qf.js","assets/Estrutura-BLoeN7zn.js","assets/react-multi-carousel-BYLf87Xc.js","assets/react-multi-carousel-C0HCKJ4u.css","assets/react-simple-maps-s3X3tYH8.js","assets/topojson-client-DzWSY_RA.js","assets/d3-geo-eEO7UCrt.js","assets/d3-array-BweefaKS.js","assets/MarkdownContent-Bk-obxsC.js","assets/Filiacao-DLnUjdRw.js","assets/papaparse-RALpPLFu.js","assets/NotFound-BVTHShL6.js","assets/Noticias-Dqis71Dh.js","assets/Institucional-ClzrWF-O.js","assets/AcoesETematicas-CPWetyls.js","assets/SocialPrograms-BFp7pgfq.js","assets/Eixos-B2VK104H.js","assets/Eventos-B4WlElmz.js","assets/Regulamento-B2PUvoij.js","assets/IntercambioNacional--hY0w_YM.js"])))=>i.map(i=>d[i]);
import{r as c,j as n,a as ee}from"./react-DaPl5ws4.js";import{c as te}from"./react-dom-CWF6clnO.js";import{L as m,B as oe}from"./react-router-dom-BFBG7k2k.js";import{p as r,h as ie,f as Vn}from"./styled-components-BD7m8TR7.js";import{l as D,f as Gn,a as Un,F as k,b as re,c as se,d as ae,e as le,g as ce,h as Qn,i as Wn,j as Yn,k as Xn,m as Jn,n as Kn,o as Zn}from"./@fortawesome-BOOXKGIM.js";import{j as de,a as me,G as pe}from"./@emotion-Clztb9Oy.js";import{s as E,I as xe,C as H,G as S,T as b,a as he,b as ue,c as ge,d as fe,e as be,f as je,g as ve}from"./@mui-D3p2DSY1.js";import{a as we}from"./axios-B4uVmeYG.js";import{F as ye,a as V,b as _e,c as ke}from"./react-icons-BQxfTaxZ.js";import{i as Ce,p as G}from"./date-fns-X50TK9oK.js";import{d as Oe,e as g}from"./react-router-B_WJkAv4.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./@remix-run-B-RBrVrq.js";import"./tslib-wbdO-F7s.js";import"./prop-types-15ULSoSZ.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))l(e);new MutationObserver(e=>{for(const s of e)if(s.type==="childList")for(const d of s.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&l(d)}).observe(document,{childList:!0,subtree:!0});function a(e){const s={};return e.integrity&&(s.integrity=e.integrity),e.referrerPolicy&&(s.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?s.credentials="include":e.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function l(e){if(e.ep)return;e.ep=!0;const s=a(e);fetch(e.href,s)}})();const Se="modulepreload",Ee=function(i){return"/"+i},U={},f=function(t,a,l){let e=Promise.resolve();if(a&&a.length>0){document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),d=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));e=Promise.all(a.map(p=>{if(p=Ee(p),p in U)return;U[p]=!0;const h=p.endsWith(".css"),v=h?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${p}"]${v}`))return;const u=document.createElement("link");if(u.rel=h?"stylesheet":Se,h||(u.as="script",u.crossOrigin=""),u.href=p,d&&u.setAttribute("nonce",d),document.head.appendChild(u),h)return new Promise((w,j)=>{u.addEventListener("load",w),u.addEventListener("error",()=>j(new Error(`Unable to preload CSS for ${p}`)))})}))}return e.then(()=>t()).catch(s=>{const d=new Event("vite:preloadError",{cancelable:!0});if(d.payload=s,window.dispatchEvent(d),!d.defaultPrevented)throw s})};function o(i,t){return t||(t=i.slice(0)),Object.freeze(Object.defineProperties(i,{raw:{value:Object.freeze(t)}}))}const ze="/assets/logo-fundo-azul-CVrwm-yG.png";var Q,W,Y,X,J,K,Z,nn,en,tn,on,rn;D.add(Gn.faBars,Un.faTimes);const Me=r.nav(Q||(Q=o([`
  background: #00508c;
  padding: 0.5rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  z-index: 10;
`]))),Ie=r.img(W||(W=o([`
  height: 50px;
`]))),Pe=r.div(Y||(Y=o([`
  display: flex;
  align-items: center;

  @media screen and (max-width: 1040px) {
    display: none;
  }
`]))),O=r.div(X||(X=o([`
  position: relative;
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 0 1rem;
  cursor: pointer;
  transition: color 0.3s;
  white-space: nowrap;

  &:hover {
    color: #fac800;
  }

  @media screen and (max-width: 1200px) {
    font-size: 1rem;
  }

  & > a {
    color: inherit;
    text-decoration: none;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`]))),P=r.div(J||(J=o([`
  display: `,`;
  position: absolute;
  top: 100%;
  left: 0;
  background: #00508c;
  padding: 1rem;
  border-radius: 5px;
  z-index: 20;

  & a {
    display: block;
    color: white;
    margin: 0.5rem 0;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`])),i=>{let{$isOpen:t}=i;return t?"block":"none"}),Ae=r(m)(K||(K=o([`
  background: #28a745;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  margin-left: 1rem;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #218838;
  }
`]))),Fe=r.div(Z||(Z=o([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: block;
    color: white;
    font-size: 1.8rem;
    cursor: pointer;
    z-index: 11; /* Ensure it is above the mobile menu */
  }
`]))),Le=r.div(nn||(nn=o([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: `,`;
    flex-direction: column;
    align-items: center;
    position: absolute;
    top: 70px;
    left: 0;
    width: 100%;
    background: #00508c;
    padding: 1rem 0;
    z-index: 9;
  }
`])),i=>{let{$isOpen:t}=i;return t?"flex":"none"}),A=r.div(en||(en=o([`
  width: 100%;
  text-align: center;
`]))),_=r(m)(tn||(tn=o([`
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 1rem 0;
  cursor: pointer;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),x=r(m)(on||(on=o([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),T=r.div(rn||(rn=o([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),$e=()=>{const[i,t]=c.useState(!1),[a,l]=c.useState(""),e=()=>{i==!0&&l(""),t(!i)},s=d=>{l(a===d?"":d)};return n.jsxs(Me,{children:[n.jsx(m,{to:"/",children:n.jsx(Ie,{src:ze,alt:"Logo"})}),n.jsx(Fe,{onClick:e,children:n.jsx(k,{icon:i?Un.faTimes:Gn.faBars})}),n.jsxs(Pe,{children:[n.jsxs(O,{onMouseEnter:()=>l("quemSomos"),onMouseLeave:()=>l(""),onClick:()=>s("quemSomosMobile"),children:["Quem Somos",n.jsxs(P,{$isOpen:a==="quemSomos"||a==="quemSomosMobile",children:[n.jsx(m,{to:"/institucional",children:"Institucional"}),n.jsx(m,{to:"/estrutura",children:"Estrutura"}),n.jsx(m,{to:"/filiacao",children:"Filiação"}),n.jsx(m,{to:"/memoria",children:"Memória Institucional"})]})]}),n.jsxs(O,{onMouseEnter:()=>l("oQueFazemos"),onMouseLeave:()=>l(""),onClick:()=>s("oQueFazemosMobile"),children:["O Que Fazemos",n.jsxs(P,{$isOpen:a==="oQueFazemos"||a==="oQueFazemosMobile",children:[n.jsx(m,{to:"/eixos",children:"Eixos de Atuação"}),n.jsx(m,{to:"/acoes",children:"Ações e Temáticas"}),n.jsx(m,{to:"/eventos",children:"Eventos e Workshops"})]})]}),n.jsxs(O,{onMouseEnter:()=>l("mobilidade"),onMouseLeave:()=>l(""),onClick:()=>s("mobilidadeMobile"),children:["Intercâmbios",n.jsxs(P,{$isOpen:a==="mobilidade"||a==="mobilidadeMobile",children:[n.jsx(m,{to:"/intercambio_nacional",children:"Intercâmbios Nacionais"}),n.jsx(m,{to:"/intercambio_internacional",children:"Intercâmbios Internacionais"}),n.jsx(m,{to:"/regulamento",children:"Regulamento de Intercâmbios"}),n.jsx(m,{to:"/outras-modalidades",children:"Outras Modalidades de Intercâmbio"}),n.jsx(m,{to:"/social-programs",children:"Social Programs"})]})]}),n.jsxs(O,{onMouseEnter:()=>l("midias"),onMouseLeave:()=>l(""),onClick:()=>s("midiasMobile"),children:["Mídias e Documentos",n.jsxs(P,{$isOpen:a==="midias"||a==="midiasMobile",children:[n.jsx(m,{to:"/arquivos/ressonancia-poetica",children:"Ressonância Poética"}),n.jsx(m,{to:"/arquivos/informa-susi",children:"Informa SUSi"}),n.jsx(m,{to:"/arquivos/bms",children:"Brazilian Medical Students"}),n.jsx(m,{to:"/arquivos/relatorios",children:"Relatórios"}),n.jsx(m,{to:"/arquivos/notas-de-posicionamento",children:"Notas de Posicionamento"}),n.jsx(m,{to:"/arquivos/declaracoes-de-politica",children:"Declarações de Política"}),n.jsx(m,{to:"/arquivos/intercambio-nacional",children:"Intercâmbio Nacional"}),n.jsx(m,{to:"/arquivos/intercambio-internacional",children:"Intercâmbio Internacional"}),n.jsx(m,{to:"/arquivos/regulamento-intercambios",children:"Regulamento de Intercâmbios"})]})]}),n.jsx(O,{children:n.jsx(m,{to:"/noticias",children:"Notícias"})}),n.jsxs(O,{onMouseEnter:()=>l("membros"),onMouseLeave:()=>l(""),onClick:()=>s("membrosMobile"),children:["Membros",n.jsxs(P,{$isOpen:a==="membros"||a==="membrosMobile",children:[n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"}),n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"}),n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})]})]}),n.jsx(Ae,{to:"/filie-se",children:"FILIE-SE"})]}),n.jsxs(Le,{$isOpen:i,children:[n.jsxs(A,{children:[n.jsx(_,{onClick:()=>s("quemSomosMobile"),children:"Quem Somos"}),a==="quemSomosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/institucional",onClick:e,children:"Institucional"}),n.jsx(x,{to:"/estrutura",onClick:e,children:"Estrutura"}),n.jsx(x,{to:"/filiacao",onClick:e,children:"Filiação"}),n.jsx(x,{to:"/memoria",onClick:e,children:"Memória Institucional"})]})]}),n.jsxs(A,{children:[n.jsx(_,{onClick:()=>s("oQueFazemosMobile"),children:"O Que Fazemos"}),a==="oQueFazemosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/eixos",onClick:e,children:"Eixos de Atuação"}),n.jsx(x,{to:"/acoes",onClick:e,children:"Ações e Temáticas"}),n.jsx(x,{to:"/eventos",onClick:e,children:"Eventos e Workshops"})]})]}),n.jsxs(A,{children:[n.jsx(_,{onClick:()=>s("mobilidadeMobile"),children:"Intercâmbios"}),a==="mobilidadeMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/intercambio_nacional",onClick:e,children:"Intercâmbios Nacionais"}),n.jsx(x,{to:"/intercambio_internacional",onClick:e,children:"Intercâmbios Internacionais"}),n.jsx(x,{to:"/regulamento",onClick:e,children:"Regulamento de Intercâmbios"}),n.jsx(x,{to:"/outras-modalidades",onClick:e,children:"Outras Modalidades de Intercâmbio"}),n.jsx(x,{to:"/social-programs",onClick:e,children:"Social Programs"})]})]}),n.jsxs(A,{children:[n.jsx(_,{onClick:()=>s("midiasMobile"),children:"Mídias e Documentos"}),a==="midiasMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/arquivos/ressonancia-poetica",onClick:e,children:"Ressonância Poética"}),n.jsx(x,{to:"/arquivos/informa-susi",onClick:e,children:"Informa SUSi"}),n.jsx(x,{to:"/arquivos/bms",onClick:e,children:"Brazilian Medical Students"}),n.jsx(x,{to:"/arquivos/relatorios",onClick:e,children:"Relatórios"}),n.jsx(x,{to:"/arquivos/notas-de-posicionamento",onClick:e,children:"Notas de Posicionamento"}),n.jsx(x,{to:"/arquivos/declaracoes-de-politica",onClick:e,children:"Declarações de Política"}),n.jsx(x,{to:"/arquivos/intercambio-nacional",onClick:e,children:"Intercâmbio Nacional"}),n.jsx(x,{to:"/arquivos/intercambio-internacional",onClick:e,children:"Intercâmbio Internacional"}),n.jsx(x,{to:"/arquivos/regulamento-intercambios",onClick:e,children:"Regulamento de Intercâmbios"})]})]}),n.jsx(_,{to:"/noticias",onClick:e,children:"Notícias"}),n.jsxs(A,{children:[n.jsx(_,{onClick:()=>s("membrosMobile"),children:"Membros"}),a==="membrosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(T,{onClick:e,children:n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"})}),n.jsx(T,{onClick:e,children:n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"})}),n.jsx(T,{onClick:e,children:n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})})]})]}),n.jsx(_,{to:"/filie-se",onClick:e,children:"FILIE-SE"})]})]})};var sn;const Be=()=>de(pe,{styles:me(sn||(sn=o([`
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap");

      html,
      body,
      body1,
      #root,
      #__next {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif !important;
        background-color: #f0f0f0;
        color: rgba(0, 0, 0, 0.87);
        font-weight: 400;
        font-size: 1rem;
        line-height: 1.5;
        letter-spacing: 0.00938em;
      }

      *,
      *::before,
      *::after {
        box-sizing: inherit;
      }

      a {
        text-decoration: none;
        color: inherit;
      }

      h1,
      h6,
      h2 {
        margin: 0;
      }

      button {
        outline: none;
      }

      .carousel-container {
        max-width: 1200px;
        margin: 0 auto;
      }

      .carousel .slide {
        background: none;
      }

      /* CSS for BrazilMap component */
      .container {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: flex-start;
        width: 100%;
        margin: 0;
        padding: 20px;
        box-sizing: border-box;
      }

      .map-container {
        flex: 1;
        min-width: 300px;
        max-width: 600px;
        margin: 0 20px; /* Medium margin on the left and right sides */
      }

      .legend-container {
        display: flex;
        flex-direction: column;
        margin-left: 20px;
      }

      .legend-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
      }

      .color-box {
        width: 20px;
        height: 20px;
        margin-right: 10px;
      }

      /* Media query for mobile view */
      @media (max-width: 768px) {
        .container {
          flex-direction: column;
          align-items: center;
        }
        .map-container {
          margin: 0; /* Remove margins on mobile */
        }
        .legend-container {
          flex-direction: row;
          flex-wrap: wrap;
          justify-content: center;
          margin-left: 0;
          margin-top: 20px; /* Space between map and legend */
        }
        .legend-item {
          margin: 5px; /* Adjust margin for horizontal layout */
        }
      }
    `])))});var an;ie(an||(an=o([`
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

  body {
    font-family: 'Poppins', sans-serif;
  }
`])));D.add(re.faTwitter,se.faInstagram,ae.faMapMarkerAlt,le.faEnvelope,ce.faPhone);const Te=E("footer")({backgroundColor:"#00508C",color:"white",padding:"20px 0",textAlign:"center"}),R=E("div")({display:"flex",alignItems:"center",margin:"5px 0",justifyContent:"center","& svg":{marginRight:"10px"}}),Re=E("div")({marginTop:"10px"}),ln=E(xe)({color:"white",margin:"0 10px",fontSize:"1.5rem",transition:"color 0.3s","&:hover":{color:"#FAC800"}}),qe=()=>n.jsx(Te,{children:n.jsx(H,{maxWidth:"lg",children:n.jsxs(S,{container:!0,spacing:4,children:[n.jsxs(S,{item:!0,xs:12,md:4,children:[n.jsx(b,{variant:"h6",gutterBottom:!0,children:"Endereço"}),n.jsxs(R,{children:[n.jsx(k,{icon:"map-marker-alt"}),n.jsx(b,{variant:"body1",children:"Avenida Paulista nº 1765 - 7º Andar"})]}),n.jsx(b,{variant:"body1",children:"Boa Vista, São Paulo/SP - Brasil"})]}),n.jsxs(S,{item:!0,xs:12,md:4,children:[n.jsx(b,{variant:"h6",gutterBottom:!0,children:"Contato"}),n.jsxs(R,{children:[n.jsx(k,{icon:"envelope"}),n.jsx(b,{variant:"body1",children:"atendimento@ifmsabrazil.org"})]}),n.jsxs(R,{children:[n.jsx(k,{icon:"phone"}),n.jsx(b,{variant:"body1",children:"Tel: + 55 11 3170-3251"})]})]}),n.jsxs(S,{item:!0,xs:12,md:4,children:[n.jsx(b,{variant:"h6",gutterBottom:!0,children:"Siga-nos"}),n.jsxs(Re,{children:[n.jsx(ln,{href:"https://twitter.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(k,{icon:["fab","twitter"]})}),n.jsx(ln,{href:"https://instagram.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(k,{icon:["fab","instagram"]})})]})]})]})})}),De=E(H)({display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh"}),He=E(b)({marginTop:"16px",color:"#00508C"}),ne=()=>n.jsxs(De,{children:[n.jsx(he,{}),n.jsx(He,{variant:"h6",children:"Carregando..."})]});var cn,dn,mn,pn,xn,hn;const Ne=Vn(cn||(cn=o([`
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
`]))),Ve=Vn(dn||(dn=o([`
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.8);
  }
`]))),Ge=r.div(mn||(mn=o([`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #00508c;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  cursor: pointer;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease-in-out;
  z-index: 1000;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 46px;
    height: 46px;
  }
`]))),Ue=r.div(pn||(pn=o([`
  position: absolute;
  top: -1px;
  right: -1px;
  background-color: #00963c;
  font-weight: bold;
  color: white;
  border-radius: 50%;
  width: 16px;
  height: 16px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 10px;
`]))),Qe=r.div(xn||(xn=o([`
  position: fixed;
  bottom: 80px;
  right: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 1000;
  transition: all 0.2s ease-in-out;
  animation: `,` 0.2s forwards;

  @media (max-width: 768px) {
    bottom: 76px;
    right: 16px;
  }
`])),i=>i.isOpen?Ne:Ve),q=r.a(hn||(hn=o([`
  color: #00508c;
  text-decoration: none;
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 8px 0;
  width: 100%;
  transition: all 0.2s ease-in-out;

  &:hover {
    color: #003366;
  }

  svg {
    margin-right: 10px;
  }
`]))),We=i=>{let{showNotification:t,onAlertReopen:a}=i;const[l,e]=c.useState(!1),s=()=>{a(),d()},d=()=>{e(!l)};return n.jsxs(n.Fragment,{children:[n.jsxs(Ge,{onClick:d,children:[l?n.jsx(ye,{size:24}):n.jsx(V,{size:24}),t&&!l&&n.jsx(Ue,{children:"1"})]}),l&&n.jsxs(Qe,{isOpen:l,children:[n.jsxs(q,{href:"mailto:atendimento@ifmsabrazil.org",children:[n.jsx(V,{size:20}),"atendimento@ifmsabrazil.org"]}),n.jsxs(q,{href:"https://instagram.com/ifmsabrazil",target:"_blank",children:[n.jsx(_e,{size:20}),"@ifmsabrazil"]}),t&&n.jsxs(q,{onClick:s,children:[n.jsx(ke,{size:20}),"Ver aviso novamente"]})]})]})};var un,gn,fn,bn,jn,vn;const Ye=r.section(un||(un=o([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #FFFFFF;
  text-align: center;
`]))),Xe=r.h2(gn||(gn=o([`
  font-family: 'Poppins', sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Je=r.div(fn||(fn=o([`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
`]))),Ke=r.div(bn||(bn=o([`
  flex: 1 1 30%;
  max-width: 30%;
  display: flex;
  justify-content: center;

  @media (max-width: 991px) {
    flex: 1 1 45%;
    max-width: 45%;
  }

  @media (max-width: 600px) {
    flex: 1 1 100%;
    max-width: 100%;
  }
`]))),Ze=r.div(jn||(jn=o([`
  position: relative;
  height: auto;
  font-family: 'Poppins', sans-serif;
  color: rgba(255, 255, 255, 1);
  text-align: center;
  background-color: `,`;
  flex-grow: 1;
  width: 100%;
  align-self: stretch;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`])),i=>i.bgColor),nt=r.div(vn||(vn=o([`
  font-size: 24px;
`])));function et(){const i=[{id:1,bgColor:"rgba(0, 80, 140, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Em 26 Estados"}),n.jsx("br",{}),n.jsx("strong",{children:"+ Distrito Federal"})]})},{id:2,bgColor:"rgba(250, 200, 0, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Temos +11000"}),n.jsx("br",{}),n.jsx("strong",{children:"membros filiados"})]})},{id:3,bgColor:"rgba(0, 150, 60, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Presentes em +220"}),n.jsx("br",{}),n.jsx("strong",{children:"escolas médicas"})]})}];return n.jsxs(Ye,{children:[n.jsx(Xe,{children:"Nossa abrangência"}),n.jsx(Je,{children:i.map(t=>n.jsx(Ke,{children:n.jsx(Ze,{bgColor:t.bgColor,children:n.jsx(nt,{children:t.text})})},t.id))})]})}var wn,yn,_n,kn,Cn;D.add(Qn.faBook,Wn.faGraduationCap,Yn.faHandsHelping,Xn.faHeartbeat,Jn.faHospital,Kn.faUniversity,Zn.faSearch);const tt=r.section(wn||(wn=o([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
  text-align: center;
`]))),ot=r.h2(yn||(yn=o([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),it=r.div(_n||(_n=o([`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 20px;
  justify-content: center;

  @media (max-width: 991px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    & > :nth-child(5) {
      grid-column: span 2;
    }
  }
`]))),rt=r.div(kn||(kn=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: `,`;
  color: `,`;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
  font-family: "Poppins", sans-serif;
  text-align: center;
  border: `,`;

  &:hover {
    transform: translateY(-10px);
  }
`])),i=>i.bgColor,i=>i.color||"rgba(255, 255, 255, 1)",i=>i.border||"none"),st=r.div(Cn||(Cn=o([`
  font-size: 18px;
  margin-top: 10px;
`])));function at(){const i=[{id:1,bgColor:"rgba(182, 120, 38, 1)",text:"Representatividade estudantil",icon:Wn.faGraduationCap},{id:2,bgColor:"rgba(0, 0, 0, 1)",text:"Capacity Building",icon:Qn.faBook},{id:3,bgColor:"#FFFFFF",text:"Educação Médica",icon:Jn.faHospital,color:"#000",border:"2px solid #000"},{id:4,bgColor:"rgba(220, 0, 0, 1)",text:"Promoção de Saúde",icon:Xn.faHeartbeat},{id:5,bgColor:"rgba(0, 150, 60, 1)",text:"Humanização",icon:Yn.faHandsHelping},{id:6,bgColor:"rgba(0, 80, 140, 1)",text:"Mobilidade Estudantil",icon:Kn.faUniversity},{id:7,bgColor:"rgba(128, 128, 128, 1)",text:"Pesquisa e Extensão",icon:Zn.faSearch}];return n.jsxs(tt,{children:[n.jsx(ot,{children:"Nossos eixos de atuação"}),n.jsx(it,{children:i.map(t=>n.jsxs(rt,{bgColor:t.bgColor,color:t.color,border:t.border,children:[n.jsx(k,{icon:t.icon,size:"3x"}),n.jsx(st,{children:t.text})]},t.id))})]})}var On,Sn;const lt=r(ue)(On||(On=o([`
  display: flex;
  flex-direction: column;
  margin: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
  border-radius: 10px;

  &:hover {
    transform: translateY(-5px);
  }

  @media (min-width: 600px) {
    flex-direction: row;
  }
`]))),ct=r(ge)(Sn||(Sn=o([`
  width: 100%;
  height: auto;

  @media (min-width: 600px) {
    width: 160px !important;
    height: auto;
    object-fit: cover;
    margin-left: auto;
  }
`]))),dt=i=>{let{post:t}=i;return n.jsxs(lt,{children:[n.jsxs(fe,{style:{flex:1},children:[n.jsx(b,{component:"h2",variant:"h5",gutterBottom:!0,children:t.title}),n.jsx(b,{variant:"subtitle1",color:"text.secondary",children:t.author}),n.jsx(b,{variant:"subtitle2",color:"text.secondary",gutterBottom:!0,children:t.date?new Date(t.date).toLocaleDateString():""}),n.jsx(b,{variant:"body1",paragraph:!0,children:t.summary})]}),n.jsx(ct,{component:"img",image:t.imageLink,alt:"Blog image"})]})},mt={ç:"c",Ç:"C",á:"a",Á:"A",é:"e",É:"E",í:"i",Í:"I",ó:"o",Ó:"O",ú:"u",Ú:"U",à:"a",À:"A",ã:"a",Ã:"A",õ:"o",Õ:"O"},pt=i=>i.split("").map(t=>mt[t]||t).join(""),xt=i=>pt(i).toLowerCase().replace(/[^a-z0-9]+/g,"-");var En,zn;const ht=r.section(En||(En=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
`]))),ut=r.h2(zn||(zn=o([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),gt=i=>{let{posts:t,loading:a}=i;if(a)return n.jsx(ne,{});const l=d=>d.sort((p,h)=>h["dia-mes-ano"]-p["dia-mes-ano"]),s=function(d){let p=arguments.length>1&&arguments[1]!==void 0?arguments[1]:4;const h=l(d),v=h.filter(j=>j["forcar-pagina-inicial"]);if(v.length>=p)return v;const u=h.filter(j=>!j["forcar-pagina-inicial"]);return v.concat(u.slice(0,p-v.length))}(t);return n.jsxs(ht,{children:[n.jsx(ut,{children:"Últimas Notícias"}),n.jsx(H,{maxWidth:"lg",children:n.jsx(S,{container:!0,spacing:4,children:s.map((d,p)=>n.jsx(S,{item:!0,xs:12,sm:6,children:n.jsx(m,{to:"/arquivo/".concat(d.id,"/").concat(xt(d.title)),children:n.jsx(dt,{post:d})})},p))})})]})},ft="/assets/background-image-YkmHsWZG.webp";var Mn,In,Pn,An,Fn,Ln,$n;function bt(i){let{message:t,title:a,buttonUrl:l,buttonText:e,toggleButton:s,toggleMessage:d,onClose:p,forceOpen:h}=i;const u=(()=>{const M="".concat(t).concat(a).concat(l).concat(e).concat(s).concat(d);let y=0;for(let I=0;I<M.length;I++){const $=M.charCodeAt(I);y=(y<<5)-y+$,y|=0}return y.toString()})(),w=localStorage.getItem("alertHash"),[j,z]=c.useState(h||!w||w!==u);c.useEffect(()=>{!j&&!h&&(localStorage.setItem("alertHash",u),p&&p())},[j,u,p,h]),c.useEffect(()=>{h&&z(!0)},[h]);const L=()=>{z(!1),p&&p()};return!j&&!h?null:n.jsx(vt,{children:n.jsxs(wt,{children:[n.jsxs(yt,{onClick:L,children:[n.jsx(jt,{}),n.jsx("span",{className:"sr-only",children:"Close"})]}),n.jsxs(_t,{children:[n.jsx(kt,{children:a}),d?n.jsx(Ct,{children:t}):null,s?n.jsx(m,{to:l,target:"_blank",rel:"noopener noreferrer",children:n.jsx(Ot,{children:e})}):null]})]})})}function jt(i){return n.jsxs("svg",{...i,xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[n.jsx("path",{d:"M18 6 6 18"}),n.jsx("path",{d:"m6 6 12 12"})]})}const vt=r.div(Mn||(Mn=o([`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`]))),wt=r.div(In||(In=o([`
  background-color: hsl(142, 86%, 28%);
  padding: 2rem 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  max-width: 42rem;
  position: relative;
`]))),yt=r.button(Pn||(Pn=o([`
  position: absolute;
  top: 1rem;
  right: 1rem;
  color: hsl(356, 29%, 98%);
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 0.25rem;

  &:hover {
    color: rgba(356, 29%, 98%, 0.8);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`]))),_t=r.div(An||(An=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`]))),kt=r.h2(Fn||(Fn=o([`
  font-size: 1.875rem;
  font-weight: bold;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1rem;
`]))),Ct=r.p(Ln||(Ln=o([`
  font-size: 1.125rem;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1.5rem;
`]))),Ot=r.a($n||($n=o([`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem 1.5rem;
  border-radius: 0.25rem;
  background-color: hsl(356, 29%, 98%);
  color: hsl(142, 86%, 28%);
  font-weight: 500;
  text-decoration: none;

  &:hover {
    background-color: rgba(356, 29%, 98%, 0.9);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`])));var Bn,Tn,Rn,qn,Dn,Hn;const St=r.div(Bn||(Bn=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  overflow: hidden;
`]))),Et=r.div(Tn||(Tn=o([`
  width: 100%;
  height: 100vh;
  background-image: url(`,`);
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  text-align: center;
  padding: 20px;
  background-color: rgba(0, 0, 0, 0.5);
`])),ft),zt=r.h1(Rn||(Rn=o([`
  font-size: 3rem;
  font-weight: 700;
  padding: 0 20px;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
`]))),Mt=r.button(qn||(qn=o([`
  margin-top: 20px;
  padding: 12px 24px;
  font-size: 1rem;
  font-weight: bold;
  color: #00508c;
  background-color: #fac800;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: translateY(-3px);
    background-color: #e6b800;
    color: #004080;
  }
`]))),It=r.button(Dn||(Dn=o([`
  position: fixed;
  bottom: 20px;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: white;
  border: none;
  cursor: pointer;
  display: `,`;
  justify-content: center;
  align-items: center;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
  }

  svg {
    width: 24px;
    height: 24px;
    fill: #00508c;
  }
`])),i=>{let{show:t}=i;return t?"flex":"none"}),Pt=r.div(Hn||(Hn=o([`
  width: 100%;
  padding: 60px 20px;
  background-color: white;
  text-align: center;
  color: #333;

  h2 {
    font-size: 2rem;
    margin-bottom: 20px;
  }

  p {
    max-width: 800px;
    margin: 0 auto;
    line-height: 1.6;
  }
`]))),At=()=>{const[i,t]=c.useState([]),[a,l]=c.useState(null),[e,s]=c.useState(null),[d,p]=c.useState(!0),[h,v]=c.useState(!0),[u,w]=c.useState(!1),[j,z]=c.useState(!1),L="https://api.ifmsabrazil.org/api/blogs/recent";c.useEffect(()=>{(async()=>{try{const F=await we.get(L),{recentBlogs:B,alert:C}=F.data;t(B),C&&C.toggleDate&&Ce(new Date,{start:G(C.dateStart),end:G(C.dateEnd)})&&(l(C),s(C))}catch(F){console.error("Error fetching posts:",F)}finally{p(!1)}})()},[]);const M=()=>{const N=window.scrollY,B=window.innerHeight*.7;N<B?v(!0):v(!1)},y=()=>{window.scrollTo({top:window.innerHeight,behavior:"smooth"})};c.useEffect(()=>(window.addEventListener("scroll",M),()=>{window.removeEventListener("scroll",M)}),[]);const I=()=>{w(!0),l(null),z(!1)},$=()=>{w(!1),l(e),z(!0)};return n.jsxs(St,{children:[a&&n.jsx(bt,{toggleMessage:a.toggleMessage,message:a.message,toggleButton:a.toggleButton,buttonText:a.buttonText,buttonUrl:a.buttonUrl,title:a.title,forceOpen:j,onClose:I}),n.jsxs(Et,{children:[n.jsx(zt,{children:"Estudantes de medicina que fazem a diferença"}),n.jsx(Mt,{children:"Faça parte"}),n.jsx(It,{show:h,onClick:y,children:n.jsx("svg",{viewBox:"0 0 24 24",children:n.jsx("path",{d:"M12 16.5l-7-7 1.41-1.41L12 13.67l5.59-5.58L19 9.5l-7 7z"})})})]}),n.jsxs(Pt,{children:[n.jsx("h2",{children:"Breve Introdução"}),n.jsx("p",{children:"Fundada em 1991 como primeira associação da América Latina vinculada à International Federation of Medical Students’ Association (IFMSA), a IFMSA Brazil interliga estudantes de medicina de todo o país para fazer a diferença na sociedade e na formação médica."})]}),n.jsx(et,{}),n.jsx(at,{}),n.jsx(gt,{posts:i,loading:d}),n.jsx(We,{showNotification:u,onAlertReopen:$})]})},Ft=be({typography:{fontFamily:"Poppins, Arial, sans-serif"},components:{MuiCssBaseline:{styleOverrides:`
        @font-face {
          font-family: 'Poppins';
          font-style: normal;
          font-display: swap;
          font-weight: 400;
          src: local('Poppins'), local('Poppins-Regular'), url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap') format('woff2');
          unicodeRange: U+0000-00FF; /* Latin characters */
        }
      `}}}),Nn=c.lazy(()=>f(()=>import("./MarkdownPage-Bo-GwOid.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]))),Lt=c.lazy(()=>f(()=>import("./GeradorLink-BvzLFz8y.js"),__vite__mapDeps([24,1,2,6,7,8,9,10,11,12,13]))),$t=c.lazy(()=>f(()=>import("./Arquivos-ClxVOag6.js"),__vite__mapDeps([25,1,2,17,18,9,10,4,26,19,20,6,7,8,11,12,13,14,15,16,21,22]))),Bt=c.lazy(()=>f(()=>import("./Estrutura-BLoeN7zn.js"),__vite__mapDeps([27,1,2,4,28,29,6,7,8,9,10,11,12,13,30,20,31,32,33,34,3,5,23,16,14,15,17,18,19,21,22]))),Tt=c.lazy(()=>f(()=>import("./Filiacao-DLnUjdRw.js"),__vite__mapDeps([35,1,2,17,18,9,10,21,6,7,8,11,12,13,4,36,34,3,5,23,16,14,15,19,20,22]))),Rt=c.lazy(()=>f(()=>import("./NotFound-BVTHShL6.js"),__vite__mapDeps([37,1,2,17,18,9,10,16,12,13,14,15,19,20,6,7,8,11,4,21,22]))),qt=c.lazy(()=>f(()=>import("./Noticias-Dqis71Dh.js"),__vite__mapDeps([38,1,2,17,18,9,10,16,12,13,14,15,26,19,20,6,7,8,11,4,21,22]))),Dt=c.lazy(()=>f(()=>import("./Institucional-ClzrWF-O.js"),__vite__mapDeps([39,1,2,34,3,5,6,7,8,9,10,11,12,13,23,16,14,15,17,18,19,20,4,21,22]))),Ht=c.lazy(()=>f(()=>import("./AcoesETematicas-CPWetyls.js"),__vite__mapDeps([40,1,2,34,3,5,6,7,8,9,10,11,12,13,23,16,14,15,17,18,19,20,4,21,22]))),Nt=c.lazy(()=>f(()=>import("./SocialPrograms-BFp7pgfq.js"),__vite__mapDeps([41,1,2,34,3,5,6,7,8,9,10,11,12,13,23,16,14,15,17,18,19,20,4,21,22]))),Vt=c.lazy(()=>f(()=>import("./Eixos-B2VK104H.js"),__vite__mapDeps([42,1,2,34,3,5,6,7,8,9,10,11,12,13,23,16,14,15,17,18,19,20,4,21,22]))),Gt=c.lazy(()=>f(()=>import("./Eventos-B4WlElmz.js"),__vite__mapDeps([43,1,2,34,3,5,6,7,8,9,10,11,12,13,23,16,14,15,17,18,19,20,4,21,22]))),Ut=c.lazy(()=>f(()=>import("./Regulamento-B2PUvoij.js"),__vite__mapDeps([44,1,2,34,3,5,6,7,8,9,10,11,12,13,23]))),Qt=c.lazy(()=>f(()=>import("./IntercambioNacional--hY0w_YM.js"),__vite__mapDeps([45,1,2,34,3,5,6,7,8,9,10,11,12,13,23]))),Wt=()=>n.jsx(je,{theme:Ft,children:n.jsxs(oe,{children:[n.jsx(Be,{}),n.jsx(ve,{}),n.jsx($e,{}),n.jsx(c.Suspense,{fallback:n.jsx(ne,{}),children:n.jsxs(Oe,{children:[n.jsx(g,{path:"/",element:n.jsx(At,{})}),n.jsx(g,{path:"/arquivo/:id/:title",element:n.jsx(Nn,{needsExternal:!0})}),n.jsx(g,{path:"/gerarlink",element:n.jsx(Lt,{})}),n.jsx(g,{path:"/estrutura",element:n.jsx(Bt,{})}),n.jsx(g,{path:"/filiacao",element:n.jsx(Tt,{})}),n.jsx(g,{path:"/noticias",element:n.jsx(qt,{})}),n.jsx(g,{path:"/institucional",element:n.jsx(Dt,{})}),n.jsx(g,{path:"/acoes",element:n.jsx(Ht,{})}),n.jsx(g,{path:"/arquivos/:type",element:n.jsx($t,{})}),n.jsx(g,{path:"/social-programs",element:n.jsx(Nt,{})}),n.jsx(g,{path:"/eixos",element:n.jsx(Vt,{})}),n.jsx(g,{path:"/eventos",element:n.jsx(Gt,{})}),n.jsx(g,{path:"/regulamento",element:n.jsx(Ut,{})}),n.jsx(g,{path:"/intercambio_nacional",element:n.jsx(Qt,{})}),n.jsx(g,{path:"/tutorial",element:n.jsx(Nn,{needsExternal:!1,filepath:"/markdown/pagina.md"})}),n.jsx(g,{path:"*",element:n.jsx(Rt,{})})," "]})}),n.jsx(qe,{})]})}),Yt=document.getElementById("root"),Xt=te(Yt);Xt.render(n.jsx(ee.StrictMode,{children:n.jsx(Wt,{})}));export{ne as L,o as _,f as a,xt as g};
