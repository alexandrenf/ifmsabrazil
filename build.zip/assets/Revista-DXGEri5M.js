import{j as i}from"./react-CLPtFgDq.js";import{M as a}from"./MarkdownContent-BNKm4Bhr.js";import{s as o,C as s,T as e}from"./@mui-B86xCNSa.js";import"./@babel-f5lBRPU2.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */import"./clsx-B-dksMZM.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./react-transition-group-CLuBo2_z.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-is-DcfIKM1A.js";const t=o(s)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),r=o(e)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),S=()=>i.jsxs(t,{children:[i.jsx(r,{variant:"h4",children:"Brazilian Medical Students"}),i.jsx(a,{content:`

A Brazilian Medical Students (BMS) é o periódico científico (ISSN: 2675-1542) da IFMSA Brazil. A Revista é composta por Editor in chief, Editores Associados, Corpo Editorial, Editor de Conteúdo e de Design, sendo esse grupo composto por acadêmicos de medicina e professores de diversas áreas. Seu objetivo principal é disseminar as produções acadêmicas dos estudantes de medicina e profissionais filiados ou não à IFMSA Brazil. O periódico aceita artigos na modalidade editorial, artigos originais, revisões, relatos de experiência tendo seu escopo constituído pelas seguintes temáticas: Saúde Coletiva, Educação, conhecimentos e mobilidade acadêmica, cuidados gerais com pacientes. Dessa forma, a revista preza pelos princípios da ciência aberta, da evidência científica e visando a responsabilidade social em pesquisa. 

**Email:** [bms@ifmsabrazil.org](mailto:bms@ifmsabrazil.org)

**Instagram:** [@bmsjournal](https://www.instagram.com/bmsjournal/)

**Site:** [bms.ifmsabrazil.org](https://bms.ifmsabrazil.org)


`})]});export{S as default};
