const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Revista-C_B6Usm8.js","assets/react-DaPl5ws4.js","assets/@babel-CNkBngnk.js","assets/MarkdownContent-Bk-obxsC.js","assets/markdown-to-jsx-CXBEPAoT.js","assets/prismjs-DEnDlMkx.js","assets/@mui-D3p2DSY1.js","assets/clsx-B-dksMZM.js","assets/react-is-DcfIKM1A.js","assets/@emotion-Clztb9Oy.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/react-transition-group-cLDJx4Bm.js","assets/react-dom-CWF6clnO.js","assets/scheduler-CzFDRTuY.js","assets/codeStyles-vPv1o2UF.css","assets/Ressonancia-DY9YuyjY.js","assets/Declaracoes-DhxT2pWe.js","assets/Notas-DfvcpL3F.js","assets/InformaSUSi-T3pvG8eF.js","assets/NotFound-CTniBd3E.js","assets/index-Di46prad.js","assets/react-router-dom-BFBG7k2k.js","assets/react-router-B_WJkAv4.js","assets/@remix-run-B-RBrVrq.js","assets/react-cookie-consent-xWEKRR8T.js","assets/styled-components-D58U5FK1.js","assets/tslib-wbdO-F7s.js","assets/stylis-DinRj2j6.js","assets/@fortawesome-BOOXKGIM.js","assets/prop-types-15ULSoSZ.js","assets/axios-B4uVmeYG.js","assets/js-cookie-Cz0CWeBA.js","assets/react-icons-BQxfTaxZ.js","assets/date-fns-X50TK9oK.js","assets/index-DkNmx6u9.css"])))=>i.map(i=>d[i]);
import{_ as l,L as B,a as c}from"./index-Di46prad.js";import{r as o,j as e}from"./react-DaPl5ws4.js";import{p as m}from"./styled-components-D58U5FK1.js";import{a as F}from"./axios-B4uVmeYG.js";import{B as V}from"./BlogPostListItem-Dxlq77NV.js";import{f as N}from"./react-router-B_WJkAv4.js";import{h as M,F as G,i as U,S as Z,O as W,M as H,j as J,L as K,k as Q,B as p,l as w,D as X}from"./@mui-D3p2DSY1.js";import"./react-dom-CWF6clnO.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-BFBG7k2k.js";import"./@remix-run-B-RBrVrq.js";import"./react-cookie-consent-xWEKRR8T.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./js-cookie-Cz0CWeBA.js";import"./react-icons-BQxfTaxZ.js";import"./date-fns-X50TK9oK.js";import"./tslib-wbdO-F7s.js";import"./stylis-DinRj2j6.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";var j,v,A,g,y,D;const Y=o.lazy(()=>c(()=>import("./Revista-C_B6Usm8.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),$=o.lazy(()=>c(()=>import("./Ressonancia-DY9YuyjY.js"),__vite__mapDeps([15,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),ee=o.lazy(()=>c(()=>import("./Declaracoes-DhxT2pWe.js"),__vite__mapDeps([16,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),te=o.lazy(()=>c(()=>import("./Notas-DfvcpL3F.js"),__vite__mapDeps([17,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),re=o.lazy(()=>c(()=>import("./InformaSUSi-T3pvG8eF.js"),__vite__mapDeps([18,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),oe=o.lazy(()=>c(()=>import("./NotFound-CTniBd3E.js"),__vite__mapDeps([19,20,1,2,12,13,21,22,23,24,25,26,9,10,27,28,29,6,7,8,11,30,31,32,33,34]))),ie=[{href:"notas",label:"Arquivos de Nota de Posicionamento",file:"1",ref:"notas-de-posicionamento"},{href:"susi",label:"Informa SUSi",file:"2",ref:"informa-susi"},{href:"rp",label:"Edições da Ressonância Poética",file:"3",ref:"ressonancia-poetica"},{href:"bms",label:"Edições de Brazilian Medical Students",file:"4",ref:"bms"},{href:"relatorios",label:"Relatórios",file:"",ref:"relatorios"},{href:"dps",label:"Arquivos de Declarações de Política",file:"6",ref:"declaracoes-de-politica"},{href:"intercambio_nac",label:"Intercâmbio Nacional",file:"",ref:"intercambio-nacional"},{href:"intercambio_inter",label:"Intercâmbio Internacional",file:"",ref:"intercambio-internacional"},{href:"regulamento",label:"Regulamento de Intercâmbios",file:"",ref:"regulamento-intercambios"}],ne=f=>{switch(f){case"1":return e.jsx(te,{});case"3":return e.jsx($,{});case"4":return e.jsx(Y,{});case"6":return e.jsx(ee,{});case"2":return e.jsx(re,{});default:return null}},se=m.section(j||(j=l([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #f0f2f5;
`]))),ae=m.h2(v||(v=l([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 30px;
`]))),le=m.div(A||(A=l([`
  width: 100%;
  max-width: 1200px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
`]))),ce=m(w)(g||(g=l([`
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
`]))),me=m(X)(y||(y=l([`
  margin: 0 20px;
`]))),de=m(w)(D||(D=l([`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 1200px;
`]))),ze=()=>{const{type:f}=N(),[x,E]=o.useState([]),[S,q]=o.useState(!0),[b,u]=o.useState("dateDesc"),[h,I]=o.useState(""),[d,L]=o.useState([]),[O,T]=o.useState([]),s=ie.find(t=>t.ref===f);if(console.log(s),!s)return e.jsx(oe,{});const _="https://api.ifmsabrazil.org/api/arquivos/".concat(s.href),C=s?s.label:"Publicações";o.useEffect(()=>{(async()=>{try{const i=(await F.get(_)).data;if(!Array.isArray(i))throw new Error("Arquivos data is not an array");E(i)}catch(r){console.error("Error fetching arquivos:",r)}finally{q(!1)}})()},[_]),o.useEffect(()=>{T(k(x))},[x,b,h,d]);const P=(t,r)=>{const i=[...t];return r==="dateAsc"?i.sort((n,a)=>new Date(n.date)-new Date(a.date)):r==="dateDesc"?i.sort((n,a)=>new Date(a.date)-new Date(n.date)):r==="titleAsc"?i.sort((n,a)=>n.title.localeCompare(a.title)):r==="titleDesc"&&i.sort((n,a)=>a.title.localeCompare(n.title)),i},R=t=>t.filter(r=>{const i=r.title.toLowerCase().includes(h.toLowerCase()),n=d.length===0||d.includes(r.author);return i&&n}),k=t=>{const r=P(t,b);return R(r)};if(S)return e.jsx(B,{});const z=[...new Set(x.map(t=>t.author))];return e.jsxs(e.Fragment,{children:[ne(s==null?void 0:s.file),e.jsxs(se,{children:[e.jsx(ae,{children:C}),e.jsxs(de,{children:[e.jsx(M,{label:"Buscar por Título",variant:"outlined",value:h,onChange:t=>I(t.target.value),style:{marginRight:"20px",flexGrow:1}}),e.jsxs(G,{variant:"outlined",style:{minWidth:200},children:[e.jsx(U,{children:"Filtrar por Autor"}),e.jsx(Z,{multiple:!0,value:d,onChange:t=>L(t.target.value),input:e.jsx(W,{label:"Filtrar por Autor"}),renderValue:t=>t.join(", "),children:z.map(t=>e.jsxs(H,{value:t,children:[e.jsx(J,{checked:d.indexOf(t)>-1}),e.jsx(K,{primary:t})]},t))})]})]}),e.jsx(ce,{children:e.jsxs(Q,{variant:"outlined",color:"primary",children:[e.jsx(p,{onClick:()=>u("dateDesc"),children:"Data (mais recentes)"}),e.jsx(p,{onClick:()=>u("dateAsc"),children:"Data (mais antigas)"}),e.jsx(me,{orientation:"vertical",flexItem:!0}),e.jsx(p,{onClick:()=>u("titleAsc"),children:"Título (A-Z)"}),e.jsx(p,{onClick:()=>u("titleDesc"),children:"Título (Z-A)"})]})}),e.jsx(le,{children:O.map((t,r)=>e.jsx("a",{href:t.fileLink,style:{textDecoration:"none"},target:"_blank",rel:"noopener noreferrer",children:e.jsx(V,{post:t})},r))})]})]})};export{ze as default};
