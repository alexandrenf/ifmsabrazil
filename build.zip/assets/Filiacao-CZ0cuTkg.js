import{j as e,r as i}from"./react-DaPl5ws4.js";import{_ as c,L as Y}from"./index-DwcZxXNk.js";import{p as l}from"./styled-components-D58U5FK1.js";import{d as Z,F as ee}from"./react-icons-BQxfTaxZ.js";import{m as oe,n as ae,o as ne,P as te,p as se,q as F,r as re,t as ie,l as ce,h as le,F as de,i as me,S as pe,O as xe,M as A,L as P,s as D,C as ue,T as Ee}from"./@mui-D3p2DSY1.js";import{a as he}from"./axios-B4uVmeYG.js";import{P as ge}from"./papaparse-RALpPLFu.js";import{M as fe}from"./MarkdownContent-Bk-obxsC.js";import"./@babel-CNkBngnk.js";import"./react-dom-CWF6clnO.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-BFBG7k2k.js";import"./react-router-B_WJkAv4.js";import"./@remix-run-B-RBrVrq.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./js-cookie-Cz0CWeBA.js";import"./date-fns-X50TK9oK.js";import"./tslib-wbdO-F7s.js";import"./stylis-DinRj2j6.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";import"./markdown-to-jsx-CXBEPAoT.js";import"./prismjs-DEnDlMkx.js";/* empty css                   */var L,S,M,z,T;const be=l.div(L||(L=c([`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  color: white;
`]))),ve=l.div(S||(S=c([`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`]))),je=l(Z)(M||(M=c([`
  font-size: 3rem;
  margin-bottom: 10px;
`]))),Ce=l.p(z||(z=c([`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  margin-bottom: 20px;
`]))),we=l.button(T||(T=c([`
  background-color: white;
  color: #003366;
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;

  &:hover {
    background-color: transparent;
    color: white;
  }
`]))),Fe=t=>{let{onClose:n}=t;return e.jsx(be,{children:e.jsxs(ve,{children:[e.jsx(je,{}),e.jsx(Ce,{children:"Por favor, gire seu dispositivo para o modo horizontal"}),e.jsx(we,{onClick:n,children:e.jsx(ee,{size:24})})]})})};var y,I,O,R;const Ae=l(oe)(y||(y=c([`
  background-color: #00508c;
  & th {
    color: #fff;
    font-weight: bold;
    white-space: nowrap;
  }
`]))),Pe=l(ae)(I||(I=c([`
  width: 100%;
  overflow-x: auto;
  position: relative;
`]))),r=l(ne)(O||(O=c([`
  min-width: 150px;
`]))),Le=l.div(R||(R=c([`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 999;
`]))),Se=t=>{let{displayedMembers:n,filteredMembersLength:m,page:h,rowsPerPage:s,handleChangePage:g,handleChangeRowsPerPage:f,showPrompt:p,onClosePrompt:u}=t;return e.jsxs(Pe,{component:te,children:[p&&e.jsx(Le,{}),p&&e.jsx(Fe,{onClose:u}),e.jsxs(se,{children:[e.jsx(Ae,{children:e.jsxs(F,{children:[e.jsx(r,{children:"Comitê Local"}),e.jsx(r,{children:"Nome da EM"}),e.jsx(r,{children:"Regional"}),e.jsx(r,{children:"Cidade"}),e.jsx(r,{children:"UF"}),e.jsx(r,{children:"Status"})]})}),e.jsx(re,{children:n.map((d,E)=>e.jsxs(F,{children:[e.jsx(r,{children:d["Comitê Local"]}),e.jsx(r,{children:d["Nome da EM"]}),e.jsx(r,{children:d.Regional}),e.jsx(r,{children:d.Cidade}),e.jsx(r,{children:d.UF}),e.jsx(r,{children:d.Status})]},E))})]}),e.jsx(ie,{component:"div",count:m,page:h,onPageChange:g,rowsPerPage:s,onRowsPerPageChange:f,rowsPerPageOptions:[10,25,50,100,{label:"Todos",value:m}],labelRowsPerPage:"Itens por página"})]})};var B,k,q;const Me=l.h1(B||(B=c([`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  color: #333;
  text-align: center;
  margin-bottom: 10px;
`]))),ze=l.section(k||(k=c([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #fafafa;
`]))),Te=l(ce)(q||(q=c([`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 1200px;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: stretch;
  }
`]))),ye=t=>{let{members:n}=t;const[m,h]=i.useState(""),[s,g]=i.useState({regional:"",cidade:"",uf:"",status:""}),[f,p]=i.useState([]),[u,d]=i.useState(0),[E,_]=i.useState(10),[U,j]=i.useState(!1),[C,V]=i.useState(!1),w=Ie(n);i.useEffect(()=>{const a=()=>{const o=window.innerWidth<=768,x=window.innerHeight>window.innerWidth;j(o&&x)};return C||(window.addEventListener("resize",a),a()),()=>{window.removeEventListener("resize",a)}},[C]),i.useEffect(()=>{p(Q(w))},[w,m,s]);const N=a=>{h(a.target.value)},$=()=>{V(!0),j(!1)},G=a=>{const{name:o,value:x}=a.target;g(b=>({...b,[o]:x}))},H=(a,o)=>{d(o)},W=a=>{_(parseInt(a.target.value,10)),d(0)},Q=a=>a.filter(o=>{const x=o["Comitê Local"]||"",b=o["Nome da EM"]||"",v=x.toLowerCase().includes(m.toLowerCase())||b.toLowerCase().includes(m.toLowerCase()),K=(!s.regional||o.Regional===s.regional)&&(!s.cidade||o.Cidade===s.cidade)&&(!s.uf||o.UF===s.uf)&&(!s.status||o.Status===s.status);return v&&K}).sort((o,x)=>{const b=o["Comitê Local"]||"",v=x["Comitê Local"]||"";return b.localeCompare(v)}),J=a=>[...new Set(n.map(o=>o[a]))].sort(),X=f.slice(u*E,u*E+E);return e.jsxs(ze,{children:[e.jsx(Me,{children:"Lista de Comitês Locais Filiados"}),e.jsxs(Te,{children:[e.jsx(le,{label:"Buscar",variant:"outlined",value:m,onChange:N,style:{mimWidth:250,marginBottom:"20px",flexGrow:1,marginRight:"10px"}}),["Regional","Cidade","UF","Status"].map(a=>e.jsxs(de,{variant:"outlined",style:{minWidth:175,marginBottom:"20px",marginRight:"10px"},children:[e.jsx(me,{children:a}),e.jsxs(pe,{name:a.toLowerCase(),value:s[a.toLowerCase()],onChange:G,input:e.jsx(xe,{label:a}),renderValue:o=>o||"Todos",children:[e.jsx(A,{value:"",children:e.jsx(P,{primary:"Todos"})}),J(a).map(o=>e.jsx(A,{value:o,children:e.jsx(P,{primary:o})},o))]})]},a))]}),e.jsx(Se,{displayedMembers:X,filteredMembersLength:f.length,page:u,rowsPerPage:E,handleChangePage:H,handleChangeRowsPerPage:W,showPrompt:U,onClosePrompt:()=>$()})]})},Ie=t=>t.map(n=>(n["Comitê Local "]&&(n["Comitê Local"]=n["Comitê Local "].trim(),delete n["Comitê Local "]),n)),Oe=D(ue)(t=>{let{theme:n}=t;return{padding:"24px",backgroundColor:"#FFFFFF",color:"#333",[n.breakpoints.down("sm")]:{padding:"16px"}}}),Re=D(Ee)(t=>{let{theme:n}=t;return{color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center",[n.breakpoints.down("sm")]:{fontSize:"1.5rem"}}}),mo=()=>{const t="https://docs.google.com/spreadsheets/d/1PF7Lqb0jq1ULQBmHzFxOif5UvGwsVLqM2LESq7JVh6c/export?gid=1583477648&format=csv",[n,m]=i.useState([]),[h,s]=i.useState(!0);i.useEffect(()=>{(async()=>{try{const p=await he.get(t),d=ge.parse(p.data,{header:!0}).data;m(d)}catch(p){console.error("Error fetching spreadsheet:",p)}finally{s(!1)}})()},[t]);const g=`

## Como posso me filiar à IFMSA Brazil?

Para se filiar, é necessário que sua escola médica tenha um comitê local da IFMSA Brazil e manifestar seu interesse a ele.

## Como eu posso fundar um comitê local?

Basta mandar um e-mail para [vpi@ifmsabrazil.org](mailto:vpi@ifmsabrazil.org) contendo o nome da sua instituição de ensino, demonstrando interesse em fundar um comitê local.
Por lá, podemos começar um processo de filiação.
Confira essa página com atenção para ver as informações sobre a filiação!

## Como funciona o processo de filiação?

### Em cinco etapas!

- **Etapa I:** Você receberá alguns documentos sobre a IFMSA Brazil e será orientado a constituir um grupo de no mínimo 5 pessoas para dar seguimento.
- **Etapa II:** Um contrato de autorização deverá ser assinado pelo coordenador do curso e pelo grupo que foi formado por você juntamente com algumas informações essenciais sobre a faculdade.
- **Etapa III:** Consiste na deliberação da Diretoria Executiva Nacional sobre a viabilidade de, naquele momento, vocês serem filiados
- **Etapa IV:** Vocês serão orientados por Coordenadores Regionais e membros da Diretoria Executiva a realizarem uma atividade de cunho social obedecendo algumas regras e preenchendo as fichas de submissão de atividade.
- **Etapa V:** Ao ser executada cada etapa, um novo processo de avaliação será feito pelos Coordenadores Regionais e Diretoria Executiva e, caso vocês a executem bem, serão convidados a estar conosco em nossa próxima Assembleia Geral para defender a não plenitude da sua faculdade perante a plenária da IFMSA Brazil.

## Como funciona a Assembleia Geral?

É o espaço de deliberação máxima na IFMSA Brazil, onde ocorrem paralelamente sessões, workshops, treinamentos, palestras, entre outros eventos, dentre os quais está a apresentação de sua candidatura à não plenitude.
Caso vocês recebam a carta convite para apresentar a não-plenitude, será necessário no mínimo um representante presente.

## Quanto tempo esse processo demora?

Em média, 1 ano para ser finalizado.
O processo pode durar menos de acordo com cada comitê aspirante.

## Há algum custo para ser filiado?

### Não!

Não há nenhuma taxa de filiação ou taxa para se manter filiado.

O único custo é a ida até a Assembleia Geral, que deve ser custeada pelo grupo fundador. A inscrição no evento inclui alimentação, hospedagem e o evento em si, e outros custos envolvem o transporte até o evento.
Durante o ciclo de capacitações sobre a atividade, vocês irão aprender estratégias para fazer uma atividade financeiramente sustentável, e conseguir patrocínios e parcerias (inclusive com a coordenação do curso), que podem ajudar com esse custo!

## E quanto aos intercâmbios?

Após o processo de não-plenitude, vocês precisarão começar o processo de plenitude que no geral dura cerca de mais um ano após a primeira ida à Assembléia Geral.

## O que é a plenitude?

Um comitê pleno é um comitê considerado capacitado para estabelecimento de direitos plenos dentro da Federação, tendo como base a atuação perante nosso eixos. Tem direito de voz e voto, e pode realizar intercâmbios.
O processo de plenitude envolve comitês bem estruturados, com um contrato de intercâmbio assinado, e vagas declaradas.

## Minha faculdade não tem IFMSA Brazil, posso fazer intercâmbio por vocês?

Não! Apenas alunos de faculdades filiadas podem fazer intercâmbios.

## Quando iremos aprender mais informações sobre a IFMSA Brazil?

Todos os aprovados na etapa III passam por capacitações sobre planejamento de atividades, metodologia de impacto, e outros assuntos pertinentes à filiação.
Após a filiação em si, todos os novos comitês não-plenos passam por um ciclo de capacitações sobre todos os eixos da IFMSA Brazil.


`;return h?e.jsx(Y,{}):e.jsxs(Oe,{children:[e.jsx(Re,{variant:"h4",children:"Processo de Filiação e Comitês Filiados"}),e.jsx(fe,{content:g}),e.jsx(ye,{members:n})]})};export{mo as default};
