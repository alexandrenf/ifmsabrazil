import{r as d,j as o}from"./react-CLPtFgDq.js";import{L as u}from"./index-De8g1K0y.js";import{a as E}from"./axios-B4uVmeYG.js";import{C as m}from"./react-multi-carousel-BkRiOElf.js";import{s as n,C as f,j as C,A as v,T as c}from"./@mui-B86xCNSa.js";import{C as b,G as A,a as S}from"./react-simple-maps-DEBQupZu.js";import{M as p}from"./MarkdownContent-BNKm4Bhr.js";import"./@babel-f5lBRPU2.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-Am9psY4u.js";import"./react-router-BzRFIFMZ.js";import"./@remix-run-YI_hLLil.js";import"./styled-components-BY_vc4YD.js";import"./tslib-wbdO-F7s.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./@fortawesome-B6QlLdFu.js";import"./prop-types-1yzuAbYU.js";import"./webfontloader-DM8E560Z.js";import"./react-icons-CrkDh4zl.js";import"./clsx-B-dksMZM.js";import"./react-transition-group-CLuBo2_z.js";import"./react-is-DcfIKM1A.js";import"./topojson-client-DzWSY_RA.js";import"./d3-geo-eEO7UCrt.js";import"./d3-array-BweefaKS.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */const j=m.default?m.default:m,F=n(f)({paddingLeft:"24px",paddingRight:"24px",paddingTop:"24px",paddingBottom:"24px",backgroundColor:"#FFFFFF",color:"#333",position:"relative"}),w=n(C)({padding:"16px",margin:"8px",backgroundColor:"#f9f9f9",borderRadius:"8px",boxShadow:"0 4px 8px rgba(0, 0, 0, 0.1)",textAlign:"center",transition:"transform 0.3s ease","&:hover":{transform:"scale(1.05)"},display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",height:"auto",minHeight:"300px",overflow:"hidden"}),R=n(v)({width:"120px",height:"120px",marginBottom:"16px",borderRadius:"12px",boxShadow:"0 4px 10px rgba(0, 0, 0, 0.2)"}),D=n(c)({textOverflow:"ellipsis",overflow:"hidden",whiteSpace:"normal",wordWrap:"break-word",width:"100%",display:"block"}),y=n(c)({color:"#1976d2",marginBottom:"8px",textOverflow:"ellipsis",overflow:"hidden",whiteSpace:"normal",wordWrap:"break-word",width:"100%",display:"block"}),N=n(c)({color:"#333",textOverflow:"ellipsis",overflow:"hidden",whiteSpace:"normal",wordWrap:"break-word",width:"100%",display:"block"}),M=()=>{const[t,l]=d.useState([]),[s,e]=d.useState(!0);if(d.useEffect(()=>{(async()=>{try{const r=await E.get("https://api.ifmsabrazil.org/api/ebs");l(r.data)}catch(r){console.error("Error fetching EB members:",r)}finally{e(!1)}})()},[]),s)return o.jsx(u,{});const i={superLargeDesktop:{breakpoint:{max:4e3,min:1024},items:3},desktop:{breakpoint:{max:1024,min:768},items:2},tablet:{breakpoint:{max:768,min:464},items:2},mobile:{breakpoint:{max:464,min:0},items:1}};return o.jsxs(F,{children:[o.jsx(c,{variant:"h4",align:"center",gutterBottom:!0,children:"Diretoria Executiva"}),o.jsx(j,{responsive:i,ssr:!0,infinite:!0,autoPlay:!1,autoPlaySpeed:3e3,keyBoardControl:!0,showDots:!1,children:t.map((a,r)=>o.jsxs(w,{children:[o.jsx(R,{src:a.imageLink,alt:a.name}),o.jsx(D,{variant:"h6",children:a.name}),o.jsxs(y,{variant:"body1",children:[a.role," (",a.acronym,")"]}),o.jsx(N,{variant:"body2",children:a.email})]},r))})]})},x=[{name:"Norte 1",states:["Acre","Rondônia","Amazonas","Roraima"],color:"#1f77b4"},{name:"Norte 2",states:["Pará","Amapá"],color:"#aec7e8"},{name:"Nordeste 1",states:["Maranhão","Piauí","Ceará"],color:"#2ca02c"},{name:"Nordeste 2",states:["Rio Grande do Norte","Paraíba","Pernambuco"],color:"#98df8a"},{name:"Nordeste 3",states:["Alagoas","Sergipe","Bahia"],color:"#ffbb78"},{name:"Leste",states:["Minas Gerais","Espírito Santo","Rio de Janeiro"],color:"#ff7f0e"},{name:"Oeste",states:["Distrito Federal","Tocantins","Goiás","Mato Grosso","Mato Grosso do Sul"],color:"#d62728"},{name:"Paulista",states:["São Paulo"],color:"#9467bd"},{name:"Sul",states:["Paraná","Santa Catarina","Rio Grande do Sul"],color:"#8c564b"}],k=()=>{const[t,l]=d.useState(null);return d.useEffect(()=>{(async()=>{try{const e=await E.get("https://cdn.jsdelivr.net/gh/alexandrenf/ifmsabrazil/src/assets/brazilstates.json");l(e.data)}catch(e){console.error("Error fetching TopoJSON data:",e)}})()},[]),o.jsx("div",{className:"container",children:t?o.jsxs(o.Fragment,{children:[o.jsx("div",{className:"map-container",children:o.jsx(b,{projection:"geoMercator",projectionConfig:{scale:750,center:[-54,-15]},style:{width:"100%",height:"auto"},children:o.jsx(A,{geography:t,children:s=>{let{geographies:e}=s;return e.map(i=>{const a=i.properties.nome,r=x.find(h=>h.states.includes(a)),g=r?r.color:"#EEE";return o.jsx(S,{geography:i,fill:g,style:{default:{outline:"none"},hover:{outline:"none"},pressed:{outline:"none"}}},i.rsmKey)})}})})}),o.jsx("div",{className:"legend-container",children:x.map((s,e)=>o.jsxs("div",{className:"legend-item",children:[o.jsx("div",{className:"color-box",style:{backgroundColor:s.color}}),o.jsx("span",{children:s.name})]},e))})]}):o.jsx(u,{})})},P=n(f)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),B=n(c)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),xo=()=>o.jsxs(P,{children:[o.jsx(B,{variant:"h4",children:"Estrutura da IFMSA Brazil"}),o.jsx(p,{content:`

  ## Nossa Composição

A estrutura da IFMSA Brazil é composta por:

- Diretoria Executiva (EB);
- Coordenadores Regionais (CRs);
- Times Nacionais;
- Coordenadores Nacionais de Programas (CNPs);
- Comitês Locais (LCs) → escolas médicas filiadas;
- Coordenadores Locais (CLs) → estudantes de medicina filiados;
- Alumni;
- Conselho Supervisor (SupCo);
- Comissão de Reforma e Elaboração de Documentos (CRED).

## Diretoria Executiva Nacional

A Diretoria Executiva é composta por 21 cargos a nível nacional, responsável por:

- Captar recursos e finanças;
- Gerir o marketing e relações externas;
- Administrar, desenvolver e apoiar os Comitês Locais;
- Desenvolvimento de atividades centrais em seis principais campos da saúde:
  - Saúde pública;
  - Educação médica;
  - Saúde e direitos sexuais e reprodutivos incluindo HIV e AIDS;
  - Direitos Humanos e Paz;
  - Intercâmbios nacional e internacional clínico-cirúrgicos ou de pesquisa.

`}),o.jsx(M,{}),o.jsx(p,{content:`
## Coordenação Regional

### O que fazem os Coordenadores Regionais?

Os Coordenadores Regionais prestam assistência à Diretoria Executiva em tarefas a nível regional; desenvolve competência de nossos eixos de atuação em Escolas Médicas de cada região; promove oportunidades, como Assembleias Regionais, espaços de representatividade de nossos coordenadores locais.

As Regionais da IFMSA Brazil são: Norte 1 (AC, RO, AM, RR), Norte 2 (PA, AP), Nordeste 1 (MA, PI, CE), Nordeste 2 (RN, PB, PE), Nordeste 3 (AL, SE, BA), Leste (MG, ES, RJ), Oeste (TO, GO, MT, MS), Paulista (SP), Sul (PR, SC, RS).
`}),o.jsx(k,{}),o.jsx(p,{content:`
## Times Nacionais

Os Times Nacionais da IFMSA Brazil são divisões de suporte ao trabalho dos Diretores Nacionais e dos Coordenadores Regionais, tendo sua organização interna e funções específicas definidas caso a caso pelo Diretor Nacional responsável e também regionalizadas de acordo com as demandas dos comitês locais.

## Conselho Supervisor

O Conselho Supervisor supervisiona ações e decisões tomadas pela Diretoria Executiva e cria estratégias para garantir imparcialidade e objetividade em investigações internas.

## Conselho de Reforma e Elaboração de Documentos (CRED)

O Conselho de Reforma e Elaboração de Documentos é responsável por revisar documentos internos e promover reuniões com participação de todos os membros para definir alterações nesses documentos.

## Alumni

Os alumni são médicos filiados à IFMSA Brazil que foram Coordenadores Locais (membros de comitês locais) em suas instituições de ensino superior de origem.

### Como me tornar alumni?

É um processo interno que ocorre quando um Coordenador Local pede desfiliação ao Vice-Presidente para Assuntos Internos, declarando interesse em se tornar alumnus ou alumna da IFMSA Brazil. A partir disso, nosso Diretor Nacional de Alumni entrará em contato com o interessado, para que entenda seu novo papel.
`})]});export{xo as default};
