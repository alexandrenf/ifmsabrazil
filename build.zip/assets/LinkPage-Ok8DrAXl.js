import{_ as i}from"./index-Di46prad.js";import{j as n}from"./react-DaPl5ws4.js";import{p as r}from"./styled-components-D58U5FK1.js";import"./react-dom-CWF6clnO.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-BFBG7k2k.js";import"./react-router-B_WJkAv4.js";import"./@remix-run-B-RBrVrq.js";import"./react-cookie-consent-xWEKRR8T.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./@mui-D3p2DSY1.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";import"./axios-B4uVmeYG.js";import"./js-cookie-Cz0CWeBA.js";import"./react-icons-BQxfTaxZ.js";import"./date-fns-X50TK9oK.js";import"./tslib-wbdO-F7s.js";import"./stylis-DinRj2j6.js";var a;const p=r.a(a||(a=i([`
  display: block;
  padding: 15px;
  margin: 10px 0;
  width: 80%;
  text-align: center;
  background-color: #00963c;
  color: #fff;
  font-size: 1.2rem;
  font-weight: bold;
  text-decoration: none;
  border-radius: 8px;
  transition: background-color 0.3s ease-in-out;

  &:hover {
    background-color: #007f33;
  }
`]))),t=s=>{let{name:m,link:l}=s;return n.jsx(p,{href:l,target:"_blank",rel:"noopener noreferrer",children:m})};var o,e;const c=r.div(o||(o=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 20px;
  background-color: white;
  min-height: 100vh;
`]))),d=r.h1(e||(e=i([`
  font-size: 2rem;
  color: #00508c;
  margin-bottom: 20px;
`]))),T=()=>n.jsxs(c,{children:[n.jsx(d,{children:"Links COBEM 2024"}),n.jsx(t,{name:"Site da IFMSA Brazil",link:"https://ifmsabrazil.org"}),n.jsx(t,{name:"Instagram",link:"https://instagram.com/ifmsabrazil"}),n.jsx(t,{name:"Instagram de Intercâmbios Internacionais",link:"https://instagram.com/ifmsabrazilexchanges"}),n.jsx(t,{name:"Instagram de Intercâmbios Nacionais",link:"https://instagram.com/ifmsabrazilintercambios"}),n.jsx(t,{name:"BMS Journal Instagram",link:"https://instagram.com/bmsjournal"}),n.jsx(t,{name:"Declarações de Política",link:"https://ifmsabrazil.org/arquivos/declaracoes-de-politica"}),n.jsx(t,{name:"Como submeter à BMS",link:"https://drive.google.com/drive/u/0/mobile/folders/1k1PsgHNX-pwwZbzuZWrd2kV3CRsaWv4Z?usp=sharing"}),n.jsx(t,{name:"Introdução à BMS",link:"https://drive.google.com/file/d/17RMM6f24aj6QnFgmnP4Wa-IDakiNqI4q/view?usp=drivesdk"}),n.jsx(t,{name:"Chamada Ressonância Poética",link:"https://ifmsabrazil.org/arquivo/5/chamada-para-submissao-de-trabalhos-no-v-resson-ncia-poetica"}),n.jsx(t,{name:"Em Breve",link:"#"})]});export{T as default};
