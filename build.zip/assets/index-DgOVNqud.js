const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Alert-DqVYityC.js","assets/react-DaPl5ws4.js","assets/@babel-CNkBngnk.js","assets/styled-components-BD7m8TR7.js","assets/tslib-wbdO-F7s.js","assets/@emotion-Clztb9Oy.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/react-dom-CWF6clnO.js","assets/scheduler-CzFDRTuY.js","assets/react-router-dom-BFBG7k2k.js","assets/react-router-B_WJkAv4.js","assets/@remix-run-B-RBrVrq.js","assets/@fortawesome-BOOXKGIM.js","assets/prop-types-15ULSoSZ.js","assets/@mui-D3p2DSY1.js","assets/clsx-B-dksMZM.js","assets/react-is-DcfIKM1A.js","assets/react-transition-group-cLDJx4Bm.js","assets/axios-B4uVmeYG.js","assets/react-icons-vpqwEHyG.js","assets/date-fns-X50TK9oK.js","assets/MarkdownPage-D9-5jk0L.js","assets/markdown-to-jsx-CXBEPAoT.js","assets/prismjs-DEnDlMkx.js","assets/codeStyles-vPv1o2UF.css","assets/GeradorLink-BvzLFz8y.js","assets/Arquivos-BieBkdgD.js","assets/BlogPostListItem-C5_5S76V.js","assets/Estrutura-BRFEcKm-.js","assets/react-multi-carousel-BYLf87Xc.js","assets/react-multi-carousel-C0HCKJ4u.css","assets/react-simple-maps-s3X3tYH8.js","assets/topojson-client-DzWSY_RA.js","assets/d3-geo-eEO7UCrt.js","assets/d3-array-BweefaKS.js","assets/MarkdownContent-Bk-obxsC.js","assets/Filiacao-Dv-1O0k5.js","assets/papaparse-RALpPLFu.js","assets/NotFound-EybCYkNE.js","assets/Noticias-U5XFGmFr.js","assets/Institucional-D6iabtNm.js","assets/AcoesETematicas-BJj1DtY3.js","assets/SocialPrograms-C8eNm8OA.js","assets/Eixos-DU6QpDWR.js","assets/Eventos-r2qjtqXW.js","assets/Regulamento-B2PUvoij.js","assets/IntercambioNacional--hY0w_YM.js"])))=>i.map(i=>d[i]);
import{r as c,j as n,a as Rn}from"./react-DaPl5ws4.js";import{c as qn}from"./react-dom-CWF6clnO.js";import{L as l,B as Dn}from"./react-router-dom-BFBG7k2k.js";import{p as a,h as Hn,f as zn}from"./styled-components-BD7m8TR7.js";import{l as A,f as Sn,a as Mn,F as _,b as Nn,c as Vn,d as Gn,e as Un,g as Qn,h as Pn,i as In,j as An,k as Fn,m as Ln,n as Tn,o as Bn}from"./@fortawesome-BOOXKGIM.js";import{j as Wn,a as Yn,G as Xn}from"./@emotion-Clztb9Oy.js";import{s as C,I as Jn,C as F,G as k,T as f,a as Kn,b as Zn,c as ne,d as ee,e as te,f as oe,g as ie}from"./@mui-D3p2DSY1.js";import{a as re}from"./axios-B4uVmeYG.js";import{F as ae,a as L,b as se}from"./react-icons-vpqwEHyG.js";import{i as le,p as T}from"./date-fns-X50TK9oK.js";import{d as ce,e as h}from"./react-router-B_WJkAv4.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./@remix-run-B-RBrVrq.js";import"./tslib-wbdO-F7s.js";import"./prop-types-15ULSoSZ.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))p(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const d of r.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&p(d)}).observe(document,{childList:!0,subtree:!0});function s(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?r.credentials="include":e.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function p(e){if(e.ep)return;e.ep=!0;const r=s(e);fetch(e.href,r)}})();const de="modulepreload",me=function(t){return"/"+t},B={},u=function(o,s,p){let e=Promise.resolve();if(s&&s.length>0){document.getElementsByTagName("link");const r=document.querySelector("meta[property=csp-nonce]"),d=(r==null?void 0:r.nonce)||(r==null?void 0:r.getAttribute("nonce"));e=Promise.all(s.map(x=>{if(x=me(x),x in B)return;B[x]=!0;const b=x.endsWith(".css"),v=b?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${x}"]${v}`))return;const g=document.createElement("link");if(g.rel=b?"stylesheet":de,b||(g.as="script",g.crossOrigin=""),g.href=x,d&&g.setAttribute("nonce",d),document.head.appendChild(g),b)return new Promise((O,j)=>{g.addEventListener("load",O),g.addEventListener("error",()=>j(new Error(`Unable to preload CSS for ${x}`)))})}))}return e.then(()=>o()).catch(r=>{const d=new Event("vite:preloadError",{cancelable:!0});if(d.payload=r,window.dispatchEvent(d),!d.defaultPrevented)throw r})};function i(t,o){return o||(o=t.slice(0)),Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(o)}}))}const pe="/assets/logo-fundo-azul-CVrwm-yG.png";var $,R,q,D,H,N,V,G,U,Q,W,Y;A.add(Sn.faBars,Mn.faTimes);const xe=a.nav($||($=i([`
  background: #00508c;
  padding: 0.5rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  z-index: 10;
`]))),he=a.img(R||(R=i([`
  height: 50px;
`]))),ue=a.div(q||(q=i([`
  display: flex;
  align-items: center;

  @media screen and (max-width: 1040px) {
    display: none;
  }
`]))),y=a.div(D||(D=i([`
  position: relative;
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 0 1rem;
  cursor: pointer;
  transition: color 0.3s;
  white-space: nowrap;

  &:hover {
    color: #fac800;
  }

  @media screen and (max-width: 1200px) {
    font-size: 1rem;
  }

  & > a {
    color: inherit;
    text-decoration: none;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`]))),z=a.div(H||(H=i([`
  display: `,`;
  position: absolute;
  top: 100%;
  left: 0;
  background: #00508c;
  padding: 1rem;
  border-radius: 5px;
  z-index: 20;

  & a {
    display: block;
    color: white;
    margin: 0.5rem 0;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`])),t=>{let{$isOpen:o}=t;return o?"block":"none"}),ge=a(l)(N||(N=i([`
  background: #28a745;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  margin-left: 1rem;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #218838;
  }
`]))),fe=a.div(V||(V=i([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: block;
    color: white;
    font-size: 1.8rem;
    cursor: pointer;
    z-index: 11; /* Ensure it is above the mobile menu */
  }
`]))),be=a.div(G||(G=i([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: `,`;
    flex-direction: column;
    align-items: center;
    position: absolute;
    top: 70px;
    left: 0;
    width: 100%;
    background: #00508c;
    padding: 1rem 0;
    z-index: 9;
  }
`])),t=>{let{$isOpen:o}=t;return o?"flex":"none"}),S=a.div(U||(U=i([`
  width: 100%;
  text-align: center;
`]))),w=a(l)(Q||(Q=i([`
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 1rem 0;
  cursor: pointer;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),m=a(l)(W||(W=i([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),P=a.div(Y||(Y=i([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),je=()=>{const[t,o]=c.useState(!1),[s,p]=c.useState(""),e=()=>{t==!0&&p(""),o(!t)},r=d=>{p(s===d?"":d)};return n.jsxs(xe,{children:[n.jsx(l,{to:"/",children:n.jsx(he,{src:pe,alt:"Logo"})}),n.jsx(fe,{onClick:e,children:n.jsx(_,{icon:t?Mn.faTimes:Sn.faBars})}),n.jsxs(ue,{children:[n.jsxs(y,{onMouseEnter:()=>p("quemSomos"),onMouseLeave:()=>p(""),onClick:()=>r("quemSomosMobile"),children:["Quem Somos",n.jsxs(z,{$isOpen:s==="quemSomos"||s==="quemSomosMobile",children:[n.jsx(l,{to:"/institucional",children:"Institucional"}),n.jsx(l,{to:"/estrutura",children:"Estrutura"}),n.jsx(l,{to:"/filiacao",children:"Filiação"}),n.jsx(l,{to:"/memoria",children:"Memória Institucional"})]})]}),n.jsxs(y,{onMouseEnter:()=>p("oQueFazemos"),onMouseLeave:()=>p(""),onClick:()=>r("oQueFazemosMobile"),children:["O Que Fazemos",n.jsxs(z,{$isOpen:s==="oQueFazemos"||s==="oQueFazemosMobile",children:[n.jsx(l,{to:"/eixos",children:"Eixos de Atuação"}),n.jsx(l,{to:"/acoes",children:"Ações e Temáticas"}),n.jsx(l,{to:"/eventos",children:"Eventos e Workshops"})]})]}),n.jsxs(y,{onMouseEnter:()=>p("mobilidade"),onMouseLeave:()=>p(""),onClick:()=>r("mobilidadeMobile"),children:["Intercâmbios",n.jsxs(z,{$isOpen:s==="mobilidade"||s==="mobilidadeMobile",children:[n.jsx(l,{to:"/intercambio_nacional",children:"Intercâmbios Nacionais"}),n.jsx(l,{to:"/intercambio_internacional",children:"Intercâmbios Internacionais"}),n.jsx(l,{to:"/regulamento",children:"Regulamento de Intercâmbios"}),n.jsx(l,{to:"/outras-modalidades",children:"Outras Modalidades de Intercâmbio"}),n.jsx(l,{to:"/social-programs",children:"Social Programs"})]})]}),n.jsxs(y,{onMouseEnter:()=>p("midias"),onMouseLeave:()=>p(""),onClick:()=>r("midiasMobile"),children:["Mídias e Documentos",n.jsxs(z,{$isOpen:s==="midias"||s==="midiasMobile",children:[n.jsx(l,{to:"/arquivos/ressonancia-poetica",children:"Ressonância Poética"}),n.jsx(l,{to:"/arquivos/informa-susi",children:"Informa SUSi"}),n.jsx(l,{to:"/arquivos/bms",children:"Brazilian Medical Students"}),n.jsx(l,{to:"/arquivos/relatorios",children:"Relatórios"}),n.jsx(l,{to:"/arquivos/notas-de-posicionamento",children:"Notas de Posicionamento"}),n.jsx(l,{to:"/arquivos/declaracoes-de-politica",children:"Declarações de Política"}),n.jsx(l,{to:"/arquivos/intercambio-nacional",children:"Intercâmbio Nacional"}),n.jsx(l,{to:"/arquivos/intercambio-internacional",children:"Intercâmbio Internacional"}),n.jsx(l,{to:"/arquivos/regulamento-intercambios",children:"Regulamento de Intercâmbios"})]})]}),n.jsx(y,{children:n.jsx(l,{to:"/noticias",children:"Notícias"})}),n.jsxs(y,{onMouseEnter:()=>p("membros"),onMouseLeave:()=>p(""),onClick:()=>r("membrosMobile"),children:["Membros",n.jsxs(z,{$isOpen:s==="membros"||s==="membrosMobile",children:[n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"}),n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"}),n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})]})]}),n.jsx(ge,{to:"/filie-se",children:"FILIE-SE"})]}),n.jsxs(be,{$isOpen:t,children:[n.jsxs(S,{children:[n.jsx(w,{onClick:()=>r("quemSomosMobile"),children:"Quem Somos"}),s==="quemSomosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/institucional",onClick:e,children:"Institucional"}),n.jsx(m,{to:"/estrutura",onClick:e,children:"Estrutura"}),n.jsx(m,{to:"/filiacao",onClick:e,children:"Filiação"}),n.jsx(m,{to:"/memoria",onClick:e,children:"Memória Institucional"})]})]}),n.jsxs(S,{children:[n.jsx(w,{onClick:()=>r("oQueFazemosMobile"),children:"O Que Fazemos"}),s==="oQueFazemosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/eixos",onClick:e,children:"Eixos de Atuação"}),n.jsx(m,{to:"/acoes",onClick:e,children:"Ações e Temáticas"}),n.jsx(m,{to:"/eventos",onClick:e,children:"Eventos e Workshops"})]})]}),n.jsxs(S,{children:[n.jsx(w,{onClick:()=>r("mobilidadeMobile"),children:"Intercâmbios"}),s==="mobilidadeMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/intercambio_nacional",onClick:e,children:"Intercâmbios Nacionais"}),n.jsx(m,{to:"/intercambio_internacional",onClick:e,children:"Intercâmbios Internacionais"}),n.jsx(m,{to:"/regulamento",onClick:e,children:"Regulamento de Intercâmbios"}),n.jsx(m,{to:"/outras-modalidades",onClick:e,children:"Outras Modalidades de Intercâmbio"}),n.jsx(m,{to:"/social-programs",onClick:e,children:"Social Programs"})]})]}),n.jsxs(S,{children:[n.jsx(w,{onClick:()=>r("midiasMobile"),children:"Mídias e Documentos"}),s==="midiasMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/arquivos/ressonancia-poetica",onClick:e,children:"Ressonância Poética"}),n.jsx(m,{to:"/arquivos/informa-susi",onClick:e,children:"Informa SUSi"}),n.jsx(m,{to:"/arquivos/bms",onClick:e,children:"Brazilian Medical Students"}),n.jsx(m,{to:"/arquivos/relatorios",onClick:e,children:"Relatórios"}),n.jsx(m,{to:"/arquivos/notas-de-posicionamento",onClick:e,children:"Notas de Posicionamento"}),n.jsx(m,{to:"/arquivos/declaracoes-de-politica",onClick:e,children:"Declarações de Política"}),n.jsx(m,{to:"/arquivos/intercambio-nacional",onClick:e,children:"Intercâmbio Nacional"}),n.jsx(m,{to:"/arquivos/intercambio-internacional",onClick:e,children:"Intercâmbio Internacional"}),n.jsx(m,{to:"/arquivos/regulamento-intercambios",onClick:e,children:"Regulamento de Intercâmbios"})]})]}),n.jsx(w,{to:"/noticias",onClick:e,children:"Notícias"}),n.jsxs(S,{children:[n.jsx(w,{onClick:()=>r("membrosMobile"),children:"Membros"}),s==="membrosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(P,{onClick:e,children:n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"})}),n.jsx(P,{onClick:e,children:n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"})}),n.jsx(P,{onClick:e,children:n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})})]})]}),n.jsx(w,{to:"/filie-se",onClick:e,children:"FILIE-SE"})]})]})};var X;const ve=()=>Wn(Xn,{styles:Yn(X||(X=i([`
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap");

      html,
      body,
      body1,
      #root,
      #__next {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif !important;
        background-color: #f0f0f0;
        color: rgba(0, 0, 0, 0.87);
        font-weight: 400;
        font-size: 1rem;
        line-height: 1.5;
        letter-spacing: 0.00938em;
      }

      *,
      *::before,
      *::after {
        box-sizing: inherit;
      }

      a {
        text-decoration: none;
        color: inherit;
      }

      h1,
      h6,
      h2 {
        margin: 0;
      }

      button {
        outline: none;
      }

      .carousel-container {
        max-width: 1200px;
        margin: 0 auto;
      }

      .carousel .slide {
        background: none;
      }

      /* CSS for BrazilMap component */
      .container {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: flex-start;
        width: 100%;
        margin: 0;
        padding: 20px;
        box-sizing: border-box;
      }

      .map-container {
        flex: 1;
        min-width: 300px;
        max-width: 600px;
        margin: 0 20px; /* Medium margin on the left and right sides */
      }

      .legend-container {
        display: flex;
        flex-direction: column;
        margin-left: 20px;
      }

      .legend-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
      }

      .color-box {
        width: 20px;
        height: 20px;
        margin-right: 10px;
      }

      /* Media query for mobile view */
      @media (max-width: 768px) {
        .container {
          flex-direction: column;
          align-items: center;
        }
        .map-container {
          margin: 0; /* Remove margins on mobile */
        }
        .legend-container {
          flex-direction: row;
          flex-wrap: wrap;
          justify-content: center;
          margin-left: 0;
          margin-top: 20px; /* Space between map and legend */
        }
        .legend-item {
          margin: 5px; /* Adjust margin for horizontal layout */
        }
      }
    `])))});var J;Hn(J||(J=i([`
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

  body {
    font-family: 'Poppins', sans-serif;
  }
`])));A.add(Nn.faTwitter,Vn.faInstagram,Gn.faMapMarkerAlt,Un.faEnvelope,Qn.faPhone);const we=C("footer")({backgroundColor:"#00508C",color:"white",padding:"20px 0",textAlign:"center"}),I=C("div")({display:"flex",alignItems:"center",margin:"5px 0",justifyContent:"center","& svg":{marginRight:"10px"}}),_e=C("div")({marginTop:"10px"}),K=C(Jn)({color:"white",margin:"0 10px",fontSize:"1.5rem",transition:"color 0.3s","&:hover":{color:"#FAC800"}}),ye=()=>n.jsx(we,{children:n.jsx(F,{maxWidth:"lg",children:n.jsxs(k,{container:!0,spacing:4,children:[n.jsxs(k,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Endereço"}),n.jsxs(I,{children:[n.jsx(_,{icon:"map-marker-alt"}),n.jsx(f,{variant:"body1",children:"Avenida Paulista nº 1765 - 7º Andar"})]}),n.jsx(f,{variant:"body1",children:"Boa Vista, São Paulo/SP - Brasil"})]}),n.jsxs(k,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Contato"}),n.jsxs(I,{children:[n.jsx(_,{icon:"envelope"}),n.jsx(f,{variant:"body1",children:"atendimento@ifmsabrazil.org"})]}),n.jsxs(I,{children:[n.jsx(_,{icon:"phone"}),n.jsx(f,{variant:"body1",children:"Tel: + 55 11 3170-3251"})]})]}),n.jsxs(k,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Siga-nos"}),n.jsxs(_e,{children:[n.jsx(K,{href:"https://twitter.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(_,{icon:["fab","twitter"]})}),n.jsx(K,{href:"https://instagram.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(_,{icon:["fab","instagram"]})})]})]})]})})}),ke=C(F)({display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh"}),Ce=C(f)({marginTop:"16px",color:"#00508C"}),$n=()=>n.jsxs(ke,{children:[n.jsx(Kn,{}),n.jsx(Ce,{variant:"h6",children:"Carregando..."})]});var Z,nn,en,tn,on;const Oe=zn(Z||(Z=i([`
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
`]))),Ee=zn(nn||(nn=i([`
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.8);
  }
`]))),ze=a.div(en||(en=i([`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #00508c;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  cursor: pointer;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease-in-out;
  z-index: 1000;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 46px;
    height: 46px;
  }
`]))),Se=a.div(tn||(tn=i([`
  position: fixed;
  bottom: 80px;
  right: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 1000;
  transition: all 0.2s ease-in-out;
  animation: `,` 0.2s forwards;

  @media (max-width: 768px) {
    bottom: 76px;
    right: 16px;
  }
`])),t=>t.isOpen?Oe:Ee),rn=a.a(on||(on=i([`
  color: #00508c;
  text-decoration: none;
  display: flex;
  align-items: center;
  padding: 8px 0;
  width: 100%;
  transition: all 0.2s ease-in-out;

  &:hover {
    color: #003366;
  }

  svg {
    margin-right: 10px;
  }
`]))),Me=()=>{const[t,o]=c.useState(!1),s=()=>{o(!t)};return n.jsxs(n.Fragment,{children:[n.jsx(ze,{onClick:s,children:t?n.jsx(ae,{size:24}):n.jsx(L,{size:24})}),t&&n.jsxs(Se,{isOpen:t,children:[n.jsxs(rn,{href:"mailto:atendimento@ifmsabrazil.org",children:[n.jsx(L,{size:20}),"atendimento@ifmsabrazil.org"]}),n.jsxs(rn,{href:"https://instagram.com/ifmsabrazil",target:"_blank",children:[n.jsx(se,{size:20}),"@ifmsabrazil"]})]})]})};var an,sn,ln,cn,dn,mn;const Pe=a.section(an||(an=i([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #FFFFFF;
  text-align: center;
`]))),Ie=a.h2(sn||(sn=i([`
  font-family: 'Poppins', sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Ae=a.div(ln||(ln=i([`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
`]))),Fe=a.div(cn||(cn=i([`
  flex: 1 1 30%;
  max-width: 30%;
  display: flex;
  justify-content: center;

  @media (max-width: 991px) {
    flex: 1 1 45%;
    max-width: 45%;
  }

  @media (max-width: 600px) {
    flex: 1 1 100%;
    max-width: 100%;
  }
`]))),Le=a.div(dn||(dn=i([`
  position: relative;
  height: auto;
  font-family: 'Poppins', sans-serif;
  color: rgba(255, 255, 255, 1);
  text-align: center;
  background-color: `,`;
  flex-grow: 1;
  width: 100%;
  align-self: stretch;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`])),t=>t.bgColor),Te=a.div(mn||(mn=i([`
  font-size: 24px;
`])));function Be(){const t=[{id:1,bgColor:"rgba(0, 80, 140, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Em 26 Estados"}),n.jsx("br",{}),n.jsx("strong",{children:"+ Distrito Federal"})]})},{id:2,bgColor:"rgba(250, 200, 0, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Temos +11000"}),n.jsx("br",{}),n.jsx("strong",{children:"membros filiados"})]})},{id:3,bgColor:"rgba(0, 150, 60, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Presentes em +220"}),n.jsx("br",{}),n.jsx("strong",{children:"escolas médicas"})]})}];return n.jsxs(Pe,{children:[n.jsx(Ie,{children:"Nossa abrangência"}),n.jsx(Ae,{children:t.map(o=>n.jsx(Fe,{children:n.jsx(Le,{bgColor:o.bgColor,children:n.jsx(Te,{children:o.text})})},o.id))})]})}var pn,xn,hn,un,gn;A.add(Pn.faBook,In.faGraduationCap,An.faHandsHelping,Fn.faHeartbeat,Ln.faHospital,Tn.faUniversity,Bn.faSearch);const $e=a.section(pn||(pn=i([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
  text-align: center;
`]))),Re=a.h2(xn||(xn=i([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),qe=a.div(hn||(hn=i([`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 20px;
  justify-content: center;

  @media (max-width: 991px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    & > :nth-child(5) {
      grid-column: span 2;
    }
  }
`]))),De=a.div(un||(un=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: `,`;
  color: `,`;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
  font-family: "Poppins", sans-serif;
  text-align: center;
  border: `,`;

  &:hover {
    transform: translateY(-10px);
  }
`])),t=>t.bgColor,t=>t.color||"rgba(255, 255, 255, 1)",t=>t.border||"none"),He=a.div(gn||(gn=i([`
  font-size: 18px;
  margin-top: 10px;
`])));function Ne(){const t=[{id:1,bgColor:"rgba(182, 120, 38, 1)",text:"Representatividade estudantil",icon:In.faGraduationCap},{id:2,bgColor:"rgba(0, 0, 0, 1)",text:"Capacity Building",icon:Pn.faBook},{id:3,bgColor:"#FFFFFF",text:"Educação Médica",icon:Ln.faHospital,color:"#000",border:"2px solid #000"},{id:4,bgColor:"rgba(220, 0, 0, 1)",text:"Promoção de Saúde",icon:Fn.faHeartbeat},{id:5,bgColor:"rgba(0, 150, 60, 1)",text:"Humanização",icon:An.faHandsHelping},{id:6,bgColor:"rgba(0, 80, 140, 1)",text:"Mobilidade Estudantil",icon:Tn.faUniversity},{id:7,bgColor:"rgba(128, 128, 128, 1)",text:"Pesquisa e Extensão",icon:Bn.faSearch}];return n.jsxs($e,{children:[n.jsx(Re,{children:"Nossos eixos de atuação"}),n.jsx(qe,{children:t.map(o=>n.jsxs(De,{bgColor:o.bgColor,color:o.color,border:o.border,children:[n.jsx(_,{icon:o.icon,size:"3x"}),n.jsx(He,{children:o.text})]},o.id))})]})}var fn,bn;const Ve=a(Zn)(fn||(fn=i([`
  display: flex;
  flex-direction: column;
  margin: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
  border-radius: 10px;

  &:hover {
    transform: translateY(-5px);
  }

  @media (min-width: 600px) {
    flex-direction: row;
  }
`]))),Ge=a(ne)(bn||(bn=i([`
  width: 100%;
  height: auto;

  @media (min-width: 600px) {
    width: 160px !important;
    height: auto;
    object-fit: cover;
    margin-left: auto;
  }
`]))),Ue=t=>{let{post:o}=t;return n.jsxs(Ve,{children:[n.jsxs(ee,{style:{flex:1},children:[n.jsx(f,{component:"h2",variant:"h5",gutterBottom:!0,children:o.title}),n.jsx(f,{variant:"subtitle1",color:"text.secondary",children:o.author}),n.jsx(f,{variant:"subtitle2",color:"text.secondary",gutterBottom:!0,children:o.date?new Date(o.date).toLocaleDateString():""}),n.jsx(f,{variant:"body1",paragraph:!0,children:o.summary})]}),n.jsx(Ge,{component:"img",image:o.imageLink,alt:"Blog image"})]})},Qe={ç:"c",Ç:"C",á:"a",Á:"A",é:"e",É:"E",í:"i",Í:"I",ó:"o",Ó:"O",ú:"u",Ú:"U",à:"a",À:"A",ã:"a",Ã:"A",õ:"o",Õ:"O"},We=t=>t.split("").map(o=>Qe[o]||o).join(""),Ye=t=>We(t).toLowerCase().replace(/[^a-z0-9]+/g,"-");var jn,vn;const Xe=a.section(jn||(jn=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
`]))),Je=a.h2(vn||(vn=i([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Ke=t=>{let{posts:o,loading:s}=t;if(s)return n.jsx($n,{});const p=d=>d.sort((x,b)=>b["dia-mes-ano"]-x["dia-mes-ano"]),r=function(d){let x=arguments.length>1&&arguments[1]!==void 0?arguments[1]:4;const b=p(d),v=b.filter(j=>j["forcar-pagina-inicial"]);if(v.length>=x)return v;const g=b.filter(j=>!j["forcar-pagina-inicial"]);return v.concat(g.slice(0,x-v.length))}(o);return n.jsxs(Xe,{children:[n.jsx(Je,{children:"Últimas Notícias"}),n.jsx(F,{maxWidth:"lg",children:n.jsx(k,{container:!0,spacing:4,children:r.map((d,x)=>n.jsx(k,{item:!0,xs:12,sm:6,children:n.jsx(l,{to:"/arquivo/".concat(d.id,"/").concat(Ye(d.title)),children:n.jsx(Ue,{post:d})})},x))})})]})},Ze="/assets/background-image-YkmHsWZG.webp";var wn,_n,yn,kn,Cn,On;const nt=c.lazy(()=>u(()=>import("./Alert-DqVYityC.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]))),et=a.div(wn||(wn=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  overflow: hidden;
`]))),tt=a.div(_n||(_n=i([`
  width: 100%;
  height: 100vh;
  background-image: url(`,`);
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  text-align: center;
  padding: 20px;
  background-color: rgba(0, 0, 0, 0.5);
`])),Ze),ot=a.h1(yn||(yn=i([`
  font-size: 3rem;
  font-weight: 700;
  padding: 0 20px;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
`]))),it=a.button(kn||(kn=i([`
  margin-top: 20px;
  padding: 12px 24px;
  font-size: 1rem;
  font-weight: bold;
  color: #00508c;
  background-color: #fac800;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: translateY(-3px);
    background-color: #e6b800;
    color: #004080;
  }
`]))),rt=a.button(Cn||(Cn=i([`
  position: fixed;
  bottom: 20px;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: white;
  border: none;
  cursor: pointer;
  display: `,`;
  justify-content: center;
  align-items: center;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
  }

  svg {
    width: 24px;
    height: 24px;
    fill: #00508c;
  }
`])),t=>{let{show:o}=t;return o?"flex":"none"}),at=a.div(On||(On=i([`
  width: 100%;
  padding: 60px 20px;
  background-color: white;
  text-align: center;
  color: #333;

  h2 {
    font-size: 2rem;
    margin-bottom: 20px;
  }

  p {
    max-width: 800px;
    margin: 0 auto;
    line-height: 1.6;
  }
`]))),st=()=>{const[t,o]=c.useState([]),[s,p]=c.useState(null),[e,r]=c.useState(!0),[d,x]=c.useState(!0),b="https://api.ifmsabrazil.org/api/blogs/recent";c.useEffect(()=>{(async()=>{try{const j=await re.get(b),{recentBlogs:M,alert:E}=j.data;o(M),E&&E.toggleDate&&le(new Date,{start:T(E.dateStart),end:T(E.dateEnd)})&&p(E)}catch(j){console.error("Error fetching posts:",j)}finally{r(!1)}})()},[]);const v=()=>{const O=window.scrollY,M=window.innerHeight*.7;O<M?x(!0):x(!1)},g=()=>{window.scrollTo({top:window.innerHeight,behavior:"smooth"})};return c.useEffect(()=>(window.addEventListener("scroll",v),()=>{window.removeEventListener("scroll",v)}),[]),n.jsxs(et,{children:[s&&n.jsx(nt,{toggleMessage:s.toggleMessage,message:s.message,toggleButton:s.toggleButton,buttonText:s.buttonText,buttonUrl:s.buttonUrl,title:s.title}),n.jsxs(tt,{children:[n.jsx(ot,{children:"Estudantes de medicina que fazem a diferença"}),n.jsx(it,{children:"Faça parte"}),n.jsx(rt,{show:d,onClick:g,children:n.jsx("svg",{viewBox:"0 0 24 24",children:n.jsx("path",{d:"M12 16.5l-7-7 1.41-1.41L12 13.67l5.59-5.58L19 9.5l-7 7z"})})})]}),n.jsxs(at,{children:[n.jsx("h2",{children:"Breve Introdução"}),n.jsx("p",{children:"Fundada em 1991 como primeira associação da América Latina vinculada à International Federation of Medical Students’ Association (IFMSA), a IFMSA Brazil interliga estudantes de medicina de todo o país para fazer a diferença na sociedade e na formação médica."})]}),n.jsx(Be,{}),n.jsx(Ne,{}),n.jsx(Ke,{posts:t,loading:e}),n.jsx(Me,{})]})},lt=te({typography:{fontFamily:"Poppins, Arial, sans-serif"},components:{MuiCssBaseline:{styleOverrides:`
        @font-face {
          font-family: 'Poppins';
          font-style: normal;
          font-display: swap;
          font-weight: 400;
          src: local('Poppins'), local('Poppins-Regular'), url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap') format('woff2');
          unicodeRange: U+0000-00FF; /* Latin characters */
        }
      `}}}),En=c.lazy(()=>u(()=>import("./MarkdownPage-D9-5jk0L.js"),__vite__mapDeps([21,1,2,22,18,23,14,15,16,5,6,17,7,8,10,11,9,3,4,12,13,19,20,24]))),ct=c.lazy(()=>u(()=>import("./GeradorLink-BvzLFz8y.js"),__vite__mapDeps([25,1,2,14,15,16,5,6,17,7,8]))),dt=c.lazy(()=>u(()=>import("./Arquivos-BieBkdgD.js"),__vite__mapDeps([26,1,2,3,4,5,6,18,27,12,13,14,15,16,17,7,8,10,11,9,19,20]))),mt=c.lazy(()=>u(()=>import("./Estrutura-BRFEcKm-.js"),__vite__mapDeps([28,1,2,18,29,30,14,15,16,5,6,17,7,8,31,13,32,33,34,35,22,23,24,9,10,11,3,4,12,19,20]))),pt=c.lazy(()=>u(()=>import("./Filiacao-Dv-1O0k5.js"),__vite__mapDeps([36,1,2,3,4,5,6,19,14,15,16,17,7,8,18,37,35,22,23,24,9,10,11,12,13,20]))),xt=c.lazy(()=>u(()=>import("./NotFound-EybCYkNE.js"),__vite__mapDeps([38,1,2,3,4,5,6,9,7,8,10,11,12,13,14,15,16,17,18,19,20]))),ht=c.lazy(()=>u(()=>import("./Noticias-U5XFGmFr.js"),__vite__mapDeps([39,1,2,3,4,5,6,9,7,8,10,11,27,12,13,14,15,16,17,18,19,20]))),ut=c.lazy(()=>u(()=>import("./Institucional-D6iabtNm.js"),__vite__mapDeps([40,1,2,35,22,23,14,15,16,5,6,17,7,8,24,9,10,11,3,4,12,13,18,19,20]))),gt=c.lazy(()=>u(()=>import("./AcoesETematicas-BJj1DtY3.js"),__vite__mapDeps([41,1,2,35,22,23,14,15,16,5,6,17,7,8,24,9,10,11,3,4,12,13,18,19,20]))),ft=c.lazy(()=>u(()=>import("./SocialPrograms-C8eNm8OA.js"),__vite__mapDeps([42,1,2,35,22,23,14,15,16,5,6,17,7,8,24,9,10,11,3,4,12,13,18,19,20]))),bt=c.lazy(()=>u(()=>import("./Eixos-DU6QpDWR.js"),__vite__mapDeps([43,1,2,35,22,23,14,15,16,5,6,17,7,8,24,9,10,11,3,4,12,13,18,19,20]))),jt=c.lazy(()=>u(()=>import("./Eventos-r2qjtqXW.js"),__vite__mapDeps([44,1,2,35,22,23,14,15,16,5,6,17,7,8,24,9,10,11,3,4,12,13,18,19,20]))),vt=c.lazy(()=>u(()=>import("./Regulamento-B2PUvoij.js"),__vite__mapDeps([45,1,2,35,22,23,14,15,16,5,6,17,7,8,24]))),wt=c.lazy(()=>u(()=>import("./IntercambioNacional--hY0w_YM.js"),__vite__mapDeps([46,1,2,35,22,23,14,15,16,5,6,17,7,8,24]))),_t=()=>n.jsx(oe,{theme:lt,children:n.jsxs(Dn,{children:[n.jsx(ve,{}),n.jsx(ie,{}),n.jsx(je,{}),n.jsx(c.Suspense,{fallback:n.jsx($n,{}),children:n.jsxs(ce,{children:[n.jsx(h,{path:"/",element:n.jsx(st,{})}),n.jsx(h,{path:"/arquivo/:id/:title",element:n.jsx(En,{needsExternal:!0})}),n.jsx(h,{path:"/gerarlink",element:n.jsx(ct,{})}),n.jsx(h,{path:"/estrutura",element:n.jsx(mt,{})}),n.jsx(h,{path:"/filiacao",element:n.jsx(pt,{})}),n.jsx(h,{path:"/noticias",element:n.jsx(ht,{})}),n.jsx(h,{path:"/institucional",element:n.jsx(ut,{})}),n.jsx(h,{path:"/acoes",element:n.jsx(gt,{})}),n.jsx(h,{path:"/arquivos/:type",element:n.jsx(dt,{})}),n.jsx(h,{path:"/social-programs",element:n.jsx(ft,{})}),n.jsx(h,{path:"/eixos",element:n.jsx(bt,{})}),n.jsx(h,{path:"/eventos",element:n.jsx(jt,{})}),n.jsx(h,{path:"/regulamento",element:n.jsx(vt,{})}),n.jsx(h,{path:"/intercambio_nacional",element:n.jsx(wt,{})}),n.jsx(h,{path:"/tutorial",element:n.jsx(En,{needsExternal:!1,filepath:"/markdown/pagina.md"})}),n.jsx(h,{path:"*",element:n.jsx(xt,{})})," "]})}),n.jsx(ye,{})]})}),yt=document.getElementById("root"),kt=qn(yt);kt.render(n.jsx(Rn.StrictMode,{children:n.jsx(_t,{})}));export{$n as L,i as _,u as a,Ye as g};
