import{_ as a}from"./index-DgOVNqud.js";import{j as t}from"./react-DaPl5ws4.js";import{p as i}from"./styled-components-BD7m8TR7.js";import{F as m,p as c}from"./@fortawesome-BOOXKGIM.js";import{l as s,A as p,T as o}from"./@mui-D3p2DSY1.js";var r,n;const d=i(s)(r||(r=a([`
  display: flex;
  align-items: center;
  padding: 15px 20px;
  border-bottom: 1px solid #eee;
  transition: background-color 0.3s;

  &:hover {
    background-color: #f5f5f5;
  }
`]))),x=i(s)(n||(n=a([`
  display: flex;
  flex-direction: column;
  flex: 1;
  margin-left: 20px;
`]))),b=l=>{let{post:e}=l;return t.jsxs(d,{children:[t.jsx(p,{src:e.imageLink,variant:"square",style:{width:80,height:80,borderRadius:"8px"}}),t.jsxs(x,{children:[t.jsx(o,{component:"h2",variant:"h6",gutterBottom:!0,style:{fontWeight:"bold",marginBottom:"0em"},children:e.title}),t.jsx(o,{variant:"subtitle1",color:"text.secondary",style:{fontSize:"0.875rem"},children:e.author}),t.jsx(o,{variant:"subtitle2",color:"text.secondary",gutterBottom:!0,style:{fontSize:"0.875rem"},children:e.date?new Date(e.date).toLocaleDateString("en-GB",{timeZone:"UTC"}):""}),t.jsx(o,{variant:"body2",paragraph:!0,style:{fontSize:"0.875rem"},children:e.summary})]}),e.forceHomePage&&t.jsx(m,{icon:c,style:{color:"#FAC800",marginLeft:"auto",fontSize:"1.5em"}})]})};export{b as B};
