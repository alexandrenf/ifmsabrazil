import{_ as t}from"./index-CvURy38U.js";import{r as j,j as n}from"./react-DaPl5ws4.js";import{p as e}from"./styled-components-CIxqPc4V.js";import"./react-dom-CWF6clnO.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-BFBG7k2k.js";import"./react-router-B_WJkAv4.js";import"./@remix-run-B-RBrVrq.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./webfontloader-ozkfuRsT.js";import"./@mui-BqBmPETx.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";import"./axios-B4uVmeYG.js";import"./react-icons-vpqwEHyG.js";import"./date-fns-X50TK9oK.js";import"./tslib-wbdO-F7s.js";var r,i,s,l,a,m,p;function V(o){let{message:c,title:d,buttonUrl:u,buttonText:g,toggleButton:h,toggleMessage:x}=o;const[b,f]=j.useState(!0);return b?n.jsx(v,{children:n.jsxs(w,{children:[n.jsxs(O,{onClick:()=>f(!1),children:[n.jsx(k,{}),n.jsx("span",{className:"sr-only",children:"Close"})]}),n.jsxs(_,{children:[n.jsx(y,{children:d}),x?n.jsx(C,{children:c}):null,h?n.jsx(L,{to:u,children:g}):null]})]})}):null}function k(o){return n.jsxs("svg",{...o,xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[n.jsx("path",{d:"M18 6 6 18"}),n.jsx("path",{d:"m6 6 12 12"})]})}const v=e.div(r||(r=t([`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`]))),w=e.div(i||(i=t([`
  background-color: hsl(142, 86%, 28%);
  padding: 2rem 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  max-width: 42rem;
  position: relative;
`]))),O=e.button(s||(s=t([`
  position: absolute;
  top: 1rem;
  right: 1rem;
  color: hsl(356, 29%, 98%);
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 0.25rem;

  &:hover {
    color: rgba(356, 29%, 98%, 0.8);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`]))),_=e.div(l||(l=t([`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`]))),y=e.h2(a||(a=t([`
  font-size: 1.875rem;
  font-weight: bold;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1rem;
`]))),C=e.p(m||(m=t([`
  font-size: 1.125rem;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1.5rem;
`]))),L=e.a(p||(p=t([`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem 1.5rem;
  border-radius: 0.25rem;
  background-color: hsl(356, 29%, 98%);
  color: hsl(142, 86%, 28%);
  font-weight: 500;
  text-decoration: none;

  &:hover {
    background-color: rgba(356, 29%, 98%, 0.9);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`])));export{V as default};
