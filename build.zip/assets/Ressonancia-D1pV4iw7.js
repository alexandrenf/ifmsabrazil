import{j as o}from"./react-DaPl5ws4.js";import{M as t}from"./MarkdownContent-CQ6Z632h.js";import{s as e,C as s,T as a}from"./@mui-BqBmPETx.js";import"./@babel-CNkBngnk.js";import"./markdown-to-jsx-CXBEPAoT.js";import"./prismjs-DEnDlMkx.js";/* empty css                   */import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./react-transition-group-cLDJx4Bm.js";import"./react-dom-CWF6clnO.js";import"./scheduler-CzFDRTuY.js";const n=e(s)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),i=e(a)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),j=()=>o.jsxs(n,{children:[o.jsx(i,{variant:"h4",children:"Ressonância Poética"}),o.jsx(t,{content:`

Ressonância Poética é um periódico cultural de acesso aberto, ou seja, tem submissão e acesso gratuitos, é organizado por discentes, e tem intuito de celebrar a expressão artística por intermédio de artes dos seus pares. Dentre os seus valores, tem-se que  a valorização da pessoa, contemplando seus conhecimentos técnicos adquiridos na faculdade com extensão humanística de interesses e de habilidades. Acontece de maneira anual, com temáticas atuais e relevantes, aceitando submissões nas seguintes modalidades: prosa, poesia, fotografia e desenho.



`})]});export{j as default};
