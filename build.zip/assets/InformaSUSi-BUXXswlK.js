import{j as a}from"./react-DaPl5ws4.js";import{M as e}from"./MarkdownContent-DAA-hkp1.js";import{s as o,C as i,T as n}from"./@mui-Decc1woQ.js";import"./@babel-CNkBngnk.js";import"./markdown-to-jsx-CXBEPAoT.js";import"./prismjs-DEnDlMkx.js";/* empty css                   */import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./react-transition-group-cLDJx4Bm.js";import"./react-dom-CWF6clnO.js";import"./scheduler-CzFDRTuY.js";const r=o(i)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),t=o(n)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),h=()=>a.jsxs(r,{children:[a.jsx(t,{variant:"h4",children:"Informa SUSi"}),a.jsx(e,{content:`

A Informa SUSi é uma iniciativa do Comitê Permanente em Saúde Pública da IFMSA Brazil, encabeçada pelo Diretor Nacional de Saúde Pública e o Time Nacional de Saúde Pública. Ela não é uma revista indexada ou que garante certificado, apenas uma iniciativa de divulgação em tópicos interessantes para a saúde coletiva brasileira, ela é composta por três seções fundamentais: notícias em saúde pública, artigos de opinião em saúde pública e atividades em saúde pública. 

Começando durante a pandemia com edições mensais, a Informa SUSi hoje se transformou numa revista de lançamento trimestral, acompanhando o calendário de relatórios dos comitês locais.

Apesar de não fornecer certificado, a publicação na Informa SUSi aumenta a visibilidade do comitê local e do coordenador local escritor, permitindo um compilado do que há de melhor em saúde pública na nossa federação! =)


`})]});export{h as default};
