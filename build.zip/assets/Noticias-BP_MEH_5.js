import{_ as a,L as E,g as I}from"./index-CgisCFxu.js";import{r as i,j as e}from"./react-DaPl5ws4.js";import{p as l}from"./styled-components-D58U5FK1.js";import{L as z}from"./react-router-dom-BFBG7k2k.js";import{B as q}from"./BlogPostListItem-DSAPkrAp.js";import{a as G}from"./axios-B4uVmeYG.js";import{h as H,F as M,i as R,S as Z,O as N,M as U,j as V,L as W,k as J,B as p,l as y,D as K}from"./@mui-Decc1woQ.js";import"./react-dom-CWF6clnO.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./react-cookie-consent-xWEKRR8T.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./js-cookie-Cz0CWeBA.js";import"./react-icons-BQxfTaxZ.js";import"./date-fns-X50TK9oK.js";import"./react-router-B_WJkAv4.js";import"./@remix-run-B-RBrVrq.js";import"./tslib-wbdO-F7s.js";import"./stylis-DinRj2j6.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";var h,g,j,b,P,w;const Q=l.section(h||(h=a([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #f0f2f5;
`]))),X=l.h2(g||(g=a([`
  font-family: "Poppins", sans-serif;
  font-size: 2.5rem;
  color: #333;
  text-align: center;
  margin-bottom: 30px;
`]))),Y=l.div(j||(j=a([`
  width: 100%;
  max-width: 1200px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
`]))),$=l(y)(b||(b=a([`
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
`]))),tt=l(K)(P||(P=a([`
  margin: 0 20px;
`]))),et=l(y)(w||(w=a([`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 1200px;
`]))),At=()=>{const[d,v]=i.useState([]),[C,D]=i.useState(!0),[f,m]=i.useState("dateDesc"),[u,S]=i.useState(""),[c,A]=i.useState([]),[L,O]=i.useState([]),T="https://api.ifmsabrazil.org/api/blogs";i.useEffect(()=>{(async()=>{try{const o=(await G.get(T)).data;if(!Array.isArray(o))throw new Error("Posts data is not an array");v(o)}catch(s){console.error("Error fetching posts:",s)}finally{D(!1)}})()},[]),i.useEffect(()=>{O(F(d))},[d,f,u,c]);const k=(t,s)=>{const o=[...t];return s==="dateAsc"?o.sort((r,n)=>new Date(r.date)-new Date(n.date)):s==="dateDesc"?o.sort((r,n)=>new Date(n.date)-new Date(r.date)):s==="titleAsc"?o.sort((r,n)=>r.title.localeCompare(n.title)):s==="titleDesc"&&o.sort((r,n)=>n.title.localeCompare(r.title)),o},B=t=>t.filter(s=>{const o=s.title.toLowerCase().includes(u.toLowerCase()),r=c.length===0||c.includes(s.author);return o&&r}),F=t=>{const s=t.filter(x=>x.forceHomePage),o=t.filter(x=>!x.forceHomePage),r=k(o,f);return B([...s,...r])};if(C)return e.jsx(E,{});const _=[...new Set(d.map(t=>t.author))];return e.jsxs(Q,{children:[e.jsx(X,{children:"Últimas Publicações"}),e.jsxs(et,{children:[e.jsx(H,{label:"Buscar por Título",variant:"outlined",value:u,onChange:t=>S(t.target.value),style:{marginRight:"20px",flexGrow:1}}),e.jsxs(M,{variant:"outlined",style:{minWidth:200},children:[e.jsx(R,{children:"Filtrar por Autor"}),e.jsx(Z,{multiple:!0,value:c,onChange:t=>A(t.target.value),input:e.jsx(N,{label:"Filtrar por Autor"}),renderValue:t=>t.join(", "),children:_.map(t=>e.jsxs(U,{value:t,children:[e.jsx(V,{checked:c.indexOf(t)>-1}),e.jsx(W,{primary:t})]},t))})]})]}),e.jsx($,{children:e.jsxs(J,{variant:"outlined",color:"primary",children:[e.jsx(p,{onClick:()=>m("dateDesc"),children:"Data (mais recentes)"}),e.jsx(p,{onClick:()=>m("dateAsc"),children:"Data (mais antigas)"}),e.jsx(tt,{orientation:"vertical",flexItem:!0}),e.jsx(p,{onClick:()=>m("titleAsc"),children:"Título (A-Z)"}),e.jsx(p,{onClick:()=>m("titleDesc"),children:"Título (Z-A)"})]})}),e.jsx(Y,{children:L.map((t,s)=>e.jsx(z,{to:"/arquivo/".concat(t.id,"/").concat(I(t.title)),style:{textDecoration:"none"},children:e.jsx(q,{post:t})},s))})]})};export{At as default};
