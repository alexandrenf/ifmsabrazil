import{j as o}from"./react-CLPtFgDq.js";import{M as t}from"./MarkdownContent-BNKm4Bhr.js";import{s as e,C as s,T as a}from"./@mui-B86xCNSa.js";import"./@babel-f5lBRPU2.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */import"./clsx-B-dksMZM.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./react-transition-group-CLuBo2_z.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-is-DcfIKM1A.js";const n=e(s)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),i=e(a)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),v=()=>o.jsxs(n,{children:[o.jsx(i,{variant:"h4",children:"Ressonância Poética"}),o.jsx(t,{content:`

Ressonância Poética é um periódico cultural de acesso aberto, ou seja, tem submissão e acesso gratuitos, é organizado por discentes, e tem intuito de celebrar a expressão artística por intermédio de artes dos seus pares. Dentre os seus valores, tem-se que  a valorização da pessoa, contemplando seus conhecimentos técnicos adquiridos na faculdade com extensão humanística de interesses e de habilidades. Acontece de maneira anual, com temáticas atuais e relevantes, aceitando submissões nas seguintes modalidades: prosa, poesia, fotografia e desenho.



`})]});export{v as default};
