const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/MarkdownPage-nLq5mdB5.js","assets/react-CLPtFgDq.js","assets/@babel-f5lBRPU2.js","assets/markdown-to-jsx-hEv6XCia.js","assets/axios-B4uVmeYG.js","assets/prismjs-D-bn_D2K.js","assets/@mui-B86xCNSa.js","assets/clsx-B-dksMZM.js","assets/@emotion-B2RCLeMm.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/stylis-FDnFs_-n.js","assets/react-transition-group-CLuBo2_z.js","assets/react-dom-DvAKqnPy.js","assets/scheduler-CzFDRTuY.js","assets/react-is-DcfIKM1A.js","assets/react-router-BzRFIFMZ.js","assets/@remix-run-YI_hLLil.js","assets/react-router-dom-Am9psY4u.js","assets/styled-components-BY_vc4YD.js","assets/tslib-wbdO-F7s.js","assets/@fortawesome-B6QlLdFu.js","assets/prop-types-1yzuAbYU.js","assets/webfontloader-DM8E560Z.js","assets/react-icons-CrkDh4zl.js","assets/codeStyles-vPv1o2UF.css","assets/GeradorLink-Bzlx9Ywa.js","assets/Arquivos-D3fmdMlm.js","assets/BlogPostListItem-fzT5Mqpu.js","assets/Estrutura-474-cZHV.js","assets/react-multi-carousel-BkRiOElf.js","assets/react-multi-carousel-C0HCKJ4u.css","assets/react-simple-maps-DEBQupZu.js","assets/topojson-client-DzWSY_RA.js","assets/d3-geo-eEO7UCrt.js","assets/d3-array-BweefaKS.js","assets/MarkdownContent-DFTCqHCR.js","assets/Filiacao-BKbIrf0g.js","assets/papaparse-D8JlQIm0.js","assets/NotFound-DAL-nhLq.js","assets/Noticias-Du7CpX6z.js","assets/Institucional--BOt_96G.js","assets/AcoesETematicas-FMVCcO3o.js","assets/SocialPrograms-Vn48lVuO.js","assets/Eixos-xPAnHoHA.js","assets/Eventos-BLbt9DDk.js","assets/Regulamento-UQnp3bb4.js","assets/IntercambioNacional-BX76PIdf.js"])))=>i.map(i=>d[i]);
import{r as d,j as n,a as Ln}from"./react-CLPtFgDq.js";import{c as Tn}from"./react-dom-DvAKqnPy.js";import{L as l,B as $n}from"./react-router-dom-Am9psY4u.js";import{p as a,h as Bn,f as kn}from"./styled-components-BY_vc4YD.js";import{l as I,f as Cn,a as En,F as y,b as Rn,c as qn,d as Dn,e as Hn,g as Nn,h as On,i as zn,j as Sn,k as Mn,m as In,n as Pn,o as An}from"./@fortawesome-B6QlLdFu.js";import{W as Vn}from"./webfontloader-DM8E560Z.js";import{s as E,I as Gn,C as P,G as C,T as f,a as Qn,b as Un,c as Wn,d as Yn,e as Xn}from"./@mui-B86xCNSa.js";import{a as Jn}from"./axios-B4uVmeYG.js";import{F as Kn,a as A,b as Zn}from"./react-icons-CrkDh4zl.js";import{d as ne,e as h}from"./react-router-BzRFIFMZ.js";import"./@babel-f5lBRPU2.js";import"./scheduler-CzFDRTuY.js";import"./@remix-run-YI_hLLil.js";import"./tslib-wbdO-F7s.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./prop-types-1yzuAbYU.js";import"./clsx-B-dksMZM.js";import"./react-transition-group-CLuBo2_z.js";import"./react-is-DcfIKM1A.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))x(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const c of r.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&x(c)}).observe(document,{childList:!0,subtree:!0});function s(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?r.credentials="include":e.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function x(e){if(e.ep)return;e.ep=!0;const r=s(e);fetch(e.href,r)}})();const ee="modulepreload",te=function(t){return"/"+t},F={},g=function(o,s,x){let e=Promise.resolve();if(s&&s.length>0){document.getElementsByTagName("link");const r=document.querySelector("meta[property=csp-nonce]"),c=(r==null?void 0:r.nonce)||(r==null?void 0:r.getAttribute("nonce"));e=Promise.all(s.map(p=>{if(p=te(p),p in F)return;F[p]=!0;const b=p.endsWith(".css"),j=b?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${p}"]${j}`))return;const u=document.createElement("link");if(u.rel=b?"stylesheet":ee,b||(u.as="script",u.crossOrigin=""),u.href=p,c&&u.setAttribute("nonce",c),document.head.appendChild(u),b)return new Promise((v,_)=>{u.addEventListener("load",v),u.addEventListener("error",()=>_(new Error(`Unable to preload CSS for ${p}`)))})}))}return e.then(()=>o()).catch(r=>{const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=r,window.dispatchEvent(c),!c.defaultPrevented)throw r})};function i(t,o){return o||(o=t.slice(0)),Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(o)}}))}const oe="/assets/logo-fundo-azul-CVrwm-yG.png";var L,T,$,B,R,q,D,H,N,V,G,Q;I.add(Cn.faBars,En.faTimes);const ie=a.nav(L||(L=i([`
  background: #00508c;
  padding: 0.5rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  z-index: 10;
`]))),re=a.img(T||(T=i([`
  height: 50px;
`]))),ae=a.div($||($=i([`
  display: flex;
  align-items: center;

  @media screen and (max-width: 768px) {
    display: none;
  }
`]))),k=a.div(B||(B=i([`
  position: relative;
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 0 1rem;
  cursor: pointer;
  transition: color 0.3s;
  white-space: nowrap;

  &:hover {
    color: #fac800;
  }

  @media screen and (max-width: 1200px) {
    font-size: 1rem;
  }

  & > a {
    color: inherit;
    text-decoration: none;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`]))),O=a.div(R||(R=i([`
  display: `,`;
  position: absolute;
  top: 100%;
  left: 0;
  background: #00508c;
  padding: 1rem;
  border-radius: 5px;
  z-index: 20;

  & a {
    display: block;
    color: white;
    margin: 0.5rem 0;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`])),t=>{let{$isOpen:o}=t;return o?"block":"none"}),se=a(l)(q||(q=i([`
  background: #28a745;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  margin-left: 1rem;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #218838;
  }
`]))),le=a.div(D||(D=i([`
  display: none;

  @media screen and (max-width: 768px) {
    display: block;
    color: white;
    font-size: 1.8rem;
    cursor: pointer;
    z-index: 11; /* Ensure it is above the mobile menu */
  }
`]))),ce=a.div(H||(H=i([`
  display: none;

  @media screen and (max-width: 768px) {
    display: `,`;
    flex-direction: column;
    align-items: center;
    position: absolute;
    top: 70px;
    left: 0;
    width: 100%;
    background: #00508c;
    padding: 1rem 0;
    z-index: 9;
  }
`])),t=>{let{$isOpen:o}=t;return o?"flex":"none"}),z=a.div(N||(N=i([`
  width: 100%;
  text-align: center;
`]))),w=a(l)(V||(V=i([`
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 1rem 0;
  cursor: pointer;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),m=a(l)(G||(G=i([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),S=a.div(Q||(Q=i([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),de=()=>{const[t,o]=d.useState(!1),[s,x]=d.useState(""),e=()=>{t==!0&&x(""),o(!t)},r=c=>{x(s===c?"":c)};return n.jsxs(ie,{children:[n.jsx(l,{to:"/",children:n.jsx(re,{src:oe,alt:"Logo"})}),n.jsx(le,{onClick:e,children:n.jsx(y,{icon:t?En.faTimes:Cn.faBars})}),n.jsxs(ae,{children:[n.jsxs(k,{onMouseEnter:()=>x("quemSomos"),onMouseLeave:()=>x(""),onClick:()=>r("quemSomosMobile"),children:["Quem Somos",n.jsxs(O,{$isOpen:s==="quemSomos"||s==="quemSomosMobile",children:[n.jsx(l,{to:"/institucional",children:"Institucional"}),n.jsx(l,{to:"/estrutura",children:"Estrutura"}),n.jsx(l,{to:"/filiacao",children:"Filiação"}),n.jsx(l,{to:"/memoria",children:"Memória Institucional"})]})]}),n.jsxs(k,{onMouseEnter:()=>x("oQueFazemos"),onMouseLeave:()=>x(""),onClick:()=>r("oQueFazemosMobile"),children:["O Que Fazemos",n.jsxs(O,{$isOpen:s==="oQueFazemos"||s==="oQueFazemosMobile",children:[n.jsx(l,{to:"/eixos",children:"Eixos de Atuação"}),n.jsx(l,{to:"/acoes",children:"Ações e Temáticas"}),n.jsx(l,{to:"/eventos",children:"Eventos e Workshops"})]})]}),n.jsxs(k,{onMouseEnter:()=>x("mobilidade"),onMouseLeave:()=>x(""),onClick:()=>r("mobilidadeMobile"),children:["Intercâmbios",n.jsxs(O,{$isOpen:s==="mobilidade"||s==="mobilidadeMobile",children:[n.jsx(l,{to:"/intercambio_nacional",children:"Intercâmbios Nacionais"}),n.jsx(l,{to:"/intercambio_internacional",children:"Intercâmbios Internacionais"}),n.jsx(l,{to:"/regulamento",children:"Regulamento de Intercâmbios"}),n.jsx(l,{to:"/outras-modalidades",children:"Outras Modalidades de Intercâmbio"}),n.jsx(l,{to:"/social-programs",children:"Social Programs"})]})]}),n.jsxs(k,{onMouseEnter:()=>x("midias"),onMouseLeave:()=>x(""),onClick:()=>r("midiasMobile"),children:["Mídias e Documentos",n.jsxs(O,{$isOpen:s==="midias"||s==="midiasMobile",children:[n.jsx(l,{to:"/arquivos/rp",children:"Ressonância Poética"}),n.jsx(l,{to:"/arquivos/susi",children:"Informa SUSi"}),n.jsx(l,{to:"/arquivos/bms",children:"Brazilian Medical Students"}),n.jsx(l,{to:"/arquivos/relatorios",children:"Relatórios"}),n.jsx(l,{to:"/arquivos/notas",children:"Notas de Posicionamento"}),n.jsx(l,{to:"/arquivos/dps",children:"Declarações de Política"}),n.jsx(l,{to:"/arquivos/intercambio_nac",children:"Intercâmbio Nacional"}),n.jsx(l,{to:"/arquivos/intercambio_inter",children:"Intercâmbio Internacional"}),n.jsx(l,{to:"/arquivos/regulamento",children:"Regulamento de Intercâmbios"})]})]}),n.jsx(k,{children:n.jsx(l,{to:"/noticias",children:"Notícias"})}),n.jsxs(k,{onMouseEnter:()=>x("membros"),onMouseLeave:()=>x(""),onClick:()=>r("membrosMobile"),children:["Membros",n.jsxs(O,{$isOpen:s==="membros"||s==="membrosMobile",children:[n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"}),n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"}),n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})]})]}),n.jsx(se,{to:"/filie-se",children:"FILIE-SE"})]}),n.jsxs(ce,{$isOpen:t,children:[n.jsxs(z,{children:[n.jsx(w,{onClick:()=>r("quemSomosMobile"),children:"Quem Somos"}),s==="quemSomosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/institucional",onClick:e,children:"Institucional"}),n.jsx(m,{to:"/estrutura",onClick:e,children:"Estrutura"}),n.jsx(m,{to:"/filiacao",onClick:e,children:"Filiação"}),n.jsx(m,{to:"/memoria",onClick:e,children:"Memória Institucional"})]})]}),n.jsxs(z,{children:[n.jsx(w,{onClick:()=>r("oQueFazemosMobile"),children:"O Que Fazemos"}),s==="oQueFazemosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/eixos",onClick:e,children:"Eixos de Atuação"}),n.jsx(m,{to:"/acoes",onClick:e,children:"Ações e Temáticas"}),n.jsx(m,{to:"/eventos",onClick:e,children:"Eventos e Workshops"})]})]}),n.jsxs(z,{children:[n.jsx(w,{onClick:()=>r("mobilidadeMobile"),children:"Intercâmbios"}),s==="mobilidadeMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/intercambio_nacional",onClick:e,children:"Intercâmbios Nacionais"}),n.jsx(m,{to:"/intercambio_internacional",onClick:e,children:"Intercâmbios Internacionais"}),n.jsx(m,{to:"/regulamento",onClick:e,children:"Regulamento de Intercâmbios"}),n.jsx(m,{to:"/outras-modalidades",onClick:e,children:"Outras Modalidades de Intercâmbio"}),n.jsx(m,{to:"/social-programs",onClick:e,children:"Social Programs"})]})]}),n.jsxs(z,{children:[n.jsx(w,{onClick:()=>r("midiasMobile"),children:"Mídias e Documentos"}),s==="midiasMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/arquivos/rp",onClick:e,children:"Ressonância Poética"}),n.jsx(m,{to:"/arquivos/susi",onClick:e,children:"Informa SUSi"}),n.jsx(m,{to:"/arquivos/bms",onClick:e,children:"Brazilian Medical Students"}),n.jsx(m,{to:"/arquivos/relatorios",onClick:e,children:"Relatórios"}),n.jsx(m,{to:"/arquivos/notas",onClick:e,children:"Notas de Posicionamento"}),n.jsx(m,{to:"/arquivos/dps",onClick:e,children:"Declarações de Política"}),n.jsx(m,{to:"/arquivos/intercambio_nac",onClick:e,children:"Intercâmbio Nacional"}),n.jsx(m,{to:"/arquivos/intercambio_inter",onClick:e,children:"Intercâmbio Internacional"}),n.jsx(m,{to:"/arquivos/regulamento",onClick:e,children:"Regulamento"})]})]}),n.jsx(w,{to:"/noticias",onClick:e,children:"Notícias"}),n.jsxs(z,{children:[n.jsx(w,{onClick:()=>r("membrosMobile"),children:"Membros"}),s==="membrosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(S,{onClick:e,children:n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"})}),n.jsx(S,{onClick:e,children:n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"})}),n.jsx(S,{onClick:e,children:n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})})]})]}),n.jsx(w,{to:"/filie-se",onClick:e,children:"FILIE-SE"})]})]})};var U;const me=Bn(U||(U=i([`
  body {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
    background-color: #f0f0f0;
  }

  a {
    text-decoration: none;
    color: inherit;
  }
  h1, h2 {
    margin: 0;
  }

  button {
    outline: none;
  }

.carousel-container {
  max-width: 1200px;
  margin: 0 auto;
}

.carousel .slide {
  background: none;
}

/* CSS for BrazilMap component */
.container {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: flex-start;
    width: 100%;
    margin: 0;
    padding: 20px;
    box-sizing: border-box;
}

.map-container {
    flex: 1;
    min-width: 300px;
    max-width: 600px;
    margin: 0 20px; /* Medium margin on the left and right sides */
}

.legend-container {
    display: flex;
    flex-direction: column;
    margin-left: 20px;
}

.legend-item {
    display: flex;
    align-items: center;
    margin-bottom: 10px;
}

.color-box {
    width: 20px;
    height: 20px;
    margin-right: 10px;
}

/* Media query for mobile view */
@media (max-width: 768px) {
    .container {
        flex-direction: column;
        align-items: center;
    }
    .map-container {
        margin: 0; /* Remove margins on mobile */
    }
    .legend-container {
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: center;
        margin-left: 0;
        margin-top: 20px; /* Space between map and legend */
    }
    .legend-item {
        margin: 5px; /* Adjust margin for horizontal layout */
    }
}


`])));Vn.load({google:{families:["Poppins:300,400,500,700","sans-serif"]}});I.add(Rn.faTwitter,qn.faInstagram,Dn.faMapMarkerAlt,Hn.faEnvelope,Nn.faPhone);const xe=E("footer")({backgroundColor:"#00508C",color:"white",padding:"20px 0",textAlign:"center"}),M=E("div")({display:"flex",alignItems:"center",margin:"5px 0",justifyContent:"center","& svg":{marginRight:"10px"}}),pe=E("div")({marginTop:"10px"}),W=E(Gn)({color:"white",margin:"0 10px",fontSize:"1.5rem",transition:"color 0.3s","&:hover":{color:"#FAC800"}}),he=()=>n.jsx(xe,{children:n.jsx(P,{maxWidth:"lg",children:n.jsxs(C,{container:!0,spacing:4,children:[n.jsxs(C,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Endereço"}),n.jsxs(M,{children:[n.jsx(y,{icon:"map-marker-alt"}),n.jsx(f,{variant:"body1",children:"Avenida Paulista nº 1765 - 7º Andar"})]}),n.jsx(f,{variant:"body1",children:"Boa Vista, São Paulo/SP - Brasil"})]}),n.jsxs(C,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Contato"}),n.jsxs(M,{children:[n.jsx(y,{icon:"envelope"}),n.jsx(f,{variant:"body1",children:"atendimento@ifmsabrazil.org"})]}),n.jsxs(M,{children:[n.jsx(y,{icon:"phone"}),n.jsx(f,{variant:"body1",children:"Tel: + 55 11 3170-3251"})]})]}),n.jsxs(C,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Siga-nos"}),n.jsxs(pe,{children:[n.jsx(W,{href:"https://twitter.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(y,{icon:["fab","twitter"]})}),n.jsx(W,{href:"https://instagram.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(y,{icon:["fab","instagram"]})})]})]})]})})}),ue=E(P)({display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh"}),ge=E(f)({marginTop:"16px",color:"#00508C"}),Fn=()=>n.jsxs(ue,{children:[n.jsx(Qn,{}),n.jsx(ge,{variant:"h6",children:"Carregando..."})]});var Y,X,J,K,Z;const fe=kn(Y||(Y=i([`
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
`]))),be=kn(X||(X=i([`
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.8);
  }
`]))),je=a.div(J||(J=i([`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #00508c;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  cursor: pointer;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease-in-out;
  z-index: 1000;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 46px;
    height: 46px;
  }
`]))),ve=a.div(K||(K=i([`
  position: fixed;
  bottom: 80px;
  right: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 1000;
  transition: all 0.2s ease-in-out;
  animation: `,` 0.2s forwards;

  @media (max-width: 768px) {
    bottom: 76px;
    right: 16px;
  }
`])),t=>t.isOpen?fe:be),nn=a.a(Z||(Z=i([`
  color: #00508c;
  text-decoration: none;
  display: flex;
  align-items: center;
  padding: 8px 0;
  width: 100%;
  transition: all 0.2s ease-in-out;

  &:hover {
    color: #003366;
  }

  svg {
    margin-right: 10px;
  }
`]))),_e=()=>{const[t,o]=d.useState(!1),s=()=>{o(!t)};return n.jsxs(n.Fragment,{children:[n.jsx(je,{onClick:s,children:t?n.jsx(Kn,{size:24}):n.jsx(A,{size:24})}),t&&n.jsxs(ve,{isOpen:t,children:[n.jsxs(nn,{href:"mailto:atendimento@ifmsabrazil.org",children:[n.jsx(A,{size:20}),"atendimento@ifmsabrazil.org"]}),n.jsxs(nn,{href:"https://instagram.com/ifmsabrazil",target:"_blank",children:[n.jsx(Zn,{size:20}),"@ifmsabrazil"]})]})]})};var en,tn,on,rn,an,sn;const we=a.section(en||(en=i([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #FFFFFF;
  text-align: center;
`]))),ye=a.h2(tn||(tn=i([`
  font-family: 'Poppins', sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),ke=a.div(on||(on=i([`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
`]))),Ce=a.div(rn||(rn=i([`
  flex: 1 1 30%;
  max-width: 30%;
  display: flex;
  justify-content: center;

  @media (max-width: 991px) {
    flex: 1 1 45%;
    max-width: 45%;
  }

  @media (max-width: 600px) {
    flex: 1 1 100%;
    max-width: 100%;
  }
`]))),Ee=a.div(an||(an=i([`
  position: relative;
  height: auto;
  font-family: 'Poppins', sans-serif;
  color: rgba(255, 255, 255, 1);
  text-align: center;
  background-color: `,`;
  flex-grow: 1;
  width: 100%;
  align-self: stretch;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`])),t=>t.bgColor),Oe=a.div(sn||(sn=i([`
  font-size: 24px;
`])));function ze(){const t=[{id:1,bgColor:"rgba(0, 80, 140, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Em 26 Estados"}),n.jsx("br",{}),n.jsx("strong",{children:"+ Distrito Federal"})]})},{id:2,bgColor:"rgba(250, 200, 0, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Temos +11000"}),n.jsx("br",{}),n.jsx("strong",{children:"membros filiados"})]})},{id:3,bgColor:"rgba(0, 150, 60, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Presentes em +220"}),n.jsx("br",{}),n.jsx("strong",{children:"escolas médicas"})]})}];return n.jsxs(we,{children:[n.jsx(ye,{children:"Nossa abrangência"}),n.jsx(ke,{children:t.map(o=>n.jsx(Ce,{children:n.jsx(Ee,{bgColor:o.bgColor,children:n.jsx(Oe,{children:o.text})})},o.id))})]})}var ln,cn,dn,mn,xn;I.add(On.faBook,zn.faGraduationCap,Sn.faHandsHelping,Mn.faHeartbeat,In.faHospital,Pn.faUniversity,An.faSearch);const Se=a.section(ln||(ln=i([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
  text-align: center;
`]))),Me=a.h2(cn||(cn=i([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Ie=a.div(dn||(dn=i([`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 20px;
  justify-content: center;

  @media (max-width: 991px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    & > :nth-child(5) {
      grid-column: span 2;
    }
  }
`]))),Pe=a.div(mn||(mn=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: `,`;
  color: `,`;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
  font-family: "Poppins", sans-serif;
  text-align: center;
  border: `,`;

  &:hover {
    transform: translateY(-10px);
  }
`])),t=>t.bgColor,t=>t.color||"rgba(255, 255, 255, 1)",t=>t.border||"none"),Ae=a.div(xn||(xn=i([`
  font-size: 18px;
  margin-top: 10px;
`])));function Fe(){const t=[{id:1,bgColor:"rgba(182, 120, 38, 1)",text:"Representatividade estudantil",icon:zn.faGraduationCap},{id:2,bgColor:"rgba(0, 0, 0, 1)",text:"Capacity Building",icon:On.faBook},{id:3,bgColor:"#FFFFFF",text:"Educação Médica",icon:In.faHospital,color:"#000",border:"2px solid #000"},{id:4,bgColor:"rgba(220, 0, 0, 1)",text:"Promoção de Saúde",icon:Mn.faHeartbeat},{id:5,bgColor:"rgba(0, 150, 60, 1)",text:"Humanização",icon:Sn.faHandsHelping},{id:6,bgColor:"rgba(0, 80, 140, 1)",text:"Mobilidade Estudantil",icon:Pn.faUniversity},{id:7,bgColor:"rgba(128, 128, 128, 1)",text:"Pesquisa e Extensão",icon:An.faSearch}];return n.jsxs(Se,{children:[n.jsx(Me,{children:"Nossos eixos de atuação"}),n.jsx(Ie,{children:t.map(o=>n.jsxs(Pe,{bgColor:o.bgColor,color:o.color,border:o.border,children:[n.jsx(y,{icon:o.icon,size:"3x"}),n.jsx(Ae,{children:o.text})]},o.id))})]})}var pn,hn;const Le=a(Un)(pn||(pn=i([`
  display: flex;
  flex-direction: column;
  margin: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
  border-radius: 10px;

  &:hover {
    transform: translateY(-5px);
  }

  @media (min-width: 600px) {
    flex-direction: row;
  }
`]))),Te=a(Wn)(hn||(hn=i([`
  width: 100%;
  height: auto;

  @media (min-width: 600px) {
    width: 160px !important;
    height: auto;
    object-fit: cover;
    margin-left: auto;
  }
`]))),$e=t=>{let{post:o}=t;return n.jsxs(Le,{children:[n.jsxs(Yn,{style:{flex:1},children:[n.jsx(f,{component:"h2",variant:"h5",gutterBottom:!0,children:o.title}),n.jsx(f,{variant:"subtitle1",color:"text.secondary",children:o.author}),n.jsx(f,{variant:"subtitle2",color:"text.secondary",gutterBottom:!0,children:o.date?new Date(o.date).toLocaleDateString():""}),n.jsx(f,{variant:"body1",paragraph:!0,children:o.summary})]}),n.jsx(Te,{component:"img",image:o.imageLink,alt:"Blog image"})]})},Be={ç:"c",Ç:"C",á:"a",Á:"A",é:"e",É:"E",í:"i",Í:"I",ó:"o",Ó:"O",ú:"u",Ú:"U",à:"a",À:"A",ã:"a",Ã:"A",õ:"o",Õ:"O"},Re=t=>t.split("").map(o=>Be[o]||o).join(""),qe=t=>Re(t).toLowerCase().replace(/[^a-z0-9]+/g,"-");var un,gn;const De=a.section(un||(un=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
`]))),He=a.h2(gn||(gn=i([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Ne=t=>{let{posts:o,loading:s}=t;if(s)return n.jsx(Fn,{});const x=c=>c.sort((p,b)=>b["dia-mes-ano"]-p["dia-mes-ano"]),r=function(c){let p=arguments.length>1&&arguments[1]!==void 0?arguments[1]:4;const b=x(c),j=b.filter(_=>_["forcar-pagina-inicial"]);if(j.length>=p)return j;const u=b.filter(_=>!_["forcar-pagina-inicial"]);return j.concat(u.slice(0,p-j.length))}(o);return n.jsxs(De,{children:[n.jsx(He,{children:"Últimas Notícias"}),n.jsx(P,{maxWidth:"lg",children:n.jsx(C,{container:!0,spacing:4,children:r.map((c,p)=>n.jsx(C,{item:!0,xs:12,sm:6,children:n.jsx(l,{to:"/arquivo/".concat(c.id,"/").concat(qe(c.title)),children:n.jsx($e,{post:c})})},p))})})]})},Ve="/assets/background-image-YkmHsWZG.webp";var fn,bn,jn,vn,_n,wn;const Ge=a.div(fn||(fn=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  overflow: hidden;
`]))),Qe=a.div(bn||(bn=i([`
  width: 100%;
  height: 100vh;
  background-image: url(`,`);
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  text-align: center;
  padding: 20px;
  background-color: rgba(0, 0, 0, 0.5);
`])),Ve),Ue=a.h1(jn||(jn=i([`
  font-size: 3rem;
  font-weight: 700;
  padding: 0 20px;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
`]))),We=a.button(vn||(vn=i([`
  margin-top: 20px;
  padding: 12px 24px;
  font-size: 1rem;
  font-weight: bold;
  color: #00508c;
  background-color: #fac800;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: translateY(-3px);
    background-color: #e6b800;
    color: #004080;
  }
`]))),Ye=a.button(_n||(_n=i([`
  position: fixed;
  bottom: 20px;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: white;
  border: none;
  cursor: pointer;
  display: `,`;
  justify-content: center;
  align-items: center;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
  }

  svg {
    width: 24px;
    height: 24px;
    fill: #00508c;
  }
`])),t=>{let{show:o}=t;return o?"flex":"none"}),Xe=a.div(wn||(wn=i([`
  width: 100%;
  padding: 60px 20px;
  background-color: white;
  text-align: center;
  color: #333;

  h2 {
    font-size: 2rem;
    margin-bottom: 20px;
  }

  p {
    max-width: 800px;
    margin: 0 auto;
    line-height: 1.6;
  }
`]))),Je=()=>{const[t,o]=d.useState([]),[s,x]=d.useState(!0),[e,r]=d.useState(!0),c="https://api.ifmsabrazil.org/api/blogs/recent";d.useEffect(()=>{(async()=>{try{const v=(await Jn.get(c)).data,_=Array.isArray(v)?v:v.posts;if(!Array.isArray(_))throw new Error("Posts data is not an array");o(_)}catch(u){console.error("Error fetching posts:",u)}finally{x(!1)}})()},[]);const p=()=>{const j=window.scrollY,v=window.innerHeight*.7;j<v?r(!0):r(!1)},b=()=>{window.scrollTo({top:window.innerHeight,behavior:"smooth"})};return d.useEffect(()=>(window.addEventListener("scroll",p),()=>{window.removeEventListener("scroll",p)}),[]),n.jsxs(Ge,{children:[n.jsxs(Qe,{children:[n.jsx(Ue,{children:"Estudantes de medicina que fazem a diferença"}),n.jsx(We,{children:"Faça parte"}),n.jsx(Ye,{show:e,onClick:b,children:n.jsx("svg",{viewBox:"0 0 24 24",children:n.jsx("path",{d:"M12 16.5l-7-7 1.41-1.41L12 13.67l5.59-5.58L19 9.5l-7 7z"})})})]}),n.jsxs(Xe,{children:[n.jsx("h2",{children:"Breve Introdução"}),n.jsx("p",{children:"Fundada em 1991 como primeira associação da América Latina vinculada à International Federation of Medical Students’ Association (IFMSA), a IFMSA Brazil interliga estudantes de medicina de todo o país para fazer a diferença na sociedade e na formação médica."})]}),n.jsx(ze,{}),n.jsx(Fe,{}),n.jsx(Ne,{posts:t,loading:s}),n.jsx(_e,{})]})},yn=d.lazy(()=>g(()=>import("./MarkdownPage-nLq5mdB5.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]))),Ke=d.lazy(()=>g(()=>import("./GeradorLink-Bzlx9Ywa.js"),__vite__mapDeps([25,1,2,6,7,8,9,10,11,12,13,14]))),Ze=d.lazy(()=>g(()=>import("./Arquivos-D3fmdMlm.js"),__vite__mapDeps([26,1,2,18,19,8,9,10,4,27,20,21,6,7,11,12,13,14,15,16,17,22,23]))),nt=d.lazy(()=>g(()=>import("./Estrutura-474-cZHV.js"),__vite__mapDeps([28,1,2,4,29,30,6,7,8,9,10,11,12,13,14,31,21,32,33,34,35,3,5,24,17,15,16,18,19,20,22,23]))),et=d.lazy(()=>g(()=>import("./Filiacao-BKbIrf0g.js"),__vite__mapDeps([36,1,2,18,19,8,9,10,23,6,7,11,12,13,14,4,37,35,3,5,24,17,15,16,20,21,22]))),tt=d.lazy(()=>g(()=>import("./NotFound-DAL-nhLq.js"),__vite__mapDeps([38,1,2,18,19,8,9,10,17,12,13,15,16,20,21,22,6,7,11,14,4,23]))),ot=d.lazy(()=>g(()=>import("./Noticias-Du7CpX6z.js"),__vite__mapDeps([39,1,2,18,19,8,9,10,17,12,13,15,16,27,20,21,6,7,11,14,4,22,23]))),it=d.lazy(()=>g(()=>import("./Institucional--BOt_96G.js"),__vite__mapDeps([40,1,2,35,3,5,6,7,8,9,10,11,12,13,14,24,17,15,16,18,19,20,21,22,4,23]))),rt=d.lazy(()=>g(()=>import("./AcoesETematicas-FMVCcO3o.js"),__vite__mapDeps([41,1,2,35,3,5,6,7,8,9,10,11,12,13,14,24,17,15,16,18,19,20,21,22,4,23]))),at=d.lazy(()=>g(()=>import("./SocialPrograms-Vn48lVuO.js"),__vite__mapDeps([42,1,2,35,3,5,6,7,8,9,10,11,12,13,14,24,17,15,16,18,19,20,21,22,4,23]))),st=d.lazy(()=>g(()=>import("./Eixos-xPAnHoHA.js"),__vite__mapDeps([43,1,2,35,3,5,6,7,8,9,10,11,12,13,14,24,17,15,16,18,19,20,21,22,4,23]))),lt=d.lazy(()=>g(()=>import("./Eventos-BLbt9DDk.js"),__vite__mapDeps([44,1,2,35,3,5,6,7,8,9,10,11,12,13,14,24,17,15,16,18,19,20,21,22,4,23]))),ct=d.lazy(()=>g(()=>import("./Regulamento-UQnp3bb4.js"),__vite__mapDeps([45,1,2,35,3,5,6,7,8,9,10,11,12,13,14,24]))),dt=d.lazy(()=>g(()=>import("./IntercambioNacional-BX76PIdf.js"),__vite__mapDeps([46,1,2,35,3,5,6,7,8,9,10,11,12,13,14,24]))),mt=()=>n.jsxs($n,{children:[n.jsx(me,{}),n.jsx(Xn,{}),n.jsx(de,{}),n.jsx(d.Suspense,{fallback:n.jsx(Fn,{}),children:n.jsxs(ne,{children:[n.jsx(h,{path:"/",element:n.jsx(Je,{})}),n.jsx(h,{path:"/arquivo/:id/:title",element:n.jsx(yn,{needsExternal:!0})}),n.jsx(h,{path:"/gerarlink",element:n.jsx(Ke,{})}),n.jsx(h,{path:"/estrutura",element:n.jsx(nt,{})}),n.jsx(h,{path:"/filiacao",element:n.jsx(et,{})}),n.jsx(h,{path:"/noticias",element:n.jsx(ot,{})}),n.jsx(h,{path:"/institucional",element:n.jsx(it,{})}),n.jsx(h,{path:"/acoes",element:n.jsx(rt,{})}),n.jsx(h,{path:"/arquivos/:type",element:n.jsx(Ze,{})}),n.jsx(h,{path:"/social-programs",element:n.jsx(at,{})}),n.jsx(h,{path:"/eixos",element:n.jsx(st,{})}),n.jsx(h,{path:"/eventos",element:n.jsx(lt,{})}),n.jsx(h,{path:"/regulamento",element:n.jsx(ct,{})}),n.jsx(h,{path:"/intercambio_nacional",element:n.jsx(dt,{})}),n.jsx(h,{path:"/tutorial",element:n.jsx(yn,{needsExternal:!1,filepath:"/markdown/pagina.md"})}),n.jsx(h,{path:"*",element:n.jsx(tt,{})})," "]})}),n.jsx(he,{})]}),xt=document.getElementById("root"),pt=Tn(xt);pt.render(n.jsx(Ln.StrictMode,{children:n.jsx(mt,{})}));export{Fn as L,i as _,g as a,qe as g};
