import{P as g}from"./prop-types-1yzuAbYU.js";import{a as jn}from"./react-CLPtFgDq.js";function cn(a,n){var t=Object.keys(a);if(Object.getOwnPropertySymbols){var e=Object.getOwnPropertySymbols(a);n&&(e=e.filter(function(r){return Object.getOwnPropertyDescriptor(a,r).enumerable})),t.push.apply(t,e)}return t}function u(a){for(var n=1;n<arguments.length;n++){var t=arguments[n]!=null?arguments[n]:{};n%2?cn(Object(t),!0).forEach(function(e){O(a,e,t[e])}):Object.getOwnPropertyDescriptors?Object.defineProperties(a,Object.getOwnPropertyDescriptors(t)):cn(Object(t)).forEach(function(e){Object.defineProperty(a,e,Object.getOwnPropertyDescriptor(t,e))})}return a}function Pa(a){"@babel/helpers - typeof";return Pa=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(n){return typeof n}:function(n){return n&&typeof Symbol=="function"&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n},Pa(a)}function Pt(a,n){if(!(a instanceof n))throw new TypeError("Cannot call a class as a function")}function At(a,n){for(var t=0;t<n.length;t++){var e=n[t];e.enumerable=e.enumerable||!1,e.configurable=!0,"value"in e&&(e.writable=!0),Object.defineProperty(a,e.key,e)}}function Ot(a,n,t){return n&&At(a.prototype,n),Object.defineProperty(a,"prototype",{writable:!1}),a}function O(a,n,t){return n in a?Object.defineProperty(a,n,{value:t,enumerable:!0,configurable:!0,writable:!0}):a[n]=t,a}function Ka(a,n){return St(a)||_t(a,n)||Hn(a,n)||Mt()}function fa(a){return Nt(a)||Ct(a)||Hn(a)||Et()}function Nt(a){if(Array.isArray(a))return Da(a)}function St(a){if(Array.isArray(a))return a}function Ct(a){if(typeof Symbol<"u"&&a[Symbol.iterator]!=null||a["@@iterator"]!=null)return Array.from(a)}function _t(a,n){var t=a==null?null:typeof Symbol<"u"&&a[Symbol.iterator]||a["@@iterator"];if(t!=null){var e=[],r=!0,i=!1,o,s;try{for(t=t.call(a);!(r=(o=t.next()).done)&&(e.push(o.value),!(n&&e.length===n));r=!0);}catch(f){i=!0,s=f}finally{try{!r&&t.return!=null&&t.return()}finally{if(i)throw s}}return e}}function Hn(a,n){if(a){if(typeof a=="string")return Da(a,n);var t=Object.prototype.toString.call(a).slice(8,-1);if(t==="Object"&&a.constructor&&(t=a.constructor.name),t==="Map"||t==="Set")return Array.from(a);if(t==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t))return Da(a,n)}}function Da(a,n){(n==null||n>a.length)&&(n=a.length);for(var t=0,e=new Array(n);t<n;t++)e[t]=a[t];return e}function Et(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function Mt(){throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}var un=function(){},Qa={},Rn={},Fn=null,Yn={mark:un,measure:un};try{typeof window<"u"&&(Qa=window),typeof document<"u"&&(Rn=document),typeof MutationObserver<"u"&&(Fn=MutationObserver),typeof performance<"u"&&(Yn=performance)}catch{}var It=Qa.navigator||{},mn=It.userAgent,vn=mn===void 0?"":mn,R=Qa,p=Rn,dn=Fn,ua=Yn;R.document;var D=!!p.documentElement&&!!p.head&&typeof p.addEventListener=="function"&&typeof p.createElement=="function",$n=~vn.indexOf("MSIE")||~vn.indexOf("Trident/"),ma,va,da,ga,ha,T="___FONT_AWESOME___",ja=16,Un="fa",Vn="svg-inline--fa",G="data-fa-i2svg",Ha="data-fa-pseudo-element",xt="data-fa-pseudo-element-pending",Ja="data-prefix",Za="data-icon",gn="fontawesome-i2svg",Tt="async",Lt=["HTML","HEAD","STYLE","SCRIPT"],Wn=function(){try{return!0}catch{return!1}}(),b="classic",y="sharp",an=[b,y];function la(a){return new Proxy(a,{get:function(t,e){return e in t?t[e]:t[b]}})}var ea=la((ma={},O(ma,b,{fa:"solid",fas:"solid","fa-solid":"solid",far:"regular","fa-regular":"regular",fal:"light","fa-light":"light",fat:"thin","fa-thin":"thin",fad:"duotone","fa-duotone":"duotone",fab:"brands","fa-brands":"brands",fak:"kit",fakd:"kit","fa-kit":"kit","fa-kit-duotone":"kit"}),O(ma,y,{fa:"solid",fass:"solid","fa-solid":"solid",fasr:"regular","fa-regular":"regular",fasl:"light","fa-light":"light",fast:"thin","fa-thin":"thin"}),ma)),ra=la((va={},O(va,b,{solid:"fas",regular:"far",light:"fal",thin:"fat",duotone:"fad",brands:"fab",kit:"fak"}),O(va,y,{solid:"fass",regular:"fasr",light:"fasl",thin:"fast"}),va)),ia=la((da={},O(da,b,{fab:"fa-brands",fad:"fa-duotone",fak:"fa-kit",fal:"fa-light",far:"fa-regular",fas:"fa-solid",fat:"fa-thin"}),O(da,y,{fass:"fa-solid",fasr:"fa-regular",fasl:"fa-light",fast:"fa-thin"}),da)),zt=la((ga={},O(ga,b,{"fa-brands":"fab","fa-duotone":"fad","fa-kit":"fak","fa-light":"fal","fa-regular":"far","fa-solid":"fas","fa-thin":"fat"}),O(ga,y,{"fa-solid":"fass","fa-regular":"fasr","fa-light":"fasl","fa-thin":"fast"}),ga)),Dt=/fa(s|r|l|t|d|b|k|ss|sr|sl|st)?[\-\ ]/,Gn="fa-layers-text",jt=/Font ?Awesome ?([56 ]*)(Solid|Regular|Light|Thin|Duotone|Brands|Free|Pro|Sharp|Kit)?.*/i,Ht=la((ha={},O(ha,b,{900:"fas",400:"far",normal:"far",300:"fal",100:"fat"}),O(ha,y,{900:"fass",400:"fasr",300:"fasl",100:"fast"}),ha)),Xn=[1,2,3,4,5,6,7,8,9,10],Rt=Xn.concat([11,12,13,14,15,16,17,18,19,20]),Ft=["class","data-prefix","data-icon","data-fa-transform","data-fa-mask"],V={GROUP:"duotone-group",SWAP_OPACITY:"swap-opacity",PRIMARY:"primary",SECONDARY:"secondary"},oa=new Set;Object.keys(ra[b]).map(oa.add.bind(oa));Object.keys(ra[y]).map(oa.add.bind(oa));var Yt=[].concat(an,fa(oa),["2xs","xs","sm","lg","xl","2xl","beat","border","fade","beat-fade","bounce","flip-both","flip-horizontal","flip-vertical","flip","fw","inverse","layers-counter","layers-text","layers","li","pull-left","pull-right","pulse","rotate-180","rotate-270","rotate-90","rotate-by","shake","spin-pulse","spin-reverse","spin","stack-1x","stack-2x","stack","ul",V.GROUP,V.SWAP_OPACITY,V.PRIMARY,V.SECONDARY]).concat(Xn.map(function(a){return"".concat(a,"x")})).concat(Rt.map(function(a){return"w-".concat(a)})),na=R.FontAwesomeConfig||{};function $t(a){var n=p.querySelector("script["+a+"]");if(n)return n.getAttribute(a)}function Ut(a){return a===""?!0:a==="false"?!1:a==="true"?!0:a}if(p&&typeof p.querySelector=="function"){var Vt=[["data-family-prefix","familyPrefix"],["data-css-prefix","cssPrefix"],["data-family-default","familyDefault"],["data-style-default","styleDefault"],["data-replacement-class","replacementClass"],["data-auto-replace-svg","autoReplaceSvg"],["data-auto-add-css","autoAddCss"],["data-auto-a11y","autoA11y"],["data-search-pseudo-elements","searchPseudoElements"],["data-observe-mutations","observeMutations"],["data-mutate-approach","mutateApproach"],["data-keep-original-source","keepOriginalSource"],["data-measure-performance","measurePerformance"],["data-show-missing-icons","showMissingIcons"]];Vt.forEach(function(a){var n=Ka(a,2),t=n[0],e=n[1],r=Ut($t(t));r!=null&&(na[e]=r)})}var Bn={styleDefault:"solid",familyDefault:"classic",cssPrefix:Un,replacementClass:Vn,autoReplaceSvg:!0,autoAddCss:!0,autoA11y:!0,searchPseudoElements:!1,observeMutations:!0,mutateApproach:"async",keepOriginalSource:!0,measurePerformance:!1,showMissingIcons:!0};na.familyPrefix&&(na.cssPrefix=na.familyPrefix);var J=u(u({},Bn),na);J.autoReplaceSvg||(J.observeMutations=!1);var v={};Object.keys(Bn).forEach(function(a){Object.defineProperty(v,a,{enumerable:!0,set:function(t){J[a]=t,ta.forEach(function(e){return e(v)})},get:function(){return J[a]}})});Object.defineProperty(v,"familyPrefix",{enumerable:!0,set:function(n){J.cssPrefix=n,ta.forEach(function(t){return t(v)})},get:function(){return J.cssPrefix}});R.FontAwesomeConfig=v;var ta=[];function Wt(a){return ta.push(a),function(){ta.splice(ta.indexOf(a),1)}}var H=ja,x={size:16,x:0,y:0,rotate:0,flipX:!1,flipY:!1};function Gt(a){if(!(!a||!D)){var n=p.createElement("style");n.setAttribute("type","text/css"),n.innerHTML=a;for(var t=p.head.childNodes,e=null,r=t.length-1;r>-1;r--){var i=t[r],o=(i.tagName||"").toUpperCase();["STYLE","LINK"].indexOf(o)>-1&&(e=i)}return p.head.insertBefore(n,e),a}}var Xt="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";function sa(){for(var a=12,n="";a-- >0;)n+=Xt[Math.random()*62|0];return n}function Z(a){for(var n=[],t=(a||[]).length>>>0;t--;)n[t]=a[t];return n}function nn(a){return a.classList?Z(a.classList):(a.getAttribute("class")||"").split(" ").filter(function(n){return n})}function qn(a){return"".concat(a).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Bt(a){return Object.keys(a||{}).reduce(function(n,t){return n+"".concat(t,'="').concat(qn(a[t]),'" ')},"").trim()}function Sa(a){return Object.keys(a||{}).reduce(function(n,t){return n+"".concat(t,": ").concat(a[t].trim(),";")},"")}function tn(a){return a.size!==x.size||a.x!==x.x||a.y!==x.y||a.rotate!==x.rotate||a.flipX||a.flipY}function qt(a){var n=a.transform,t=a.containerWidth,e=a.iconWidth,r={transform:"translate(".concat(t/2," 256)")},i="translate(".concat(n.x*32,", ").concat(n.y*32,") "),o="scale(".concat(n.size/16*(n.flipX?-1:1),", ").concat(n.size/16*(n.flipY?-1:1),") "),s="rotate(".concat(n.rotate," 0 0)"),f={transform:"".concat(i," ").concat(o," ").concat(s)},c={transform:"translate(".concat(e/2*-1," -256)")};return{outer:r,inner:f,path:c}}function Kt(a){var n=a.transform,t=a.width,e=t===void 0?ja:t,r=a.height,i=r===void 0?ja:r,o=a.startCentered,s=o===void 0?!1:o,f="";return s&&$n?f+="translate(".concat(n.x/H-e/2,"em, ").concat(n.y/H-i/2,"em) "):s?f+="translate(calc(-50% + ".concat(n.x/H,"em), calc(-50% + ").concat(n.y/H,"em)) "):f+="translate(".concat(n.x/H,"em, ").concat(n.y/H,"em) "),f+="scale(".concat(n.size/H*(n.flipX?-1:1),", ").concat(n.size/H*(n.flipY?-1:1),") "),f+="rotate(".concat(n.rotate,"deg) "),f}var Qt=`:root, :host {
  --fa-font-solid: normal 900 1em/1 "Font Awesome 6 Solid";
  --fa-font-regular: normal 400 1em/1 "Font Awesome 6 Regular";
  --fa-font-light: normal 300 1em/1 "Font Awesome 6 Light";
  --fa-font-thin: normal 100 1em/1 "Font Awesome 6 Thin";
  --fa-font-duotone: normal 900 1em/1 "Font Awesome 6 Duotone";
  --fa-font-sharp-solid: normal 900 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-regular: normal 400 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-light: normal 300 1em/1 "Font Awesome 6 Sharp";
  --fa-font-sharp-thin: normal 100 1em/1 "Font Awesome 6 Sharp";
  --fa-font-brands: normal 400 1em/1 "Font Awesome 6 Brands";
}

svg:not(:root).svg-inline--fa, svg:not(:host).svg-inline--fa {
  overflow: visible;
  box-sizing: content-box;
}

.svg-inline--fa {
  display: var(--fa-display, inline-block);
  height: 1em;
  overflow: visible;
  vertical-align: -0.125em;
}
.svg-inline--fa.fa-2xs {
  vertical-align: 0.1em;
}
.svg-inline--fa.fa-xs {
  vertical-align: 0em;
}
.svg-inline--fa.fa-sm {
  vertical-align: -0.0714285705em;
}
.svg-inline--fa.fa-lg {
  vertical-align: -0.2em;
}
.svg-inline--fa.fa-xl {
  vertical-align: -0.25em;
}
.svg-inline--fa.fa-2xl {
  vertical-align: -0.3125em;
}
.svg-inline--fa.fa-pull-left {
  margin-right: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-pull-right {
  margin-left: var(--fa-pull-margin, 0.3em);
  width: auto;
}
.svg-inline--fa.fa-li {
  width: var(--fa-li-width, 2em);
  top: 0.25em;
}
.svg-inline--fa.fa-fw {
  width: var(--fa-fw-width, 1.25em);
}

.fa-layers svg.svg-inline--fa {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
}

.fa-layers-counter, .fa-layers-text {
  display: inline-block;
  position: absolute;
  text-align: center;
}

.fa-layers {
  display: inline-block;
  height: 1em;
  position: relative;
  text-align: center;
  vertical-align: -0.125em;
  width: 1em;
}
.fa-layers svg.svg-inline--fa {
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-text {
  left: 50%;
  top: 50%;
  -webkit-transform: translate(-50%, -50%);
          transform: translate(-50%, -50%);
  -webkit-transform-origin: center center;
          transform-origin: center center;
}

.fa-layers-counter {
  background-color: var(--fa-counter-background-color, #ff253a);
  border-radius: var(--fa-counter-border-radius, 1em);
  box-sizing: border-box;
  color: var(--fa-inverse, #fff);
  line-height: var(--fa-counter-line-height, 1);
  max-width: var(--fa-counter-max-width, 5em);
  min-width: var(--fa-counter-min-width, 1.5em);
  overflow: hidden;
  padding: var(--fa-counter-padding, 0.25em 0.5em);
  right: var(--fa-right, 0);
  text-overflow: ellipsis;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-counter-scale, 0.25));
          transform: scale(var(--fa-counter-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-bottom-right {
  bottom: var(--fa-bottom, 0);
  right: var(--fa-right, 0);
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom right;
          transform-origin: bottom right;
}

.fa-layers-bottom-left {
  bottom: var(--fa-bottom, 0);
  left: var(--fa-left, 0);
  right: auto;
  top: auto;
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: bottom left;
          transform-origin: bottom left;
}

.fa-layers-top-right {
  top: var(--fa-top, 0);
  right: var(--fa-right, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top right;
          transform-origin: top right;
}

.fa-layers-top-left {
  left: var(--fa-left, 0);
  right: auto;
  top: var(--fa-top, 0);
  -webkit-transform: scale(var(--fa-layers-scale, 0.25));
          transform: scale(var(--fa-layers-scale, 0.25));
  -webkit-transform-origin: top left;
          transform-origin: top left;
}

.fa-1x {
  font-size: 1em;
}

.fa-2x {
  font-size: 2em;
}

.fa-3x {
  font-size: 3em;
}

.fa-4x {
  font-size: 4em;
}

.fa-5x {
  font-size: 5em;
}

.fa-6x {
  font-size: 6em;
}

.fa-7x {
  font-size: 7em;
}

.fa-8x {
  font-size: 8em;
}

.fa-9x {
  font-size: 9em;
}

.fa-10x {
  font-size: 10em;
}

.fa-2xs {
  font-size: 0.625em;
  line-height: 0.1em;
  vertical-align: 0.225em;
}

.fa-xs {
  font-size: 0.75em;
  line-height: 0.0833333337em;
  vertical-align: 0.125em;
}

.fa-sm {
  font-size: 0.875em;
  line-height: 0.0714285718em;
  vertical-align: 0.0535714295em;
}

.fa-lg {
  font-size: 1.25em;
  line-height: 0.05em;
  vertical-align: -0.075em;
}

.fa-xl {
  font-size: 1.5em;
  line-height: 0.0416666682em;
  vertical-align: -0.125em;
}

.fa-2xl {
  font-size: 2em;
  line-height: 0.03125em;
  vertical-align: -0.1875em;
}

.fa-fw {
  text-align: center;
  width: 1.25em;
}

.fa-ul {
  list-style-type: none;
  margin-left: var(--fa-li-margin, 2.5em);
  padding-left: 0;
}
.fa-ul > li {
  position: relative;
}

.fa-li {
  left: calc(var(--fa-li-width, 2em) * -1);
  position: absolute;
  text-align: center;
  width: var(--fa-li-width, 2em);
  line-height: inherit;
}

.fa-border {
  border-color: var(--fa-border-color, #eee);
  border-radius: var(--fa-border-radius, 0.1em);
  border-style: var(--fa-border-style, solid);
  border-width: var(--fa-border-width, 0.08em);
  padding: var(--fa-border-padding, 0.2em 0.25em 0.15em);
}

.fa-pull-left {
  float: left;
  margin-right: var(--fa-pull-margin, 0.3em);
}

.fa-pull-right {
  float: right;
  margin-left: var(--fa-pull-margin, 0.3em);
}

.fa-beat {
  -webkit-animation-name: fa-beat;
          animation-name: fa-beat;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-bounce {
  -webkit-animation-name: fa-bounce;
          animation-name: fa-bounce;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.28, 0.84, 0.42, 1));
}

.fa-fade {
  -webkit-animation-name: fa-fade;
          animation-name: fa-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-beat-fade {
  -webkit-animation-name: fa-beat-fade;
          animation-name: fa-beat-fade;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
          animation-timing-function: var(--fa-animation-timing, cubic-bezier(0.4, 0, 0.6, 1));
}

.fa-flip {
  -webkit-animation-name: fa-flip;
          animation-name: fa-flip;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, ease-in-out);
          animation-timing-function: var(--fa-animation-timing, ease-in-out);
}

.fa-shake {
  -webkit-animation-name: fa-shake;
          animation-name: fa-shake;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-delay: var(--fa-animation-delay, 0s);
          animation-delay: var(--fa-animation-delay, 0s);
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 2s);
          animation-duration: var(--fa-animation-duration, 2s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, linear);
          animation-timing-function: var(--fa-animation-timing, linear);
}

.fa-spin-reverse {
  --fa-animation-direction: reverse;
}

.fa-pulse,
.fa-spin-pulse {
  -webkit-animation-name: fa-spin;
          animation-name: fa-spin;
  -webkit-animation-direction: var(--fa-animation-direction, normal);
          animation-direction: var(--fa-animation-direction, normal);
  -webkit-animation-duration: var(--fa-animation-duration, 1s);
          animation-duration: var(--fa-animation-duration, 1s);
  -webkit-animation-iteration-count: var(--fa-animation-iteration-count, infinite);
          animation-iteration-count: var(--fa-animation-iteration-count, infinite);
  -webkit-animation-timing-function: var(--fa-animation-timing, steps(8));
          animation-timing-function: var(--fa-animation-timing, steps(8));
}

@media (prefers-reduced-motion: reduce) {
  .fa-beat,
.fa-bounce,
.fa-fade,
.fa-beat-fade,
.fa-flip,
.fa-pulse,
.fa-shake,
.fa-spin,
.fa-spin-pulse {
    -webkit-animation-delay: -1ms;
            animation-delay: -1ms;
    -webkit-animation-duration: 1ms;
            animation-duration: 1ms;
    -webkit-animation-iteration-count: 1;
            animation-iteration-count: 1;
    -webkit-transition-delay: 0s;
            transition-delay: 0s;
    -webkit-transition-duration: 0s;
            transition-duration: 0s;
  }
}
@-webkit-keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@keyframes fa-beat {
  0%, 90% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  45% {
    -webkit-transform: scale(var(--fa-beat-scale, 1.25));
            transform: scale(var(--fa-beat-scale, 1.25));
  }
}
@-webkit-keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@keyframes fa-bounce {
  0% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  10% {
    -webkit-transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
            transform: scale(var(--fa-bounce-start-scale-x, 1.1), var(--fa-bounce-start-scale-y, 0.9)) translateY(0);
  }
  30% {
    -webkit-transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
            transform: scale(var(--fa-bounce-jump-scale-x, 0.9), var(--fa-bounce-jump-scale-y, 1.1)) translateY(var(--fa-bounce-height, -0.5em));
  }
  50% {
    -webkit-transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
            transform: scale(var(--fa-bounce-land-scale-x, 1.05), var(--fa-bounce-land-scale-y, 0.95)) translateY(0);
  }
  57% {
    -webkit-transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
            transform: scale(1, 1) translateY(var(--fa-bounce-rebound, -0.125em));
  }
  64% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
  100% {
    -webkit-transform: scale(1, 1) translateY(0);
            transform: scale(1, 1) translateY(0);
  }
}
@-webkit-keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@keyframes fa-fade {
  50% {
    opacity: var(--fa-fade-opacity, 0.4);
  }
}
@-webkit-keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@keyframes fa-beat-fade {
  0%, 100% {
    opacity: var(--fa-beat-fade-opacity, 0.4);
    -webkit-transform: scale(1);
            transform: scale(1);
  }
  50% {
    opacity: 1;
    -webkit-transform: scale(var(--fa-beat-fade-scale, 1.125));
            transform: scale(var(--fa-beat-fade-scale, 1.125));
  }
}
@-webkit-keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@keyframes fa-flip {
  50% {
    -webkit-transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
            transform: rotate3d(var(--fa-flip-x, 0), var(--fa-flip-y, 1), var(--fa-flip-z, 0), var(--fa-flip-angle, -180deg));
  }
}
@-webkit-keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@keyframes fa-shake {
  0% {
    -webkit-transform: rotate(-15deg);
            transform: rotate(-15deg);
  }
  4% {
    -webkit-transform: rotate(15deg);
            transform: rotate(15deg);
  }
  8%, 24% {
    -webkit-transform: rotate(-18deg);
            transform: rotate(-18deg);
  }
  12%, 28% {
    -webkit-transform: rotate(18deg);
            transform: rotate(18deg);
  }
  16% {
    -webkit-transform: rotate(-22deg);
            transform: rotate(-22deg);
  }
  20% {
    -webkit-transform: rotate(22deg);
            transform: rotate(22deg);
  }
  32% {
    -webkit-transform: rotate(-12deg);
            transform: rotate(-12deg);
  }
  36% {
    -webkit-transform: rotate(12deg);
            transform: rotate(12deg);
  }
  40%, 100% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
}
@-webkit-keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
@keyframes fa-spin {
  0% {
    -webkit-transform: rotate(0deg);
            transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
            transform: rotate(360deg);
  }
}
.fa-rotate-90 {
  -webkit-transform: rotate(90deg);
          transform: rotate(90deg);
}

.fa-rotate-180 {
  -webkit-transform: rotate(180deg);
          transform: rotate(180deg);
}

.fa-rotate-270 {
  -webkit-transform: rotate(270deg);
          transform: rotate(270deg);
}

.fa-flip-horizontal {
  -webkit-transform: scale(-1, 1);
          transform: scale(-1, 1);
}

.fa-flip-vertical {
  -webkit-transform: scale(1, -1);
          transform: scale(1, -1);
}

.fa-flip-both,
.fa-flip-horizontal.fa-flip-vertical {
  -webkit-transform: scale(-1, -1);
          transform: scale(-1, -1);
}

.fa-rotate-by {
  -webkit-transform: rotate(var(--fa-rotate-angle, 0));
          transform: rotate(var(--fa-rotate-angle, 0));
}

.fa-stack {
  display: inline-block;
  vertical-align: middle;
  height: 2em;
  position: relative;
  width: 2.5em;
}

.fa-stack-1x,
.fa-stack-2x {
  bottom: 0;
  left: 0;
  margin: auto;
  position: absolute;
  right: 0;
  top: 0;
  z-index: var(--fa-stack-z-index, auto);
}

.svg-inline--fa.fa-stack-1x {
  height: 1em;
  width: 1.25em;
}
.svg-inline--fa.fa-stack-2x {
  height: 2em;
  width: 2.5em;
}

.fa-inverse {
  color: var(--fa-inverse, #fff);
}

.sr-only,
.fa-sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.sr-only-focusable:not(:focus),
.fa-sr-only-focusable:not(:focus) {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  white-space: nowrap;
  border-width: 0;
}

.svg-inline--fa .fa-primary {
  fill: var(--fa-primary-color, currentColor);
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa .fa-secondary {
  fill: var(--fa-secondary-color, currentColor);
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-primary {
  opacity: var(--fa-secondary-opacity, 0.4);
}

.svg-inline--fa.fa-swap-opacity .fa-secondary {
  opacity: var(--fa-primary-opacity, 1);
}

.svg-inline--fa mask .fa-primary,
.svg-inline--fa mask .fa-secondary {
  fill: black;
}

.fad.fa-inverse,
.fa-duotone.fa-inverse {
  color: var(--fa-inverse, #fff);
}`;function Kn(){var a=Un,n=Vn,t=v.cssPrefix,e=v.replacementClass,r=Qt;if(t!==a||e!==n){var i=new RegExp("\\.".concat(a,"\\-"),"g"),o=new RegExp("\\--".concat(a,"\\-"),"g"),s=new RegExp("\\.".concat(n),"g");r=r.replace(i,".".concat(t,"-")).replace(o,"--".concat(t,"-")).replace(s,".".concat(e))}return r}var hn=!1;function Ia(){v.autoAddCss&&!hn&&(Gt(Kn()),hn=!0)}var Jt={mixout:function(){return{dom:{css:Kn,insertCss:Ia}}},hooks:function(){return{beforeDOMElementCreation:function(){Ia()},beforeI2svg:function(){Ia()}}}},L=R||{};L[T]||(L[T]={});L[T].styles||(L[T].styles={});L[T].hooks||(L[T].hooks={});L[T].shims||(L[T].shims=[]);var M=L[T],Qn=[],Zt=function a(){p.removeEventListener("DOMContentLoaded",a),Aa=1,Qn.map(function(n){return n()})},Aa=!1;D&&(Aa=(p.documentElement.doScroll?/^loaded|^c/:/^loaded|^i|^c/).test(p.readyState),Aa||p.addEventListener("DOMContentLoaded",Zt));function ae(a){D&&(Aa?setTimeout(a,0):Qn.push(a))}function ca(a){var n=a.tag,t=a.attributes,e=t===void 0?{}:t,r=a.children,i=r===void 0?[]:r;return typeof a=="string"?qn(a):"<".concat(n," ").concat(Bt(e),">").concat(i.map(ca).join(""),"</").concat(n,">")}function bn(a,n,t){if(a&&a[n]&&a[n][t])return{prefix:n,iconName:t,icon:a[n][t]}}var xa=function(n,t,e,r){var i=Object.keys(n),o=i.length,s=t,f,c,l;for(e===void 0?(f=1,l=n[i[0]]):(f=0,l=e);f<o;f++)c=i[f],l=s(l,n[c],c,n);return l};function ne(a){for(var n=[],t=0,e=a.length;t<e;){var r=a.charCodeAt(t++);if(r>=55296&&r<=56319&&t<e){var i=a.charCodeAt(t++);(i&64512)==56320?n.push(((r&1023)<<10)+(i&1023)+65536):(n.push(r),t--)}else n.push(r)}return n}function Ra(a){var n=ne(a);return n.length===1?n[0].toString(16):null}function te(a,n){var t=a.length,e=a.charCodeAt(n),r;return e>=55296&&e<=56319&&t>n+1&&(r=a.charCodeAt(n+1),r>=56320&&r<=57343)?(e-55296)*1024+r-56320+65536:e}function pn(a){return Object.keys(a).reduce(function(n,t){var e=a[t],r=!!e.icon;return r?n[e.iconName]=e.icon:n[t]=e,n},{})}function Fa(a,n){var t=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{},e=t.skipHooks,r=e===void 0?!1:e,i=pn(n);typeof M.hooks.addPack=="function"&&!r?M.hooks.addPack(a,pn(n)):M.styles[a]=u(u({},M.styles[a]||{}),i),a==="fas"&&Fa("fa",n)}var ba,pa,ya,B=M.styles,ee=M.shims,re=(ba={},O(ba,b,Object.values(ia[b])),O(ba,y,Object.values(ia[y])),ba),en=null,Jn={},Zn={},at={},nt={},tt={},ie=(pa={},O(pa,b,Object.keys(ea[b])),O(pa,y,Object.keys(ea[y])),pa);function oe(a){return~Yt.indexOf(a)}function se(a,n){var t=n.split("-"),e=t[0],r=t.slice(1).join("-");return e===a&&r!==""&&!oe(r)?r:null}var et=function(){var n=function(i){return xa(B,function(o,s,f){return o[f]=xa(s,i,{}),o},{})};Jn=n(function(r,i,o){if(i[3]&&(r[i[3]]=o),i[2]){var s=i[2].filter(function(f){return typeof f=="number"});s.forEach(function(f){r[f.toString(16)]=o})}return r}),Zn=n(function(r,i,o){if(r[o]=o,i[2]){var s=i[2].filter(function(f){return typeof f=="string"});s.forEach(function(f){r[f]=o})}return r}),tt=n(function(r,i,o){var s=i[2];return r[o]=o,s.forEach(function(f){r[f]=o}),r});var t="far"in B||v.autoFetchSvg,e=xa(ee,function(r,i){var o=i[0],s=i[1],f=i[2];return s==="far"&&!t&&(s="fas"),typeof o=="string"&&(r.names[o]={prefix:s,iconName:f}),typeof o=="number"&&(r.unicodes[o.toString(16)]={prefix:s,iconName:f}),r},{names:{},unicodes:{}});at=e.names,nt=e.unicodes,en=Ca(v.styleDefault,{family:v.familyDefault})};Wt(function(a){en=Ca(a.styleDefault,{family:v.familyDefault})});et();function rn(a,n){return(Jn[a]||{})[n]}function fe(a,n){return(Zn[a]||{})[n]}function W(a,n){return(tt[a]||{})[n]}function rt(a){return at[a]||{prefix:null,iconName:null}}function le(a){var n=nt[a],t=rn("fas",a);return n||(t?{prefix:"fas",iconName:t}:null)||{prefix:null,iconName:null}}function F(){return en}var on=function(){return{prefix:null,iconName:null,rest:[]}};function Ca(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},t=n.family,e=t===void 0?b:t,r=ea[e][a],i=ra[e][a]||ra[e][r],o=a in M.styles?a:null;return i||o||null}var yn=(ya={},O(ya,b,Object.keys(ia[b])),O(ya,y,Object.keys(ia[y])),ya);function _a(a){var n,t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},e=t.skipLookups,r=e===void 0?!1:e,i=(n={},O(n,b,"".concat(v.cssPrefix,"-").concat(b)),O(n,y,"".concat(v.cssPrefix,"-").concat(y)),n),o=null,s=b;(a.includes(i[b])||a.some(function(c){return yn[b].includes(c)}))&&(s=b),(a.includes(i[y])||a.some(function(c){return yn[y].includes(c)}))&&(s=y);var f=a.reduce(function(c,l){var m=se(v.cssPrefix,l);if(B[l]?(l=re[s].includes(l)?zt[s][l]:l,o=l,c.prefix=l):ie[s].indexOf(l)>-1?(o=l,c.prefix=Ca(l,{family:s})):m?c.iconName=m:l!==v.replacementClass&&l!==i[b]&&l!==i[y]&&c.rest.push(l),!r&&c.prefix&&c.iconName){var d=o==="fa"?rt(c.iconName):{},h=W(c.prefix,c.iconName);d.prefix&&(o=null),c.iconName=d.iconName||h||c.iconName,c.prefix=d.prefix||c.prefix,c.prefix==="far"&&!B.far&&B.fas&&!v.autoFetchSvg&&(c.prefix="fas")}return c},on());return(a.includes("fa-brands")||a.includes("fab"))&&(f.prefix="fab"),(a.includes("fa-duotone")||a.includes("fad"))&&(f.prefix="fad"),!f.prefix&&s===y&&(B.fass||v.autoFetchSvg)&&(f.prefix="fass",f.iconName=W(f.prefix,f.iconName)||f.iconName),(f.prefix==="fa"||o==="fa")&&(f.prefix=F()||"fas"),f}var ce=function(){function a(){Pt(this,a),this.definitions={}}return Ot(a,[{key:"add",value:function(){for(var t=this,e=arguments.length,r=new Array(e),i=0;i<e;i++)r[i]=arguments[i];var o=r.reduce(this._pullDefinitions,{});Object.keys(o).forEach(function(s){t.definitions[s]=u(u({},t.definitions[s]||{}),o[s]),Fa(s,o[s]);var f=ia[b][s];f&&Fa(f,o[s]),et()})}},{key:"reset",value:function(){this.definitions={}}},{key:"_pullDefinitions",value:function(t,e){var r=e.prefix&&e.iconName&&e.icon?{0:e}:e;return Object.keys(r).map(function(i){var o=r[i],s=o.prefix,f=o.iconName,c=o.icon,l=c[2];t[s]||(t[s]={}),l.length>0&&l.forEach(function(m){typeof m=="string"&&(t[s][m]=c)}),t[s][f]=c}),t}}]),a}(),wn=[],q={},Q={},ue=Object.keys(Q);function me(a,n){var t=n.mixoutsTo;return wn=a,q={},Object.keys(Q).forEach(function(e){ue.indexOf(e)===-1&&delete Q[e]}),wn.forEach(function(e){var r=e.mixout?e.mixout():{};if(Object.keys(r).forEach(function(o){typeof r[o]=="function"&&(t[o]=r[o]),Pa(r[o])==="object"&&Object.keys(r[o]).forEach(function(s){t[o]||(t[o]={}),t[o][s]=r[o][s]})}),e.hooks){var i=e.hooks();Object.keys(i).forEach(function(o){q[o]||(q[o]=[]),q[o].push(i[o])})}e.provides&&e.provides(Q)}),t}function Ya(a,n){for(var t=arguments.length,e=new Array(t>2?t-2:0),r=2;r<t;r++)e[r-2]=arguments[r];var i=q[a]||[];return i.forEach(function(o){n=o.apply(null,[n].concat(e))}),n}function X(a){for(var n=arguments.length,t=new Array(n>1?n-1:0),e=1;e<n;e++)t[e-1]=arguments[e];var r=q[a]||[];r.forEach(function(i){i.apply(null,t)})}function z(){var a=arguments[0],n=Array.prototype.slice.call(arguments,1);return Q[a]?Q[a].apply(null,n):void 0}function $a(a){a.prefix==="fa"&&(a.prefix="fas");var n=a.iconName,t=a.prefix||F();if(n)return n=W(t,n)||n,bn(it.definitions,t,n)||bn(M.styles,t,n)}var it=new ce,ve=function(){v.autoReplaceSvg=!1,v.observeMutations=!1,X("noAuto")},de={i2svg:function(){var n=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};return D?(X("beforeI2svg",n),z("pseudoElements2svg",n),z("i2svg",n)):Promise.reject("Operation requires a DOM of some kind.")},watch:function(){var n=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},t=n.autoReplaceSvgRoot;v.autoReplaceSvg===!1&&(v.autoReplaceSvg=!0),v.observeMutations=!0,ae(function(){he({autoReplaceSvgRoot:t}),X("watch",n)})}},ge={icon:function(n){if(n===null)return null;if(Pa(n)==="object"&&n.prefix&&n.iconName)return{prefix:n.prefix,iconName:W(n.prefix,n.iconName)||n.iconName};if(Array.isArray(n)&&n.length===2){var t=n[1].indexOf("fa-")===0?n[1].slice(3):n[1],e=Ca(n[0]);return{prefix:e,iconName:W(e,t)||t}}if(typeof n=="string"&&(n.indexOf("".concat(v.cssPrefix,"-"))>-1||n.match(Dt))){var r=_a(n.split(" "),{skipLookups:!0});return{prefix:r.prefix||F(),iconName:W(r.prefix,r.iconName)||r.iconName}}if(typeof n=="string"){var i=F();return{prefix:i,iconName:W(i,n)||n}}}},E={noAuto:ve,config:v,dom:de,parse:ge,library:it,findIconDefinition:$a,toHtml:ca},he=function(){var n=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},t=n.autoReplaceSvgRoot,e=t===void 0?p:t;(Object.keys(M.styles).length>0||v.autoFetchSvg)&&D&&v.autoReplaceSvg&&E.dom.i2svg({node:e})};function Ea(a,n){return Object.defineProperty(a,"abstract",{get:n}),Object.defineProperty(a,"html",{get:function(){return a.abstract.map(function(e){return ca(e)})}}),Object.defineProperty(a,"node",{get:function(){if(D){var e=p.createElement("div");return e.innerHTML=a.html,e.children}}}),a}function be(a){var n=a.children,t=a.main,e=a.mask,r=a.attributes,i=a.styles,o=a.transform;if(tn(o)&&t.found&&!e.found){var s=t.width,f=t.height,c={x:s/f/2,y:.5};r.style=Sa(u(u({},i),{},{"transform-origin":"".concat(c.x+o.x/16,"em ").concat(c.y+o.y/16,"em")}))}return[{tag:"svg",attributes:r,children:n}]}function pe(a){var n=a.prefix,t=a.iconName,e=a.children,r=a.attributes,i=a.symbol,o=i===!0?"".concat(n,"-").concat(v.cssPrefix,"-").concat(t):i;return[{tag:"svg",attributes:{style:"display: none;"},children:[{tag:"symbol",attributes:u(u({},r),{},{id:o}),children:e}]}]}function sn(a){var n=a.icons,t=n.main,e=n.mask,r=a.prefix,i=a.iconName,o=a.transform,s=a.symbol,f=a.title,c=a.maskId,l=a.titleId,m=a.extra,d=a.watchable,h=d===void 0?!1:d,k=e.found?e:t,C=k.width,P=k.height,N=r==="fak",w=[v.replacementClass,i?"".concat(v.cssPrefix,"-").concat(i):""].filter(function(j){return m.classes.indexOf(j)===-1}).filter(function(j){return j!==""||!!j}).concat(m.classes).join(" "),A={children:[],attributes:u(u({},m.attributes),{},{"data-prefix":r,"data-icon":i,class:w,role:m.attributes.role||"img",xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 ".concat(C," ").concat(P)})},_=N&&!~m.classes.indexOf("fa-fw")?{width:"".concat(C/P*16*.0625,"em")}:{};h&&(A.attributes[G]=""),f&&(A.children.push({tag:"title",attributes:{id:A.attributes["aria-labelledby"]||"title-".concat(l||sa())},children:[f]}),delete A.attributes.title);var S=u(u({},A),{},{prefix:r,iconName:i,main:t,mask:e,maskId:c,transform:o,symbol:s,styles:u(u({},_),m.styles)}),$=e.found&&t.found?z("generateAbstractMask",S)||{children:[],attributes:{}}:z("generateAbstractIcon",S)||{children:[],attributes:{}},U=$.children,Ma=$.attributes;return S.children=U,S.attributes=Ma,s?pe(S):be(S)}function kn(a){var n=a.content,t=a.width,e=a.height,r=a.transform,i=a.title,o=a.extra,s=a.watchable,f=s===void 0?!1:s,c=u(u(u({},o.attributes),i?{title:i}:{}),{},{class:o.classes.join(" ")});f&&(c[G]="");var l=u({},o.styles);tn(r)&&(l.transform=Kt({transform:r,startCentered:!0,width:t,height:e}),l["-webkit-transform"]=l.transform);var m=Sa(l);m.length>0&&(c.style=m);var d=[];return d.push({tag:"span",attributes:c,children:[n]}),i&&d.push({tag:"span",attributes:{class:"sr-only"},children:[i]}),d}function ye(a){var n=a.content,t=a.title,e=a.extra,r=u(u(u({},e.attributes),t?{title:t}:{}),{},{class:e.classes.join(" ")}),i=Sa(e.styles);i.length>0&&(r.style=i);var o=[];return o.push({tag:"span",attributes:r,children:[n]}),t&&o.push({tag:"span",attributes:{class:"sr-only"},children:[t]}),o}var Ta=M.styles;function Ua(a){var n=a[0],t=a[1],e=a.slice(4),r=Ka(e,1),i=r[0],o=null;return Array.isArray(i)?o={tag:"g",attributes:{class:"".concat(v.cssPrefix,"-").concat(V.GROUP)},children:[{tag:"path",attributes:{class:"".concat(v.cssPrefix,"-").concat(V.SECONDARY),fill:"currentColor",d:i[0]}},{tag:"path",attributes:{class:"".concat(v.cssPrefix,"-").concat(V.PRIMARY),fill:"currentColor",d:i[1]}}]}:o={tag:"path",attributes:{fill:"currentColor",d:i}},{found:!0,width:n,height:t,icon:o}}var we={found:!1,width:512,height:512};function ke(a,n){!Wn&&!v.showMissingIcons&&a&&console.error('Icon with name "'.concat(a,'" and prefix "').concat(n,'" is missing.'))}function Va(a,n){var t=n;return n==="fa"&&v.styleDefault!==null&&(n=F()),new Promise(function(e,r){if(z("missingIconAbstract"),t==="fa"){var i=rt(a)||{};a=i.iconName||a,n=i.prefix||n}if(a&&n&&Ta[n]&&Ta[n][a]){var o=Ta[n][a];return e(Ua(o))}ke(a,n),e(u(u({},we),{},{icon:v.showMissingIcons&&a?z("missingIconAbstract")||{}:{}}))})}var Pn=function(){},Wa=v.measurePerformance&&ua&&ua.mark&&ua.measure?ua:{mark:Pn,measure:Pn},aa='FA "6.5.2"',Pe=function(n){return Wa.mark("".concat(aa," ").concat(n," begins")),function(){return ot(n)}},ot=function(n){Wa.mark("".concat(aa," ").concat(n," ends")),Wa.measure("".concat(aa," ").concat(n),"".concat(aa," ").concat(n," begins"),"".concat(aa," ").concat(n," ends"))},fn={begin:Pe,end:ot},wa=function(){};function An(a){var n=a.getAttribute?a.getAttribute(G):null;return typeof n=="string"}function Ae(a){var n=a.getAttribute?a.getAttribute(Ja):null,t=a.getAttribute?a.getAttribute(Za):null;return n&&t}function Oe(a){return a&&a.classList&&a.classList.contains&&a.classList.contains(v.replacementClass)}function Ne(){if(v.autoReplaceSvg===!0)return ka.replace;var a=ka[v.autoReplaceSvg];return a||ka.replace}function Se(a){return p.createElementNS("http://www.w3.org/2000/svg",a)}function Ce(a){return p.createElement(a)}function st(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},t=n.ceFn,e=t===void 0?a.tag==="svg"?Se:Ce:t;if(typeof a=="string")return p.createTextNode(a);var r=e(a.tag);Object.keys(a.attributes||[]).forEach(function(o){r.setAttribute(o,a.attributes[o])});var i=a.children||[];return i.forEach(function(o){r.appendChild(st(o,{ceFn:e}))}),r}function _e(a){var n=" ".concat(a.outerHTML," ");return n="".concat(n,"Font Awesome fontawesome.com "),n}var ka={replace:function(n){var t=n[0];if(t.parentNode)if(n[1].forEach(function(r){t.parentNode.insertBefore(st(r),t)}),t.getAttribute(G)===null&&v.keepOriginalSource){var e=p.createComment(_e(t));t.parentNode.replaceChild(e,t)}else t.remove()},nest:function(n){var t=n[0],e=n[1];if(~nn(t).indexOf(v.replacementClass))return ka.replace(n);var r=new RegExp("".concat(v.cssPrefix,"-.*"));if(delete e[0].attributes.id,e[0].attributes.class){var i=e[0].attributes.class.split(" ").reduce(function(s,f){return f===v.replacementClass||f.match(r)?s.toSvg.push(f):s.toNode.push(f),s},{toNode:[],toSvg:[]});e[0].attributes.class=i.toSvg.join(" "),i.toNode.length===0?t.removeAttribute("class"):t.setAttribute("class",i.toNode.join(" "))}var o=e.map(function(s){return ca(s)}).join(`
`);t.setAttribute(G,""),t.innerHTML=o}};function On(a){a()}function ft(a,n){var t=typeof n=="function"?n:wa;if(a.length===0)t();else{var e=On;v.mutateApproach===Tt&&(e=R.requestAnimationFrame||On),e(function(){var r=Ne(),i=fn.begin("mutate");a.map(r),i(),t()})}}var ln=!1;function lt(){ln=!0}function Ga(){ln=!1}var Oa=null;function Nn(a){if(dn&&v.observeMutations){var n=a.treeCallback,t=n===void 0?wa:n,e=a.nodeCallback,r=e===void 0?wa:e,i=a.pseudoElementsCallback,o=i===void 0?wa:i,s=a.observeMutationsRoot,f=s===void 0?p:s;Oa=new dn(function(c){if(!ln){var l=F();Z(c).forEach(function(m){if(m.type==="childList"&&m.addedNodes.length>0&&!An(m.addedNodes[0])&&(v.searchPseudoElements&&o(m.target),t(m.target)),m.type==="attributes"&&m.target.parentNode&&v.searchPseudoElements&&o(m.target.parentNode),m.type==="attributes"&&An(m.target)&&~Ft.indexOf(m.attributeName))if(m.attributeName==="class"&&Ae(m.target)){var d=_a(nn(m.target)),h=d.prefix,k=d.iconName;m.target.setAttribute(Ja,h||l),k&&m.target.setAttribute(Za,k)}else Oe(m.target)&&r(m.target)})}}),D&&Oa.observe(f,{childList:!0,attributes:!0,characterData:!0,subtree:!0})}}function Ee(){Oa&&Oa.disconnect()}function Me(a){var n=a.getAttribute("style"),t=[];return n&&(t=n.split(";").reduce(function(e,r){var i=r.split(":"),o=i[0],s=i.slice(1);return o&&s.length>0&&(e[o]=s.join(":").trim()),e},{})),t}function Ie(a){var n=a.getAttribute("data-prefix"),t=a.getAttribute("data-icon"),e=a.innerText!==void 0?a.innerText.trim():"",r=_a(nn(a));return r.prefix||(r.prefix=F()),n&&t&&(r.prefix=n,r.iconName=t),r.iconName&&r.prefix||(r.prefix&&e.length>0&&(r.iconName=fe(r.prefix,a.innerText)||rn(r.prefix,Ra(a.innerText))),!r.iconName&&v.autoFetchSvg&&a.firstChild&&a.firstChild.nodeType===Node.TEXT_NODE&&(r.iconName=a.firstChild.data)),r}function xe(a){var n=Z(a.attributes).reduce(function(r,i){return r.name!=="class"&&r.name!=="style"&&(r[i.name]=i.value),r},{}),t=a.getAttribute("title"),e=a.getAttribute("data-fa-title-id");return v.autoA11y&&(t?n["aria-labelledby"]="".concat(v.replacementClass,"-title-").concat(e||sa()):(n["aria-hidden"]="true",n.focusable="false")),n}function Te(){return{iconName:null,title:null,titleId:null,prefix:null,transform:x,symbol:!1,mask:{iconName:null,prefix:null,rest:[]},maskId:null,extra:{classes:[],styles:{},attributes:{}}}}function Sn(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{styleParser:!0},t=Ie(a),e=t.iconName,r=t.prefix,i=t.rest,o=xe(a),s=Ya("parseNodeAttributes",{},a),f=n.styleParser?Me(a):[];return u({iconName:e,title:a.getAttribute("title"),titleId:a.getAttribute("data-fa-title-id"),prefix:r,transform:x,mask:{iconName:null,prefix:null,rest:[]},maskId:null,symbol:!1,extra:{classes:i,styles:f,attributes:o}},s)}var Le=M.styles;function ct(a){var n=v.autoReplaceSvg==="nest"?Sn(a,{styleParser:!1}):Sn(a);return~n.extra.classes.indexOf(Gn)?z("generateLayersText",a,n):z("generateSvgReplacementMutation",a,n)}var Y=new Set;an.map(function(a){Y.add("fa-".concat(a))});Object.keys(ea[b]).map(Y.add.bind(Y));Object.keys(ea[y]).map(Y.add.bind(Y));Y=fa(Y);function Cn(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;if(!D)return Promise.resolve();var t=p.documentElement.classList,e=function(m){return t.add("".concat(gn,"-").concat(m))},r=function(m){return t.remove("".concat(gn,"-").concat(m))},i=v.autoFetchSvg?Y:an.map(function(l){return"fa-".concat(l)}).concat(Object.keys(Le));i.includes("fa")||i.push("fa");var o=[".".concat(Gn,":not([").concat(G,"])")].concat(i.map(function(l){return".".concat(l,":not([").concat(G,"])")})).join(", ");if(o.length===0)return Promise.resolve();var s=[];try{s=Z(a.querySelectorAll(o))}catch{}if(s.length>0)e("pending"),r("complete");else return Promise.resolve();var f=fn.begin("onTree"),c=s.reduce(function(l,m){try{var d=ct(m);d&&l.push(d)}catch(h){Wn||h.name==="MissingIcon"&&console.error(h)}return l},[]);return new Promise(function(l,m){Promise.all(c).then(function(d){ft(d,function(){e("active"),e("complete"),r("pending"),typeof n=="function"&&n(),f(),l()})}).catch(function(d){f(),m(d)})})}function ze(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:null;ct(a).then(function(t){t&&ft([t],n)})}function De(a){return function(n){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},e=(n||{}).icon?n:$a(n||{}),r=t.mask;return r&&(r=(r||{}).icon?r:$a(r||{})),a(e,u(u({},t),{},{mask:r}))}}var je=function(n){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},e=t.transform,r=e===void 0?x:e,i=t.symbol,o=i===void 0?!1:i,s=t.mask,f=s===void 0?null:s,c=t.maskId,l=c===void 0?null:c,m=t.title,d=m===void 0?null:m,h=t.titleId,k=h===void 0?null:h,C=t.classes,P=C===void 0?[]:C,N=t.attributes,w=N===void 0?{}:N,A=t.styles,_=A===void 0?{}:A;if(n){var S=n.prefix,$=n.iconName,U=n.icon;return Ea(u({type:"icon"},n),function(){return X("beforeDOMElementCreation",{iconDefinition:n,params:t}),v.autoA11y&&(d?w["aria-labelledby"]="".concat(v.replacementClass,"-title-").concat(k||sa()):(w["aria-hidden"]="true",w.focusable="false")),sn({icons:{main:Ua(U),mask:f?Ua(f.icon):{found:!1,width:null,height:null,icon:{}}},prefix:S,iconName:$,transform:u(u({},x),r),symbol:o,title:d,maskId:l,titleId:k,extra:{attributes:w,styles:_,classes:P}})})}},He={mixout:function(){return{icon:De(je)}},hooks:function(){return{mutationObserverCallbacks:function(t){return t.treeCallback=Cn,t.nodeCallback=ze,t}}},provides:function(n){n.i2svg=function(t){var e=t.node,r=e===void 0?p:e,i=t.callback,o=i===void 0?function(){}:i;return Cn(r,o)},n.generateSvgReplacementMutation=function(t,e){var r=e.iconName,i=e.title,o=e.titleId,s=e.prefix,f=e.transform,c=e.symbol,l=e.mask,m=e.maskId,d=e.extra;return new Promise(function(h,k){Promise.all([Va(r,s),l.iconName?Va(l.iconName,l.prefix):Promise.resolve({found:!1,width:512,height:512,icon:{}})]).then(function(C){var P=Ka(C,2),N=P[0],w=P[1];h([t,sn({icons:{main:N,mask:w},prefix:s,iconName:r,transform:f,symbol:c,maskId:m,title:i,titleId:o,extra:d,watchable:!0})])}).catch(k)})},n.generateAbstractIcon=function(t){var e=t.children,r=t.attributes,i=t.main,o=t.transform,s=t.styles,f=Sa(s);f.length>0&&(r.style=f);var c;return tn(o)&&(c=z("generateAbstractTransformGrouping",{main:i,transform:o,containerWidth:i.width,iconWidth:i.width})),e.push(c||i.icon),{children:e,attributes:r}}}},Re={mixout:function(){return{layer:function(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=e.classes,i=r===void 0?[]:r;return Ea({type:"layer"},function(){X("beforeDOMElementCreation",{assembler:t,params:e});var o=[];return t(function(s){Array.isArray(s)?s.map(function(f){o=o.concat(f.abstract)}):o=o.concat(s.abstract)}),[{tag:"span",attributes:{class:["".concat(v.cssPrefix,"-layers")].concat(fa(i)).join(" ")},children:o}]})}}}},Fe={mixout:function(){return{counter:function(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=e.title,i=r===void 0?null:r,o=e.classes,s=o===void 0?[]:o,f=e.attributes,c=f===void 0?{}:f,l=e.styles,m=l===void 0?{}:l;return Ea({type:"counter",content:t},function(){return X("beforeDOMElementCreation",{content:t,params:e}),ye({content:t.toString(),title:i,extra:{attributes:c,styles:m,classes:["".concat(v.cssPrefix,"-layers-counter")].concat(fa(s))}})})}}}},Ye={mixout:function(){return{text:function(t){var e=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=e.transform,i=r===void 0?x:r,o=e.title,s=o===void 0?null:o,f=e.classes,c=f===void 0?[]:f,l=e.attributes,m=l===void 0?{}:l,d=e.styles,h=d===void 0?{}:d;return Ea({type:"text",content:t},function(){return X("beforeDOMElementCreation",{content:t,params:e}),kn({content:t,transform:u(u({},x),i),title:s,extra:{attributes:m,styles:h,classes:["".concat(v.cssPrefix,"-layers-text")].concat(fa(c))}})})}}},provides:function(n){n.generateLayersText=function(t,e){var r=e.title,i=e.transform,o=e.extra,s=null,f=null;if($n){var c=parseInt(getComputedStyle(t).fontSize,10),l=t.getBoundingClientRect();s=l.width/c,f=l.height/c}return v.autoA11y&&!r&&(o.attributes["aria-hidden"]="true"),Promise.resolve([t,kn({content:t.innerHTML,width:s,height:f,transform:i,title:r,extra:o,watchable:!0})])}}},$e=new RegExp('"',"ug"),_n=[1105920,1112319];function Ue(a){var n=a.replace($e,""),t=te(n,0),e=t>=_n[0]&&t<=_n[1],r=n.length===2?n[0]===n[1]:!1;return{value:Ra(r?n[0]:n),isSecondary:e||r}}function En(a,n){var t="".concat(xt).concat(n.replace(":","-"));return new Promise(function(e,r){if(a.getAttribute(t)!==null)return e();var i=Z(a.children),o=i.filter(function(U){return U.getAttribute(Ha)===n})[0],s=R.getComputedStyle(a,n),f=s.getPropertyValue("font-family").match(jt),c=s.getPropertyValue("font-weight"),l=s.getPropertyValue("content");if(o&&!f)return a.removeChild(o),e();if(f&&l!=="none"&&l!==""){var m=s.getPropertyValue("content"),d=~["Sharp"].indexOf(f[2])?y:b,h=~["Solid","Regular","Light","Thin","Duotone","Brands","Kit"].indexOf(f[2])?ra[d][f[2].toLowerCase()]:Ht[d][c],k=Ue(m),C=k.value,P=k.isSecondary,N=f[0].startsWith("FontAwesome"),w=rn(h,C),A=w;if(N){var _=le(C);_.iconName&&_.prefix&&(w=_.iconName,h=_.prefix)}if(w&&!P&&(!o||o.getAttribute(Ja)!==h||o.getAttribute(Za)!==A)){a.setAttribute(t,A),o&&a.removeChild(o);var S=Te(),$=S.extra;$.attributes[Ha]=n,Va(w,h).then(function(U){var Ma=sn(u(u({},S),{},{icons:{main:U,mask:on()},prefix:h,iconName:A,extra:$,watchable:!0})),j=p.createElementNS("http://www.w3.org/2000/svg","svg");n==="::before"?a.insertBefore(j,a.firstChild):a.appendChild(j),j.outerHTML=Ma.map(function(kt){return ca(kt)}).join(`
`),a.removeAttribute(t),e()}).catch(r)}else e()}else e()})}function Ve(a){return Promise.all([En(a,"::before"),En(a,"::after")])}function We(a){return a.parentNode!==document.head&&!~Lt.indexOf(a.tagName.toUpperCase())&&!a.getAttribute(Ha)&&(!a.parentNode||a.parentNode.tagName!=="svg")}function Mn(a){if(D)return new Promise(function(n,t){var e=Z(a.querySelectorAll("*")).filter(We).map(Ve),r=fn.begin("searchPseudoElements");lt(),Promise.all(e).then(function(){r(),Ga(),n()}).catch(function(){r(),Ga(),t()})})}var Ge={hooks:function(){return{mutationObserverCallbacks:function(t){return t.pseudoElementsCallback=Mn,t}}},provides:function(n){n.pseudoElements2svg=function(t){var e=t.node,r=e===void 0?p:e;v.searchPseudoElements&&Mn(r)}}},In=!1,Xe={mixout:function(){return{dom:{unwatch:function(){lt(),In=!0}}}},hooks:function(){return{bootstrap:function(){Nn(Ya("mutationObserverCallbacks",{}))},noAuto:function(){Ee()},watch:function(t){var e=t.observeMutationsRoot;In?Ga():Nn(Ya("mutationObserverCallbacks",{observeMutationsRoot:e}))}}}},xn=function(n){var t={size:16,x:0,y:0,flipX:!1,flipY:!1,rotate:0};return n.toLowerCase().split(" ").reduce(function(e,r){var i=r.toLowerCase().split("-"),o=i[0],s=i.slice(1).join("-");if(o&&s==="h")return e.flipX=!0,e;if(o&&s==="v")return e.flipY=!0,e;if(s=parseFloat(s),isNaN(s))return e;switch(o){case"grow":e.size=e.size+s;break;case"shrink":e.size=e.size-s;break;case"left":e.x=e.x-s;break;case"right":e.x=e.x+s;break;case"up":e.y=e.y-s;break;case"down":e.y=e.y+s;break;case"rotate":e.rotate=e.rotate+s;break}return e},t)},Be={mixout:function(){return{parse:{transform:function(t){return xn(t)}}}},hooks:function(){return{parseNodeAttributes:function(t,e){var r=e.getAttribute("data-fa-transform");return r&&(t.transform=xn(r)),t}}},provides:function(n){n.generateAbstractTransformGrouping=function(t){var e=t.main,r=t.transform,i=t.containerWidth,o=t.iconWidth,s={transform:"translate(".concat(i/2," 256)")},f="translate(".concat(r.x*32,", ").concat(r.y*32,") "),c="scale(".concat(r.size/16*(r.flipX?-1:1),", ").concat(r.size/16*(r.flipY?-1:1),") "),l="rotate(".concat(r.rotate," 0 0)"),m={transform:"".concat(f," ").concat(c," ").concat(l)},d={transform:"translate(".concat(o/2*-1," -256)")},h={outer:s,inner:m,path:d};return{tag:"g",attributes:u({},h.outer),children:[{tag:"g",attributes:u({},h.inner),children:[{tag:e.icon.tag,children:e.icon.children,attributes:u(u({},e.icon.attributes),h.path)}]}]}}}},La={x:0,y:0,width:"100%",height:"100%"};function Tn(a){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:!0;return a.attributes&&(a.attributes.fill||n)&&(a.attributes.fill="black"),a}function qe(a){return a.tag==="g"?a.children:[a]}var Ke={hooks:function(){return{parseNodeAttributes:function(t,e){var r=e.getAttribute("data-fa-mask"),i=r?_a(r.split(" ").map(function(o){return o.trim()})):on();return i.prefix||(i.prefix=F()),t.mask=i,t.maskId=e.getAttribute("data-fa-mask-id"),t}}},provides:function(n){n.generateAbstractMask=function(t){var e=t.children,r=t.attributes,i=t.main,o=t.mask,s=t.maskId,f=t.transform,c=i.width,l=i.icon,m=o.width,d=o.icon,h=qt({transform:f,containerWidth:m,iconWidth:c}),k={tag:"rect",attributes:u(u({},La),{},{fill:"white"})},C=l.children?{children:l.children.map(Tn)}:{},P={tag:"g",attributes:u({},h.inner),children:[Tn(u({tag:l.tag,attributes:u(u({},l.attributes),h.path)},C))]},N={tag:"g",attributes:u({},h.outer),children:[P]},w="mask-".concat(s||sa()),A="clip-".concat(s||sa()),_={tag:"mask",attributes:u(u({},La),{},{id:w,maskUnits:"userSpaceOnUse",maskContentUnits:"userSpaceOnUse"}),children:[k,N]},S={tag:"defs",children:[{tag:"clipPath",attributes:{id:A},children:qe(d)},_]};return e.push(S,{tag:"rect",attributes:u({fill:"currentColor","clip-path":"url(#".concat(A,")"),mask:"url(#".concat(w,")")},La)}),{children:e,attributes:r}}}},Qe={provides:function(n){var t=!1;R.matchMedia&&(t=R.matchMedia("(prefers-reduced-motion: reduce)").matches),n.missingIconAbstract=function(){var e=[],r={fill:"currentColor"},i={attributeType:"XML",repeatCount:"indefinite",dur:"2s"};e.push({tag:"path",attributes:u(u({},r),{},{d:"M156.5,447.7l-12.6,29.5c-18.7-9.5-35.9-21.2-51.5-34.9l22.7-22.7C127.6,430.5,141.5,440,156.5,447.7z M40.6,272H8.5 c1.4,21.2,5.4,41.7,11.7,61.1L50,321.2C45.1,305.5,41.8,289,40.6,272z M40.6,240c1.4-18.8,5.2-37,11.1-54.1l-29.5-12.6 C14.7,194.3,10,216.7,8.5,240H40.6z M64.3,156.5c7.8-14.9,17.2-28.8,28.1-41.5L69.7,92.3c-13.7,15.6-25.5,32.8-34.9,51.5 L64.3,156.5z M397,419.6c-13.9,12-29.4,22.3-46.1,30.4l11.9,29.8c20.7-9.9,39.8-22.6,56.9-37.6L397,419.6z M115,92.4 c13.9-12,29.4-22.3,46.1-30.4l-11.9-29.8c-20.7,9.9-39.8,22.6-56.8,37.6L115,92.4z M447.7,355.5c-7.8,14.9-17.2,28.8-28.1,41.5 l22.7,22.7c13.7-15.6,25.5-32.9,34.9-51.5L447.7,355.5z M471.4,272c-1.4,18.8-5.2,37-11.1,54.1l29.5,12.6 c7.5-21.1,12.2-43.5,13.6-66.8H471.4z M321.2,462c-15.7,5-32.2,8.2-49.2,9.4v32.1c21.2-1.4,41.7-5.4,61.1-11.7L321.2,462z M240,471.4c-18.8-1.4-37-5.2-54.1-11.1l-12.6,29.5c21.1,7.5,43.5,12.2,66.8,13.6V471.4z M462,190.8c5,15.7,8.2,32.2,9.4,49.2h32.1 c-1.4-21.2-5.4-41.7-11.7-61.1L462,190.8z M92.4,397c-12-13.9-22.3-29.4-30.4-46.1l-29.8,11.9c9.9,20.7,22.6,39.8,37.6,56.9 L92.4,397z M272,40.6c18.8,1.4,36.9,5.2,54.1,11.1l12.6-29.5C317.7,14.7,295.3,10,272,8.5V40.6z M190.8,50 c15.7-5,32.2-8.2,49.2-9.4V8.5c-21.2,1.4-41.7,5.4-61.1,11.7L190.8,50z M442.3,92.3L419.6,115c12,13.9,22.3,29.4,30.5,46.1 l29.8-11.9C470,128.5,457.3,109.4,442.3,92.3z M397,92.4l22.7-22.7c-15.6-13.7-32.8-25.5-51.5-34.9l-12.6,29.5 C370.4,72.1,384.4,81.5,397,92.4z"})});var o=u(u({},i),{},{attributeName:"opacity"}),s={tag:"circle",attributes:u(u({},r),{},{cx:"256",cy:"364",r:"28"}),children:[]};return t||s.children.push({tag:"animate",attributes:u(u({},i),{},{attributeName:"r",values:"28;14;28;28;14;28;"})},{tag:"animate",attributes:u(u({},o),{},{values:"1;0;1;1;0;1;"})}),e.push(s),e.push({tag:"path",attributes:u(u({},r),{},{opacity:"1",d:"M263.7,312h-16c-6.6,0-12-5.4-12-12c0-71,77.4-63.9,77.4-107.8c0-20-17.8-40.2-57.4-40.2c-29.1,0-44.3,9.6-59.2,28.7 c-3.9,5-11.1,6-16.2,2.4l-13.1-9.2c-5.6-3.9-6.9-11.8-2.6-17.2c21.2-27.2,46.4-44.7,91.2-44.7c52.3,0,97.4,29.8,97.4,80.2 c0,67.6-77.4,63.5-77.4,107.8C275.7,306.6,270.3,312,263.7,312z"}),children:t?[]:[{tag:"animate",attributes:u(u({},o),{},{values:"1;0;0;0;0;1;"})}]}),t||e.push({tag:"path",attributes:u(u({},r),{},{opacity:"0",d:"M232.5,134.5l7,168c0.3,6.4,5.6,11.5,12,11.5h9c6.4,0,11.7-5.1,12-11.5l7-168c0.3-6.8-5.2-12.5-12-12.5h-23 C237.7,122,232.2,127.7,232.5,134.5z"}),children:[{tag:"animate",attributes:u(u({},o),{},{values:"0;0;1;1;0;0;"})}]}),{tag:"g",attributes:{class:"missing"},children:e}}}},Je={hooks:function(){return{parseNodeAttributes:function(t,e){var r=e.getAttribute("data-fa-symbol"),i=r===null?!1:r===""?!0:r;return t.symbol=i,t}}}},Ze=[Jt,He,Re,Fe,Ye,Ge,Xe,Be,Ke,Qe,Je];me(Ze,{mixoutsTo:E});E.noAuto;E.config;var Mr=E.library;E.dom;var Xa=E.parse;E.findIconDefinition;E.toHtml;var ar=E.icon;E.layer;E.text;E.counter;function Ln(a,n){var t=Object.keys(a);if(Object.getOwnPropertySymbols){var e=Object.getOwnPropertySymbols(a);n&&(e=e.filter(function(r){return Object.getOwnPropertyDescriptor(a,r).enumerable})),t.push.apply(t,e)}return t}function I(a){for(var n=1;n<arguments.length;n++){var t=arguments[n]!=null?arguments[n]:{};n%2?Ln(Object(t),!0).forEach(function(e){K(a,e,t[e])}):Object.getOwnPropertyDescriptors?Object.defineProperties(a,Object.getOwnPropertyDescriptors(t)):Ln(Object(t)).forEach(function(e){Object.defineProperty(a,e,Object.getOwnPropertyDescriptor(t,e))})}return a}function Na(a){"@babel/helpers - typeof";return Na=typeof Symbol=="function"&&typeof Symbol.iterator=="symbol"?function(n){return typeof n}:function(n){return n&&typeof Symbol=="function"&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n},Na(a)}function K(a,n,t){return n in a?Object.defineProperty(a,n,{value:t,enumerable:!0,configurable:!0,writable:!0}):a[n]=t,a}function nr(a,n){if(a==null)return{};var t={},e=Object.keys(a),r,i;for(i=0;i<e.length;i++)r=e[i],!(n.indexOf(r)>=0)&&(t[r]=a[r]);return t}function tr(a,n){if(a==null)return{};var t=nr(a,n),e,r;if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(a);for(r=0;r<i.length;r++)e=i[r],!(n.indexOf(e)>=0)&&Object.prototype.propertyIsEnumerable.call(a,e)&&(t[e]=a[e])}return t}function Ba(a){return er(a)||rr(a)||ir(a)||or()}function er(a){if(Array.isArray(a))return qa(a)}function rr(a){if(typeof Symbol<"u"&&a[Symbol.iterator]!=null||a["@@iterator"]!=null)return Array.from(a)}function ir(a,n){if(a){if(typeof a=="string")return qa(a,n);var t=Object.prototype.toString.call(a).slice(8,-1);if(t==="Object"&&a.constructor&&(t=a.constructor.name),t==="Map"||t==="Set")return Array.from(a);if(t==="Arguments"||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t))return qa(a,n)}}function qa(a,n){(n==null||n>a.length)&&(n=a.length);for(var t=0,e=new Array(n);t<n;t++)e[t]=a[t];return e}function or(){throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)}function sr(a){var n,t=a.beat,e=a.fade,r=a.beatFade,i=a.bounce,o=a.shake,s=a.flash,f=a.spin,c=a.spinPulse,l=a.spinReverse,m=a.pulse,d=a.fixedWidth,h=a.inverse,k=a.border,C=a.listItem,P=a.flip,N=a.size,w=a.rotation,A=a.pull,_=(n={"fa-beat":t,"fa-fade":e,"fa-beat-fade":r,"fa-bounce":i,"fa-shake":o,"fa-flash":s,"fa-spin":f,"fa-spin-reverse":l,"fa-spin-pulse":c,"fa-pulse":m,"fa-fw":d,"fa-inverse":h,"fa-border":k,"fa-li":C,"fa-flip":P===!0,"fa-flip-horizontal":P==="horizontal"||P==="both","fa-flip-vertical":P==="vertical"||P==="both"},K(n,"fa-".concat(N),typeof N<"u"&&N!==null),K(n,"fa-rotate-".concat(w),typeof w<"u"&&w!==null&&w!==0),K(n,"fa-pull-".concat(A),typeof A<"u"&&A!==null),K(n,"fa-swap-opacity",a.swapOpacity),n);return Object.keys(_).map(function(S){return _[S]?S:null}).filter(function(S){return S})}function fr(a){return a=a-0,a===a}function ut(a){return fr(a)?a:(a=a.replace(/[\-_\s]+(.)?/g,function(n,t){return t?t.toUpperCase():""}),a.substr(0,1).toLowerCase()+a.substr(1))}var lr=["style"];function cr(a){return a.charAt(0).toUpperCase()+a.slice(1)}function ur(a){return a.split(";").map(function(n){return n.trim()}).filter(function(n){return n}).reduce(function(n,t){var e=t.indexOf(":"),r=ut(t.slice(0,e)),i=t.slice(e+1).trim();return r.startsWith("webkit")?n[cr(r)]=i:n[r]=i,n},{})}function mt(a,n){var t=arguments.length>2&&arguments[2]!==void 0?arguments[2]:{};if(typeof n=="string")return n;var e=(n.children||[]).map(function(f){return mt(a,f)}),r=Object.keys(n.attributes||{}).reduce(function(f,c){var l=n.attributes[c];switch(c){case"class":f.attrs.className=l,delete n.attributes.class;break;case"style":f.attrs.style=ur(l);break;default:c.indexOf("aria-")===0||c.indexOf("data-")===0?f.attrs[c.toLowerCase()]=l:f.attrs[ut(c)]=l}return f},{attrs:{}}),i=t.style,o=i===void 0?{}:i,s=tr(t,lr);return r.attrs.style=I(I({},r.attrs.style),o),a.apply(void 0,[n.tag,I(I({},r.attrs),s)].concat(Ba(e)))}var vt=!1;try{vt=!0}catch{}function mr(){if(!vt&&console&&typeof console.error=="function"){var a;(a=console).error.apply(a,arguments)}}function zn(a){if(a&&Na(a)==="object"&&a.prefix&&a.iconName&&a.icon)return a;if(Xa.icon)return Xa.icon(a);if(a===null)return null;if(a&&Na(a)==="object"&&a.prefix&&a.iconName)return a;if(Array.isArray(a)&&a.length===2)return{prefix:a[0],iconName:a[1]};if(typeof a=="string")return{prefix:"fas",iconName:a}}function za(a,n){return Array.isArray(n)&&n.length>0||!Array.isArray(n)&&n?K({},a,n):{}}var Dn={border:!1,className:"",mask:null,maskId:null,fixedWidth:!1,inverse:!1,flip:!1,icon:null,listItem:!1,pull:null,pulse:!1,rotation:null,size:null,spin:!1,spinPulse:!1,spinReverse:!1,beat:!1,fade:!1,beatFade:!1,bounce:!1,shake:!1,symbol:!1,title:"",titleId:null,transform:null,swapOpacity:!1},dt=jn.forwardRef(function(a,n){var t=I(I({},Dn),a),e=t.icon,r=t.mask,i=t.symbol,o=t.className,s=t.title,f=t.titleId,c=t.maskId,l=zn(e),m=za("classes",[].concat(Ba(sr(t)),Ba((o||"").split(" ")))),d=za("transform",typeof t.transform=="string"?Xa.transform(t.transform):t.transform),h=za("mask",zn(r)),k=ar(l,I(I(I(I({},m),d),h),{},{symbol:i,title:s,titleId:f,maskId:c}));if(!k)return mr("Could not find icon",l),null;var C=k.abstract,P={ref:n};return Object.keys(t).forEach(function(N){Dn.hasOwnProperty(N)||(P[N]=t[N])}),vr(C[0],P)});dt.displayName="FontAwesomeIcon";dt.propTypes={beat:g.bool,border:g.bool,beatFade:g.bool,bounce:g.bool,className:g.string,fade:g.bool,flash:g.bool,mask:g.oneOfType([g.object,g.array,g.string]),maskId:g.string,fixedWidth:g.bool,inverse:g.bool,flip:g.oneOf([!0,!1,"horizontal","vertical","both"]),icon:g.oneOfType([g.object,g.array,g.string]),listItem:g.bool,pull:g.oneOf(["right","left"]),pulse:g.bool,rotation:g.oneOf([0,90,180,270]),shake:g.bool,size:g.oneOf(["2xs","xs","sm","lg","xl","2xl","1x","2x","3x","4x","5x","6x","7x","8x","9x","10x"]),spin:g.bool,spinPulse:g.bool,spinReverse:g.bool,symbol:g.oneOfType([g.bool,g.string]),title:g.string,titleId:g.string,transform:g.oneOfType([g.string,g.object]),swapOpacity:g.bool};var vr=mt.bind(null,jn.createElement),dr={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="bars",e=448,r=512,i=["navicon"],o="f0c9",s="M0 96C0 78.3 14.3 64 32 64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32C14.3 128 0 113.7 0 96zM0 256c0-17.7 14.3-32 32-32H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H32c-17.7 0-32-14.3-32-32zM448 416c0 17.7-14.3 32-32 32H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H416c17.7 0 32 14.3 32 32z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faBars=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(dr);var gr={},gt={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="xmark",e=384,r=512,i=[128473,10005,10006,10060,215,"close","multiply","remove","times"],o="f00d",s="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faXmark=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(gt);(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n=gt;a.definition={prefix:n.prefix,iconName:n.iconName,icon:[n.width,n.height,n.aliases,n.unicode,n.svgPathData]},a.faTimes=a.definition,a.prefix=n.prefix,a.iconName=n.iconName,a.width=n.width,a.height=n.height,a.ligatures=n.aliases,a.unicode=n.unicode,a.svgPathData=n.svgPathData,a.aliases=n.aliases})(gr);var hr={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fab",t="twitter",e=512,r=512,i=[],o="f099",s="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faTwitter=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(hr);var br={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fab",t="instagram",e=448,r=512,i=[],o="f16d",s="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faInstagram=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(br);var pr={},ht={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="location-dot",e=384,r=512,i=["map-marker-alt"],o="f3c5",s="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faLocationDot=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(ht);(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n=ht;a.definition={prefix:n.prefix,iconName:n.iconName,icon:[n.width,n.height,n.aliases,n.unicode,n.svgPathData]},a.faMapMarkerAlt=a.definition,a.prefix=n.prefix,a.iconName=n.iconName,a.width=n.width,a.height=n.height,a.ligatures=n.aliases,a.unicode=n.unicode,a.svgPathData=n.svgPathData,a.aliases=n.aliases})(pr);var yr={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="envelope",e=512,r=512,i=[128386,9993,61443],o="f0e0",s="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faEnvelope=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(yr);var wr={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="phone",e=512,r=512,i=[128222,128379],o="f095",s="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faPhone=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(wr);var kr={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="book",e=448,r=512,i=[128212],o="f02d",s="M96 0C43 0 0 43 0 96V416c0 53 43 96 96 96H384h32c17.7 0 32-14.3 32-32s-14.3-32-32-32V384c17.7 0 32-14.3 32-32V32c0-17.7-14.3-32-32-32H384 96zm0 384H352v64H96c-17.7 0-32-14.3-32-32s14.3-32 32-32zm32-240c0-8.8 7.2-16 16-16H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16zm16 48H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16s7.2-16 16-16z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faBook=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(kr);var Pr={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="graduation-cap",e=640,r=512,i=[127891,"mortar-board"],o="f19d",s="M320 32c-8.1 0-16.1 1.4-23.7 4.1L15.8 137.4C6.3 140.9 0 149.9 0 160s6.3 19.1 15.8 22.6l57.9 20.9C57.3 229.3 48 259.8 48 291.9v28.1c0 28.4-10.8 57.7-22.3 80.8c-6.5 13-13.9 25.8-22.5 37.6C0 442.7-.9 448.3 .9 453.4s6 8.9 11.2 10.2l64 16c4.2 1.1 8.7 .3 12.4-2s6.3-6.1 7.1-10.4c8.6-42.8 4.3-81.2-2.1-108.7C90.3 344.3 86 329.8 80 316.5V291.9c0-30.2 10.2-58.7 27.9-81.5c12.9-15.5 29.6-28 49.2-35.7l157-61.7c8.2-3.2 17.5 .8 20.7 9s-.8 17.5-9 20.7l-157 61.7c-12.4 4.9-23.3 12.4-32.2 21.6l159.6 57.6c7.6 2.7 15.6 4.1 23.7 4.1s16.1-1.4 23.7-4.1L624.2 182.6c9.5-3.4 15.8-12.5 15.8-22.6s-6.3-19.1-15.8-22.6L343.7 36.1C336.1 33.4 328.1 32 320 32zM128 408c0 35.3 86 72 192 72s192-36.7 192-72L496.7 262.6 354.5 314c-11.1 4-22.8 6-34.5 6s-23.5-2-34.5-6L143.3 262.6 128 408z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faGraduationCap=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(Pr);var Ar={},bt={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="handshake-angle",e=640,r=512,i=["hands-helping"],o="f4c4",s="M544 248v3.3l69.7-69.7c21.9-21.9 21.9-57.3 0-79.2L535.6 24.4c-21.9-21.9-57.3-21.9-79.2 0L416.3 64.5c-2.7-.3-5.5-.5-8.3-.5H296c-37.1 0-67.6 28-71.6 64H224V248c0 22.1 17.9 40 40 40s40-17.9 40-40V176c0 0 0-.1 0-.1V160l16 0 136 0c0 0 0 0 .1 0H464c44.2 0 80 35.8 80 80v8zM336 192v56c0 39.8-32.2 72-72 72s-72-32.2-72-72V129.4c-35.9 6.2-65.8 32.3-76 68.2L99.5 255.2 26.3 328.4c-21.9 21.9-21.9 57.3 0 79.2l78.1 78.1c21.9 21.9 57.3 21.9 79.2 0l37.7-37.7c.9 0 1.8 .1 2.7 .1H384c26.5 0 48-21.5 48-48c0-5.6-1-11-2.7-16H432c26.5 0 48-21.5 48-48c0-12.8-5-24.4-13.2-33c25.7-5 45.1-27.6 45.2-54.8v-.4c-.1-30.8-25.1-55.8-56-55.8c0 0 0 0 0 0l-120 0z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faHandshakeAngle=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(bt);(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n=bt;a.definition={prefix:n.prefix,iconName:n.iconName,icon:[n.width,n.height,n.aliases,n.unicode,n.svgPathData]},a.faHandsHelping=a.definition,a.prefix=n.prefix,a.iconName=n.iconName,a.width=n.width,a.height=n.height,a.ligatures=n.aliases,a.unicode=n.unicode,a.svgPathData=n.svgPathData,a.aliases=n.aliases})(Ar);var Or={},pt={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="heart-pulse",e=512,r=512,i=["heartbeat"],o="f21e",s="M228.3 469.1L47.6 300.4c-4.2-3.9-8.2-8.1-11.9-12.4h87c22.6 0 43-13.6 51.7-34.5l10.5-25.2 49.3 109.5c3.8 8.5 12.1 14 21.4 14.1s17.8-5 22-13.3L320 253.7l1.7 3.4c9.5 19 28.9 31 50.1 31H476.3c-3.7 4.3-7.7 8.5-11.9 12.4L283.7 469.1c-7.5 7-17.4 10.9-27.7 10.9s-20.2-3.9-27.7-10.9zM503.7 240h-132c-3 0-5.8-1.7-7.2-4.4l-23.2-46.3c-4.1-8.1-12.4-13.3-21.5-13.3s-17.4 5.1-21.5 13.3l-41.4 82.8L205.9 158.2c-3.9-8.7-12.7-14.3-22.2-14.1s-18.1 5.9-21.8 14.8l-31.8 76.3c-1.2 3-4.2 4.9-7.4 4.9H16c-2.6 0-5 .4-7.3 1.1C3 225.2 0 208.2 0 190.9v-5.8c0-69.9 50.5-129.5 119.4-141C165 36.5 211.4 51.4 244 84l12 12 12-12c32.6-32.6 79-47.5 124.6-39.9C461.5 55.6 512 115.2 512 185.1v5.8c0 16.9-2.8 33.5-8.3 49.1z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faHeartPulse=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(pt);(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n=pt;a.definition={prefix:n.prefix,iconName:n.iconName,icon:[n.width,n.height,n.aliases,n.unicode,n.svgPathData]},a.faHeartbeat=a.definition,a.prefix=n.prefix,a.iconName=n.iconName,a.width=n.width,a.height=n.height,a.ligatures=n.aliases,a.unicode=n.unicode,a.svgPathData=n.svgPathData,a.aliases=n.aliases})(Or);var Nr={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="hospital",e=640,r=512,i=[127973,62589,"hospital-alt","hospital-wide"],o="f0f8",s="M192 48c0-26.5 21.5-48 48-48H400c26.5 0 48 21.5 48 48V512H368V432c0-26.5-21.5-48-48-48s-48 21.5-48 48v80H192V48zM48 96H160V512H48c-26.5 0-48-21.5-48-48V320H80c8.8 0 16-7.2 16-16s-7.2-16-16-16H0V224H80c8.8 0 16-7.2 16-16s-7.2-16-16-16H0V144c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48v48H560c-8.8 0-16 7.2-16 16s7.2 16 16 16h80v64H560c-8.8 0-16 7.2-16 16s7.2 16 16 16h80V464c0 26.5-21.5 48-48 48H480V96H592zM312 64c-8.8 0-16 7.2-16 16v24H272c-8.8 0-16 7.2-16 16v16c0 8.8 7.2 16 16 16h24v24c0 8.8 7.2 16 16 16h16c8.8 0 16-7.2 16-16V152h24c8.8 0 16-7.2 16-16V120c0-8.8-7.2-16-16-16H344V80c0-8.8-7.2-16-16-16H312z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faHospital=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(Nr);var Sr={},yt={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="building-columns",e=512,r=512,i=["bank","institution","museum","university"],o="f19c",s="M243.4 2.6l-224 96c-14 6-21.8 21-18.7 35.8S16.8 160 32 160v8c0 13.3 10.7 24 24 24H456c13.3 0 24-10.7 24-24v-8c15.2 0 28.3-10.7 31.3-25.6s-4.8-29.9-18.7-35.8l-224-96c-8-3.4-17.2-3.4-25.2 0zM128 224H64V420.3c-.6 .3-1.2 .7-1.8 1.1l-48 32c-11.7 7.8-17 22.4-12.9 35.9S17.9 512 32 512H480c14.1 0 26.5-9.2 30.6-22.7s-1.1-28.1-12.9-35.9l-48-32c-.6-.4-1.2-.7-1.8-1.1V224H384V416H344V224H280V416H232V224H168V416H128V224zM256 64a32 32 0 1 1 0 64 32 32 0 1 1 0-64z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faBuildingColumns=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(yt);(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n=yt;a.definition={prefix:n.prefix,iconName:n.iconName,icon:[n.width,n.height,n.aliases,n.unicode,n.svgPathData]},a.faUniversity=a.definition,a.prefix=n.prefix,a.iconName=n.iconName,a.width=n.width,a.height=n.height,a.ligatures=n.aliases,a.unicode=n.unicode,a.svgPathData=n.svgPathData,a.aliases=n.aliases})(Sr);var Cr={},wt={};(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n="fas",t="magnifying-glass",e=512,r=512,i=[128269,"search"],o="f002",s="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z";a.definition={prefix:n,iconName:t,icon:[e,r,i,o,s]},a.faMagnifyingGlass=a.definition,a.prefix=n,a.iconName=t,a.width=e,a.height=r,a.ligatures=i,a.unicode=o,a.svgPathData=s,a.aliases=i})(wt);(function(a){Object.defineProperty(a,"__esModule",{value:!0});var n=wt;a.definition={prefix:n.prefix,iconName:n.iconName,icon:[n.width,n.height,n.aliases,n.unicode,n.svgPathData]},a.faSearch=a.definition,a.prefix=n.prefix,a.iconName=n.iconName,a.width=n.width,a.height=n.height,a.ligatures=n.aliases,a.unicode=n.unicode,a.svgPathData=n.svgPathData,a.aliases=n.aliases})(Cr);var Ir={prefix:"fas",iconName:"thumbtack",icon:[384,512,[128204,128392,"thumb-tack"],"f08d","M32 32C32 14.3 46.3 0 64 0H320c17.7 0 32 14.3 32 32s-14.3 32-32 32H290.5l11.4 148.2c36.7 19.9 65.7 53.2 79.5 94.7l1 3c3.3 9.8 1.6 20.5-4.4 28.8s-15.7 13.3-26 13.3H32c-10.3 0-19.9-4.9-26-13.3s-7.7-19.1-4.4-28.8l1-3c13.8-41.5 42.8-74.8 79.5-94.7L93.5 64H64C46.3 64 32 49.7 32 32zM160 384h64v96c0 17.7-14.3 32-32 32s-32-14.3-32-32V384z"]};export{dt as F,gr as a,hr as b,br as c,pr as d,yr as e,dr as f,wr as g,kr as h,Pr as i,Ar as j,Or as k,Mr as l,Nr as m,Sr as n,Cr as o,Ir as p};
