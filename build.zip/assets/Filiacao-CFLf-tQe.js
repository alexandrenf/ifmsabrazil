import{j as e,r as i}from"./react-CLPtFgDq.js";import{_ as c,L as J}from"./index-INV2gsy9.js";import{p as d}from"./styled-components-BY_vc4YD.js";import{c as X,F as K}from"./react-icons-CrkDh4zl.js";import{k as Y,l as Z,m as ee,P as oe,n as ae,o as C,p as ne,q as te,j as se,f as re,F as ie,g as ce,S as de,O as le,M as w,L as F,s as B,C as me,T as pe}from"./@mui-B86xCNSa.js";import{a as xe}from"./axios-B4uVmeYG.js";import{P as ue}from"./papaparse-D8JlQIm0.js";import{M as Ee}from"./MarkdownContent-DFTCqHCR.js";import"./@babel-f5lBRPU2.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-Am9psY4u.js";import"./react-router-BzRFIFMZ.js";import"./@remix-run-YI_hLLil.js";import"./@fortawesome-B6QlLdFu.js";import"./prop-types-1yzuAbYU.js";import"./webfontloader-DM8E560Z.js";import"./tslib-wbdO-F7s.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./clsx-B-dksMZM.js";import"./react-transition-group-CLuBo2_z.js";import"./react-is-DcfIKM1A.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */var P,A,S,L,M;const he=d.div(P||(P=c([`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  color: white;
`]))),fe=d.div(A||(A=c([`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`]))),ge=d(X)(S||(S=c([`
  font-size: 3rem;
  margin-bottom: 10px;
`]))),be=d.p(L||(L=c([`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  margin-bottom: 20px;
`]))),ve=d.button(M||(M=c([`
  background-color: white;
  color: #003366;
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;

  &:hover {
    background-color: transparent;
    color: white;
  }
`]))),je=s=>{let{onClose:t}=s;return e.jsx(he,{children:e.jsxs(fe,{children:[e.jsx(ge,{}),e.jsx(be,{children:"Por favor, gire seu dispositivo para o modo horizontal"}),e.jsx(ve,{onClick:t,children:e.jsx(K,{size:24})})]})})};var T,y,z,I;const Ce=d(Y)(T||(T=c([`
  background-color: #00508c;
  & th {
    color: #fff;
    font-weight: bold;
    white-space: nowrap;
  }
`]))),we=d(Z)(y||(y=c([`
  width: 100%;
  overflow-x: auto;
  position: relative;
`]))),r=d(ee)(z||(z=c([`
  min-width: 150px;
`]))),Fe=d.div(I||(I=c([`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 999;
`]))),Pe=s=>{let{displayedMembers:t,filteredMembersLength:m,page:h,rowsPerPage:n,handleChangePage:f,handleChangeRowsPerPage:g,showPrompt:p,onClosePrompt:u}=s;return e.jsxs(we,{component:oe,children:[p&&e.jsx(Fe,{}),p&&e.jsx(je,{onClose:u}),e.jsxs(ae,{children:[e.jsx(Ce,{children:e.jsxs(C,{children:[e.jsx(r,{children:"Comitê Local"}),e.jsx(r,{children:"Nome da EM"}),e.jsx(r,{children:"Regional"}),e.jsx(r,{children:"Cidade"}),e.jsx(r,{children:"UF"}),e.jsx(r,{children:"Status"})]})}),e.jsx(ne,{children:t.map((l,E)=>e.jsxs(C,{children:[e.jsx(r,{children:l["Comitê Local"]}),e.jsx(r,{children:l["Nome da EM"]}),e.jsx(r,{children:l.Regional}),e.jsx(r,{children:l.Cidade}),e.jsx(r,{children:l.UF}),e.jsx(r,{children:l.Status})]},E))})]}),e.jsx(te,{component:"div",count:m,page:h,onPageChange:f,rowsPerPage:n,onRowsPerPageChange:g,rowsPerPageOptions:[10,25,50,100,{label:"Todos",value:m}],labelRowsPerPage:"Itens por página"})]})};var O,R,k;const Ae=d.h1(O||(O=c([`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  color: #333;
  text-align: center;
  margin-bottom: 10px;
`]))),Se=d.section(R||(R=c([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #fafafa;
`]))),Le=d(se)(k||(k=c([`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 1200px;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: stretch;
  }
`]))),Me=s=>{let{members:t}=s;const[m,h]=i.useState(""),[n,f]=i.useState({regional:"",cidade:"",uf:"",status:""}),[g,p]=i.useState([]),[u,l]=i.useState(0),[E,q]=i.useState(10),[D,v]=i.useState(!1),[j,_]=i.useState(!1);i.useEffect(()=>{const a=()=>{const o=window.innerWidth<=768,x=window.innerHeight>window.innerWidth;v(o&&x)};return j||(window.addEventListener("resize",a),a()),()=>{window.removeEventListener("resize",a)}},[j]),i.useEffect(()=>{p(H(t))},[t,m,n]);const U=a=>{h(a.target.value)},V=()=>{_(!0),v(!1)},N=a=>{const{name:o,value:x}=a.target;f(b=>({...b,[o]:x}))},$=(a,o)=>{l(o)},G=a=>{q(parseInt(a.target.value,10)),l(0)},H=a=>a.filter(o=>{const x=o["Comitê Local"].toLowerCase().includes(m.toLowerCase())||o["Nome da EM"].toLowerCase().includes(m.toLowerCase()),b=(!n.regional||o.Regional===n.regional)&&(!n.cidade||o.Cidade===n.cidade)&&(!n.uf||o.UF===n.uf)&&(!n.status||o.Status===n.status);return x&&b}).sort((o,x)=>o["Comitê Local"].localeCompare(x["Comitê Local"])),W=a=>[...new Set(t.map(o=>o[a]))].sort(),Q=g.slice(u*E,u*E+E);return e.jsxs(Se,{children:[e.jsx(Ae,{children:"Lista de Comitês Locais Filiados"}),e.jsxs(Le,{children:[e.jsx(re,{label:"Buscar",variant:"outlined",value:m,onChange:U,style:{marginBottom:"20px",flexGrow:1}}),["Regional","Cidade","UF","Status"].map(a=>e.jsxs(ie,{variant:"outlined",style:{minWidth:200,marginBottom:"20px"},children:[e.jsx(ce,{children:a}),e.jsxs(de,{name:a.toLowerCase(),value:n[a.toLowerCase()],onChange:N,input:e.jsx(le,{label:a}),renderValue:o=>o||"Todos",children:[e.jsx(w,{value:"",children:e.jsx(F,{primary:"Todos"})}),W(a).map(o=>e.jsx(w,{value:o,children:e.jsx(F,{primary:o})},o))]})]},a))]}),e.jsx(Pe,{displayedMembers:Q,filteredMembersLength:g.length,page:u,rowsPerPage:E,handleChangePage:$,handleChangeRowsPerPage:G,showPrompt:D,onClosePrompt:()=>V()})]})},Te=B(me)(s=>{let{theme:t}=s;return{padding:"24px",backgroundColor:"#FFFFFF",color:"#333",[t.breakpoints.down("sm")]:{padding:"16px"}}}),ye=B(pe)(s=>{let{theme:t}=s;return{color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center",[t.breakpoints.down("sm")]:{fontSize:"1.5rem"}}}),so=()=>{const s="https://docs.google.com/spreadsheets/d/1PF7Lqb0jq1ULQBmHzFxOif5UvGwsVLqM2LESq7JVh6c/export?gid=1583477648&format=csv",[t,m]=i.useState([]),[h,n]=i.useState(!0);i.useEffect(()=>{(async()=>{try{const p=await xe.get(s),l=ue.parse(p.data,{header:!0}).data;m(l)}catch(p){console.error("Error fetching spreadsheet:",p)}finally{n(!1)}})()},[s]);const f=`

## Como posso me filiar à IFMSA Brazil?

Para se filiar, é necessário que sua escola médica tenha um comitê local da IFMSA Brazil e manifestar seu interesse a ele.

## Como eu posso fundar um comitê local?

Basta mandar um e-mail para vpi@ifmsabrazil.org contendo o nome da sua instituição de ensino, demonstrando interesse em fundar um comitê local.
Por lá, podemos começar um processo de filiação.
Confira essa página com atenção para ver as informações sobre a filiação!

## Como funciona o processo de filiação?

### Em cinco etapas!

- **Etapa I:** Você receberá alguns documentos sobre a IFMSA Brazil e será orientado a constituir um grupo de no mínimo 5 pessoas para dar seguimento.
- **Etapa II:** Um contrato de autorização deverá ser assinado pelo coordenador do curso e pelo grupo que foi formado por você juntamente com algumas informações essenciais sobre a faculdade.
- **Etapa III:** Consiste na deliberação da Diretoria Executiva Nacional sobre a viabilidade de, naquele momento, vocês serem filiados
- **Etapa IV:** Vocês serão orientados por Coordenadores Regionais e membros da Diretoria Executiva a realizarem uma atividade de cunho social obedecendo algumas regras e preenchendo as fichas de submissão de atividade.
- **Etapa V:** Ao ser executada cada etapa, um novo processo de avaliação será feito pelos Coordenadores Regionais e Diretoria Executiva e, caso vocês a executem bem, serão convidados a estar conosco em nossa próxima Assembleia Geral para defender a não plenitude da sua faculdade perante a plenária da IFMSA Brazil.

## Como funciona a Assembleia Geral?

É o espaço de deliberação máxima na IFMSA Brazil, onde ocorrem paralelamente sessões, workshops, treinamentos, palestras, entre outros eventos, dentre os quais está a apresentação de sua candidatura à não plenitude.
Caso vocês recebam a carta convite para apresentar a não-plenitude, será necessário no mínimo um representante presente.

## Quanto tempo esse processo demora?

Em média, 1 ano para ser finalizado.
O processo pode durar menos de acordo com cada comitê aspirante.

## Há algum custo para ser filiado?

### Não!

Não há nenhuma taxa de filiação ou taxa para se manter filiado.

O único custo é a ida até a Assembleia Geral, que deve ser custeada pelo grupo fundador. A inscrição no evento inclui alimentação, hospedagem e o evento em si, e outros custos envolvem o transporte até o evento.
Durante o ciclo de capacitações sobre a atividade, vocês irão aprender estratégias para fazer uma atividade financeiramente sustentável, e conseguir patrocínios e parcerias (inclusive com a coordenação do curso), que podem ajudar com esse custo!

## E quanto aos intercâmbios?

Após o processo de não-plenitude, vocês precisarão começar o processo de plenitude que no geral dura cerca de mais um ano após a primeira ida à Assembléia Geral.

## O que é a plenitude?

Um comitê pleno é um comitê considerado capacitado para estabelecimento de direitos plenos dentro da Federação, tendo como base a atuação perante nosso eixos. Tem direito de voz e voto, e pode realizar intercâmbios.
O processo de plenitude envolve comitês bem estruturados, com um contrato de intercâmbio assinado, e vagas declaradas.

## Minha faculdade não tem IFMSA Brazil, posso fazer intercâmbio por vocês?

Não! Apenas alunos de faculdades filiadas podem fazer intercâmbios.

## Quando iremos aprender mais informações sobre a IFMSA Brazil?

Todos os aprovados na etapa III passam por capacitações sobre planejamento de atividades, metodologia de impacto, e outros assuntos pertinentes à filiação.
Após a filiação em si, todos os novos comitês não-plenos passam por um ciclo de capacitações sobre todos os eixos da IFMSA Brazil.


`;return h?e.jsx(J,{}):e.jsxs(Te,{children:[e.jsx(ye,{variant:"h4",children:"Processo de Filiação e Comitês Filiados"}),e.jsx(Ee,{content:f}),e.jsx(Me,{members:t})]})};export{so as default};
