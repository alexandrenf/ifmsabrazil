import{j as a}from"./react-DaPl5ws4.js";import"./index-tzKVQ37f.js";import{M as o}from"./MarkdownContent-Bk-obxsC.js";import{s as e,C as i,T as s}from"./@mui-D3p2DSY1.js";import"./@babel-CNkBngnk.js";import"./react-dom-CWF6clnO.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-BFBG7k2k.js";import"./react-router-B_WJkAv4.js";import"./@remix-run-B-RBrVrq.js";import"./styled-components-BD7m8TR7.js";import"./tslib-wbdO-F7s.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./axios-B4uVmeYG.js";import"./react-icons-BQxfTaxZ.js";import"./date-fns-X50TK9oK.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";import"./markdown-to-jsx-CXBEPAoT.js";import"./prismjs-DEnDlMkx.js";/* empty css                   */const r=e(i)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),n=e(s)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),T=()=>a.jsxs(r,{children:[a.jsx(n,{variant:"h4",children:"Ações e Temáticas"}),a.jsx(o,{content:`

### Mobilidade Acadêmica:

Com a visão de formar estudantes de medicina mais humanizados e culturalmente competentes, a  IFMSA Brazil tem como uma de suas missões a organização de intercâmbios estudantis acessíveis, pelos quais enviamos e recebemos acadêmicos de medicina para estágios tutorados o ano todo. Ofertamos vagas Nacionais e Internacionais, para diversas modalidades de intercâmbios, como clínico-cirúrgico, pesquisa, entre outras vivências no eixo de saúde pública. A federação reúne neles a integração entre os estudantes e escolas médicas do próprio país, bem como a troca de experiências e de conhecimento com culturas estrangeiras. Por isso, a IFMSA Brazil trabalha há mais de 30 anos com empenho para oferecer aos estudantes de medicina da nação mais uma de suas ações que fazem a diferença: a possibilidade de realizar estágios em seus 26 estados mais o distrito federal, e em mais de 50 países.
Por meio dos intercâmbios, além de transformar sonhos em realidade, os estudantes conhecem realidades distintas das quais vivem e, portanto, conseguem uma visão mais ampla e inclusiva sobre globalização e saúde global. Seja no Brasil, seja no exterior, o fluxo de experiências e culturas expande não só a dimensão intelectual, mas também a moral, contribuindo na formação de indivíduos mais compassivos e tolerantes. Além disso, a atuação profissional, as oportunidades curriculares e a independência desses alunos são grandemente beneficiadas pelas experiências vivenciadas no estágio durante 2 a 4 semanas em outra cidade ou país. Estas, quando compartilhadas com amigos e docentes, fazem com que missão e compromisso da IFMSA Brazil com a educação médica sejam espalhadas Brasil e mundo.
Para mais informações, contate o Coordenador Local de Intercâmbios da sua faculdade, ou mande um email para intercambios@ifmsabrazil.org .


### Educação Médica:

Educação Médica é um eixo interdisciplinar e com caráter explorador, questionador e também inovador. Trabalhando desde as lacunas curriculares até iluminando tópicos importantes para a formação dos acadêmicos, visa construir plenos currículos formais, informais e ocultos. Esse eixo objetiva melhorar para além da construção médica, enfatizando as relações de aprendizado e ensino, compreendendo a comunidade, seu contexto sócio-político-econômico e seus determinantes sociais em saúde.

###Pesquisa:

O eixo de Publicação, Pesquisa e Extensão visa proporcionar bases de evidência científica às atividades desenvolvidas pela federação. O eixo é alicerçado em três principais bases, sendo a primeira delas a promoção de acesso à pesquisa e educação em pesquisa através de capacitações, cursos e espaços abertos para discussões prezando sempre pela medicina baseada em evidência e pela reprodução de uma ciência de qualidade, também é fundamentado pela produção de evidência científica através das pesquisas e projetos promovidos pelo Scientific Team e pelos Coordenadores Locais, sempre prezando pela responsabilidade social e pelo envolvimento significativo da comunidade acadêmica ou civil, de acordo com a abordagem. Além disso, a representatividade é indissociável do eixo visto que proporciona voz a federação no que tange a construção de conhecimento dentro desta, ademais por meio da nossa Revista Científica Brazilian Medical Students podemos disseminar as atividades e construções sociais realizadas pela IFMSA Brazil em abrangência nacional e internacional. 

### Promoção de Saúde:

### Humanização:


### Construção de Habilidades:

O Capacity Building é a coluna vertebral da IFMSA Brazil, uma vez que se mostra presente nas diferentes áreas de atuação. A capacitação em habilidades como liderança, produtividade, comunicação, trabalho em equipe, dentre diversas outras, é a sua principal função, a fim de formar Coordenadores Locais aptos a fazerem a diferença.
É parte da missão da IFMSA Brazil contribuir para a formação médica plena e, em especial para o contexto brasileiro, aplicar metodologias de aprendizagem para otimizar a gestão de recursos e cuidado em saúde.
Esta proficiência repercute também institucionalmente, ao contribuir para a boa administração dos Comitês Locais, e individualmente, aperfeiçoando práticas cotidianas que potencializam a qualidade de vida pessoal e acadêmica dos membros filiados.
Para tanto, é utilizada a estrutura internacional de multiplicação de conhecimentos da IFMSA e também da IFMSA Brazil. Novos treinadores são produzidos em eventos supervisionados denominados Workshop de Formação e tutorados por treinadores experientes, para prepará-los a atuarem localmente na facilitação do desenvolvimento de habilidades de demais acadêmicos.
O sistema de formação é continuado, preservando o sistema de membros, novos treinadores e treinadores experientes, partindo de encontros regionais e nacionais para globais, ampliando progressiva e sustentavelmente as possibilidades de atuação do treinador, bem como oportunidades em educação com seus pares. 

### Representatividade Estudantil:
`})]});export{T as default};
