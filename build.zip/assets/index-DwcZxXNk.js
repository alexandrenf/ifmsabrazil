const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/MarkdownPage-bREgTZA-.js","assets/react-DaPl5ws4.js","assets/@babel-CNkBngnk.js","assets/markdown-to-jsx-CXBEPAoT.js","assets/axios-B4uVmeYG.js","assets/prismjs-DEnDlMkx.js","assets/@mui-D3p2DSY1.js","assets/clsx-B-dksMZM.js","assets/react-is-DcfIKM1A.js","assets/@emotion-Clztb9Oy.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/react-transition-group-cLDJx4Bm.js","assets/react-dom-CWF6clnO.js","assets/scheduler-CzFDRTuY.js","assets/react-router-B_WJkAv4.js","assets/@remix-run-B-RBrVrq.js","assets/react-router-dom-BFBG7k2k.js","assets/styled-components-D58U5FK1.js","assets/tslib-wbdO-F7s.js","assets/stylis-DinRj2j6.js","assets/@fortawesome-BOOXKGIM.js","assets/prop-types-15ULSoSZ.js","assets/js-cookie-Cz0CWeBA.js","assets/react-icons-BQxfTaxZ.js","assets/date-fns-X50TK9oK.js","assets/codeStyles-vPv1o2UF.css","assets/GeradorLink-BvzLFz8y.js","assets/Arquivos-_iLfxw24.js","assets/BlogPostListItem-Cq53e-sa.js","assets/Estrutura-D2QeCl0k.js","assets/react-multi-carousel-BYLf87Xc.js","assets/react-multi-carousel-C0HCKJ4u.css","assets/react-simple-maps-s3X3tYH8.js","assets/topojson-client-DzWSY_RA.js","assets/d3-geo-eEO7UCrt.js","assets/d3-array-BweefaKS.js","assets/MarkdownContent-Bk-obxsC.js","assets/Filiacao-CZ0cuTkg.js","assets/papaparse-RALpPLFu.js","assets/NotFound-DjpsNUeh.js","assets/Noticias-ConqDetI.js","assets/Institucional-CqBadN7M.js","assets/AcoesETematicas-C2q4Nw7n.js","assets/SocialPrograms-BTDze6rF.js","assets/Eixos-D94FvlQN.js","assets/Eventos-BhVtkaDV.js","assets/MemoriaInstitucional-BJUdPq4t.js","assets/Regulamento-B2PUvoij.js","assets/OutrosIntercambios-CGTohQ1h.js","assets/IntercambioInternacional-C46sCKfl.js","assets/IntercambioNacional--hY0w_YM.js"])))=>i.map(i=>d[i]);
import{r as l,j as n,a as ge}from"./react-DaPl5ws4.js";import{c as fe}from"./react-dom-CWF6clnO.js";import{L as m,B as be}from"./react-router-dom-BFBG7k2k.js";import{p as r,h as je,f as Xn}from"./styled-components-D58U5FK1.js";import{l as D,f as Jn,a as Kn,F as k,b as ve,c as we,d as _e,e as ye,g as ke,h as Zn,i as ne,j as ee,k as te,m as oe,n as ie,o as re}from"./@fortawesome-BOOXKGIM.js";import{j as Oe,a as Ce,G as Ee}from"./@emotion-Clztb9Oy.js";import{s as S,I as ze,C as H,G as z,T as j,a as Se,b as Ie,c as Me,d as Pe,e as Ae,f as Le,g as Fe}from"./@mui-D3p2DSY1.js";import{a as Te}from"./axios-B4uVmeYG.js";import{a as W}from"./js-cookie-Cz0CWeBA.js";import{F as $e,a as Y,b as Be,c as Re}from"./react-icons-BQxfTaxZ.js";import{i as qe,p as X}from"./date-fns-X50TK9oK.js";import{d as De,e as h}from"./react-router-B_WJkAv4.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./@remix-run-B-RBrVrq.js";import"./tslib-wbdO-F7s.js";import"./stylis-DinRj2j6.js";import"./prop-types-15ULSoSZ.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))d(e);new MutationObserver(e=>{for(const s of e)if(s.type==="childList")for(const c of s.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&d(c)}).observe(document,{childList:!0,subtree:!0});function a(e){const s={};return e.integrity&&(s.integrity=e.integrity),e.referrerPolicy&&(s.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?s.credentials="include":e.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function d(e){if(e.ep)return;e.ep=!0;const s=a(e);fetch(e.href,s)}})();const He="modulepreload",Ne=function(i){return"/"+i},J={},f=function(t,a,d){let e=Promise.resolve();if(a&&a.length>0){document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),c=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));e=Promise.all(a.map(p=>{if(p=Ne(p),p in J)return;J[p]=!0;const u=p.endsWith(".css"),v=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${p}"]${v}`))return;const g=document.createElement("link");if(g.rel=u?"stylesheet":He,u||(g.as="script",g.crossOrigin=""),g.href=p,c&&g.setAttribute("nonce",c),document.head.appendChild(g),u)return new Promise((O,w)=>{g.addEventListener("load",O),g.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${p}`)))})}))}return e.then(()=>t()).catch(s=>{const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=s,window.dispatchEvent(c),!c.defaultPrevented)throw s})};function o(i,t){return t||(t=i.slice(0)),Object.freeze(Object.defineProperties(i,{raw:{value:Object.freeze(t)}}))}const Ve="/assets/logo-fundo-azul-CVrwm-yG.png";var K,Z,nn,en,tn,on,rn,sn,an,ln,cn,dn;D.add(Jn.faBars,Kn.faTimes);const Ue=r.nav(K||(K=o([`
  background: #00508c;
  padding: 0.5rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  z-index: 10;
`]))),Ge=r.img(Z||(Z=o([`
  height: 50px;
`]))),Qe=r.div(nn||(nn=o([`
  display: flex;
  align-items: center;

  @media screen and (max-width: 1040px) {
    display: none;
  }
`]))),E=r.div(en||(en=o([`
  position: relative;
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 0 1rem;
  cursor: pointer;
  transition: color 0.3s;
  white-space: nowrap;

  &:hover {
    color: #fac800;
  }

  @media screen and (max-width: 1200px) {
    font-size: 1rem;
  }

  & > a {
    color: inherit;
    text-decoration: none;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`]))),M=r.div(tn||(tn=o([`
  display: `,`;
  position: absolute;
  top: 100%;
  left: 0;
  background: #00508c;
  padding: 1rem;
  border-radius: 5px;
  z-index: 20;

  & a {
    display: block;
    color: white;
    margin: 0.5rem 0;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`])),i=>{let{$isOpen:t}=i;return t?"block":"none"}),We=r(m)(on||(on=o([`
  background: #28a745;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  margin-left: 1rem;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #218838;
  }
`]))),Ye=r.div(rn||(rn=o([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: block;
    color: white;
    font-size: 1.8rem;
    cursor: pointer;
    z-index: 11; /* Ensure it is above the mobile menu */
  }
`]))),Xe=r.div(sn||(sn=o([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: `,`;
    flex-direction: column;
    align-items: center;
    position: absolute;
    top: 70px;
    left: 0;
    width: 100%;
    background: #00508c;
    padding: 1rem 0;
    z-index: 9;
  }
`])),i=>{let{$isOpen:t}=i;return t?"flex":"none"}),P=r.div(an||(an=o([`
  width: 100%;
  text-align: center;
`]))),y=r(m)(ln||(ln=o([`
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 1rem 0;
  cursor: pointer;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),x=r(m)(cn||(cn=o([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),B=r.div(dn||(dn=o([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),Je=()=>{const[i,t]=l.useState(!1),[a,d]=l.useState(""),e=()=>{i==!0&&d(""),t(!i)},s=c=>{d(a===c?"":c)};return n.jsxs(Ue,{children:[n.jsx(m,{to:"/",children:n.jsx(Ge,{src:Ve,alt:"Logo"})}),n.jsx(Ye,{onClick:e,children:n.jsx(k,{icon:i?Kn.faTimes:Jn.faBars})}),n.jsxs(Qe,{children:[n.jsxs(E,{onMouseEnter:()=>d("quemSomos"),onMouseLeave:()=>d(""),onClick:()=>s("quemSomosMobile"),children:["Quem Somos",n.jsxs(M,{$isOpen:a==="quemSomos"||a==="quemSomosMobile",children:[n.jsx(m,{to:"/institucional",children:"Institucional"}),n.jsx(m,{to:"/estrutura",children:"Estrutura"}),n.jsx(m,{to:"/filiacao",children:"Filiação"}),n.jsx(m,{to:"/memoria",children:"Memória Institucional"})]})]}),n.jsxs(E,{onMouseEnter:()=>d("oQueFazemos"),onMouseLeave:()=>d(""),onClick:()=>s("oQueFazemosMobile"),children:["O Que Fazemos",n.jsxs(M,{$isOpen:a==="oQueFazemos"||a==="oQueFazemosMobile",children:[n.jsx(m,{to:"/eixos",children:"Eixos de Atuação"}),n.jsx(m,{to:"/acoes",children:"Ações e Temáticas"}),n.jsx(m,{to:"/eventos",children:"Eventos e Workshops"})]})]}),n.jsxs(E,{onMouseEnter:()=>d("mobilidade"),onMouseLeave:()=>d(""),onClick:()=>s("mobilidadeMobile"),children:["Intercâmbios",n.jsxs(M,{$isOpen:a==="mobilidade"||a==="mobilidadeMobile",children:[n.jsx(m,{to:"/intercambio_nacional",children:"Intercâmbios Nacionais"}),n.jsx(m,{to:"/intercambio_internacional",children:"Intercâmbios Internacionais"}),n.jsx(m,{to:"/regulamento",children:"Regulamento de Intercâmbios"}),n.jsx(m,{to:"/outras-modalidades",children:"Outras Modalidades de Intercâmbio"}),n.jsx(m,{to:"/social-programs",children:"Social Programs"})]})]}),n.jsxs(E,{onMouseEnter:()=>d("midias"),onMouseLeave:()=>d(""),onClick:()=>s("midiasMobile"),children:["Mídias e Documentos",n.jsxs(M,{$isOpen:a==="midias"||a==="midiasMobile",children:[n.jsx(m,{to:"/arquivos/ressonancia-poetica",children:"Ressonância Poética"}),n.jsx(m,{to:"/arquivos/informa-susi",children:"Informa SUSi"}),n.jsx(m,{to:"/arquivos/bms",children:"Brazilian Medical Students"}),n.jsx(m,{to:"/arquivos/relatorios",children:"Relatórios"}),n.jsx(m,{to:"/arquivos/notas-de-posicionamento",children:"Notas de Posicionamento"}),n.jsx(m,{to:"/arquivos/declaracoes-de-politica",children:"Declarações de Política"}),n.jsx(m,{to:"/arquivos/intercambio-nacional",children:"Intercâmbio Nacional"}),n.jsx(m,{to:"/arquivos/intercambio-internacional",children:"Intercâmbio Internacional"}),n.jsx(m,{to:"/arquivos/regulamento-intercambios",children:"Regulamento de Intercâmbios"})]})]}),n.jsx(E,{children:n.jsx(m,{to:"/noticias",children:"Notícias"})}),n.jsxs(E,{onMouseEnter:()=>d("membros"),onMouseLeave:()=>d(""),onClick:()=>s("membrosMobile"),children:["Membros",n.jsxs(M,{$isOpen:a==="membros"||a==="membrosMobile",children:[n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"}),n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"}),n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})]})]}),n.jsx(We,{to:"/filie-se",children:"FILIE-SE"})]}),n.jsxs(Xe,{$isOpen:i,children:[n.jsxs(P,{children:[n.jsx(y,{onClick:()=>s("quemSomosMobile"),children:"Quem Somos"}),a==="quemSomosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/institucional",onClick:e,children:"Institucional"}),n.jsx(x,{to:"/estrutura",onClick:e,children:"Estrutura"}),n.jsx(x,{to:"/filiacao",onClick:e,children:"Filiação"}),n.jsx(x,{to:"/memoria",onClick:e,children:"Memória Institucional"})]})]}),n.jsxs(P,{children:[n.jsx(y,{onClick:()=>s("oQueFazemosMobile"),children:"O Que Fazemos"}),a==="oQueFazemosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/eixos",onClick:e,children:"Eixos de Atuação"}),n.jsx(x,{to:"/acoes",onClick:e,children:"Ações e Temáticas"}),n.jsx(x,{to:"/eventos",onClick:e,children:"Eventos e Workshops"})]})]}),n.jsxs(P,{children:[n.jsx(y,{onClick:()=>s("mobilidadeMobile"),children:"Intercâmbios"}),a==="mobilidadeMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/intercambio_nacional",onClick:e,children:"Intercâmbios Nacionais"}),n.jsx(x,{to:"/intercambio_internacional",onClick:e,children:"Intercâmbios Internacionais"}),n.jsx(x,{to:"/regulamento",onClick:e,children:"Regulamento de Intercâmbios"}),n.jsx(x,{to:"/outras-modalidades",onClick:e,children:"Outras Modalidades de Intercâmbio"}),n.jsx(x,{to:"/social-programs",onClick:e,children:"Social Programs"})]})]}),n.jsxs(P,{children:[n.jsx(y,{onClick:()=>s("midiasMobile"),children:"Mídias e Documentos"}),a==="midiasMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/arquivos/ressonancia-poetica",onClick:e,children:"Ressonância Poética"}),n.jsx(x,{to:"/arquivos/informa-susi",onClick:e,children:"Informa SUSi"}),n.jsx(x,{to:"/arquivos/bms",onClick:e,children:"Brazilian Medical Students"}),n.jsx(x,{to:"/arquivos/relatorios",onClick:e,children:"Relatórios"}),n.jsx(x,{to:"/arquivos/notas-de-posicionamento",onClick:e,children:"Notas de Posicionamento"}),n.jsx(x,{to:"/arquivos/declaracoes-de-politica",onClick:e,children:"Declarações de Política"}),n.jsx(x,{to:"/arquivos/intercambio-nacional",onClick:e,children:"Intercâmbio Nacional"}),n.jsx(x,{to:"/arquivos/intercambio-internacional",onClick:e,children:"Intercâmbio Internacional"}),n.jsx(x,{to:"/arquivos/regulamento-intercambios",onClick:e,children:"Regulamento de Intercâmbios"})]})]}),n.jsx(y,{to:"/noticias",onClick:e,children:"Notícias"}),n.jsxs(P,{children:[n.jsx(y,{onClick:()=>s("membrosMobile"),children:"Membros"}),a==="membrosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(B,{onClick:e,children:n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"})}),n.jsx(B,{onClick:e,children:n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"})}),n.jsx(B,{onClick:e,children:n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})})]})]}),n.jsx(y,{to:"/filie-se",onClick:e,children:"FILIE-SE"})]})]})};var mn;const Ke=()=>Oe(Ee,{styles:Ce(mn||(mn=o([`
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap");

      html,
      body,
      body1,
      #root,
      #__next {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif !important;
        background-color: #ffffff;
        color: rgba(0, 0, 0, 0.87);
        font-weight: 400;
        font-size: 1rem;
        line-height: 1.5;
        letter-spacing: 0.00938em;
      }

      *,
      *::before,
      *::after {
        box-sizing: inherit;
      }

      a {
        text-decoration: none;
        color: inherit;
      }

      h1,
      h6,
      h2 {
        margin: 0;
      }

      button {
        outline: none;
      }

      .carousel-container {
        max-width: 1200px;
        margin: 0 auto;
      }

      .carousel .slide {
        background: none;
      }

      /* CSS for BrazilMap component */
      .container {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: flex-start;
        width: 100%;
        margin: 0;
        padding: 20px;
        box-sizing: border-box;
      }

      .map-container {
        flex: 1;
        min-width: 300px;
        max-width: 600px;
        margin: 0 20px; /* Medium margin on the left and right sides */
      }

      .legend-container {
        display: flex;
        flex-direction: column;
        margin-left: 20px;
      }

      .legend-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
      }

      .color-box {
        width: 20px;
        height: 20px;
        margin-right: 10px;
      }

      /* Media query for mobile view */
      @media (max-width: 768px) {
        .container {
          flex-direction: column;
          align-items: center;
        }
        .map-container {
          margin: 0; /* Remove margins on mobile */
        }
        .legend-container {
          flex-direction: row;
          flex-wrap: wrap;
          justify-content: center;
          margin-left: 0;
          margin-top: 20px; /* Space between map and legend */
        }
        .legend-item {
          margin: 5px; /* Adjust margin for horizontal layout */
        }
      }
    `])))});var pn;je(pn||(pn=o([`
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

  body {
    font-family: 'Poppins', sans-serif;
  }
`])));D.add(ve.faTwitter,we.faInstagram,_e.faMapMarkerAlt,ye.faEnvelope,ke.faPhone);const Ze=S("footer")({backgroundColor:"#00508C",color:"white",padding:"20px 0",textAlign:"center"}),R=S("div")({display:"flex",alignItems:"center",margin:"5px 0",justifyContent:"center","& svg":{marginRight:"10px"}}),nt=S("div")({marginTop:"10px"}),xn=S(ze)({color:"white",margin:"0 10px",fontSize:"1.5rem",transition:"color 0.3s","&:hover":{color:"#FAC800"}}),et=()=>n.jsx(Ze,{children:n.jsx(H,{maxWidth:"lg",children:n.jsxs(z,{container:!0,spacing:4,children:[n.jsxs(z,{item:!0,xs:12,md:4,children:[n.jsx(j,{variant:"h6",gutterBottom:!0,children:"Endereço"}),n.jsxs(R,{children:[n.jsx(k,{icon:"map-marker-alt"}),n.jsx(j,{variant:"body1",children:"Avenida Paulista nº 1765 - 7º Andar"})]}),n.jsx(j,{variant:"body1",children:"Boa Vista, São Paulo/SP - Brasil"})]}),n.jsxs(z,{item:!0,xs:12,md:4,children:[n.jsx(j,{variant:"h6",gutterBottom:!0,children:"Contato"}),n.jsxs(R,{children:[n.jsx(k,{icon:"envelope"}),n.jsx(j,{variant:"body1",children:"atendimento@ifmsabrazil.org"})]}),n.jsxs(R,{children:[n.jsx(k,{icon:"phone"}),n.jsx(j,{variant:"body1",children:"Tel: + 55 11 3170-3251"})]})]}),n.jsxs(z,{item:!0,xs:12,md:4,children:[n.jsx(j,{variant:"h6",gutterBottom:!0,children:"Siga-nos"}),n.jsxs(nt,{children:[n.jsx(xn,{href:"https://twitter.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(k,{icon:["fab","twitter"]})}),n.jsx(xn,{href:"https://instagram.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(k,{icon:["fab","instagram"]})})]})]})]})})}),tt=S(H)({display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh"}),ot=S(j)({marginTop:"16px",color:"#00508C"}),se=()=>n.jsxs(tt,{children:[n.jsx(Se,{}),n.jsx(ot,{variant:"h6",children:"Carregando..."})]});var hn,un,gn,fn,bn,jn;const it=Xn(hn||(hn=o([`
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
`]))),rt=Xn(un||(un=o([`
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.8);
  }
`]))),st=r.div(gn||(gn=o([`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #00508c;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  cursor: pointer;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease-in-out;
  z-index: 1000;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 46px;
    height: 46px;
  }
`]))),at=r.div(fn||(fn=o([`
  position: absolute;
  top: -1px;
  right: -1px;
  background-color: #00963c;
  font-weight: bold;
  color: white;
  border-radius: 50%;
  width: 16px;
  height: 16px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 10px;
`]))),lt=r.div(bn||(bn=o([`
  position: fixed;
  bottom: 80px;
  right: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 1000;
  transition: all 0.2s ease-in-out;
  animation: `,` 0.2s forwards;

  @media (max-width: 768px) {
    bottom: 76px;
    right: 16px;
  }
`])),i=>i.isOpen?it:rt),q=r.a(jn||(jn=o([`
  color: #00508c;
  text-decoration: none;
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 8px 0;
  width: 100%;
  transition: all 0.2s ease-in-out;

  &:hover {
    color: #003366;
  }

  svg {
    margin-right: 10px;
  }
`]))),ct=i=>{let{showNotification:t,onAlertReopen:a}=i;const[d,e]=l.useState(!1),s=()=>{a(),c()},c=()=>{e(!d)};return n.jsxs(n.Fragment,{children:[n.jsxs(st,{onClick:c,children:[d?n.jsx($e,{size:24}):n.jsx(Y,{size:24}),t&&!d&&n.jsx(at,{children:"1"})]}),d&&n.jsxs(lt,{isOpen:d,children:[n.jsxs(q,{href:"mailto:atendimento@ifmsabrazil.org",children:[n.jsx(Y,{size:20}),"atendimento@ifmsabrazil.org"]}),n.jsxs(q,{href:"https://instagram.com/ifmsabrazil",target:"_blank",children:[n.jsx(Be,{size:20}),"@ifmsabrazil"]}),t&&n.jsxs(q,{onClick:s,children:[n.jsx(Re,{size:20}),"Ver aviso novamente"]})]})]})};var vn,wn,_n,yn,kn,On;const dt=r.section(vn||(vn=o([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #FFFFFF;
  text-align: center;
`]))),mt=r.h2(wn||(wn=o([`
  font-family: 'Poppins', sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),pt=r.div(_n||(_n=o([`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
`]))),xt=r.div(yn||(yn=o([`
  flex: 1 1 30%;
  max-width: 30%;
  display: flex;
  justify-content: center;

  @media (max-width: 991px) {
    flex: 1 1 45%;
    max-width: 45%;
  }

  @media (max-width: 600px) {
    flex: 1 1 100%;
    max-width: 100%;
  }
`]))),ht=r.div(kn||(kn=o([`
  position: relative;
  height: auto;
  font-family: 'Poppins', sans-serif;
  color: rgba(255, 255, 255, 1);
  text-align: center;
  background-color: `,`;
  flex-grow: 1;
  width: 100%;
  align-self: stretch;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`])),i=>i.bgColor),ut=r.div(On||(On=o([`
  font-size: 24px;
`])));function gt(){const i=[{id:1,bgColor:"rgba(0, 80, 140, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Em 26 Estados"}),n.jsx("br",{}),n.jsx("strong",{children:"+ Distrito Federal"})]})},{id:2,bgColor:"rgba(250, 200, 0, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Temos +11000"}),n.jsx("br",{}),n.jsx("strong",{children:"membros filiados"})]})},{id:3,bgColor:"rgba(0, 150, 60, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Presentes em +220"}),n.jsx("br",{}),n.jsx("strong",{children:"escolas médicas"})]})}];return n.jsxs(dt,{children:[n.jsx(mt,{children:"Nossa abrangência"}),n.jsx(pt,{children:i.map(t=>n.jsx(xt,{children:n.jsx(ht,{bgColor:t.bgColor,children:n.jsx(ut,{children:t.text})})},t.id))})]})}var Cn,En,zn,Sn,In;D.add(Zn.faBook,ne.faGraduationCap,ee.faHandsHelping,te.faHeartbeat,oe.faHospital,ie.faUniversity,re.faSearch);const ft=r.section(Cn||(Cn=o([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
  text-align: center;
`]))),bt=r.h2(En||(En=o([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),jt=r.div(zn||(zn=o([`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 20px;
  justify-content: center;

  @media (max-width: 991px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    & > :nth-child(5) {
      grid-column: span 2;
    }
  }
`]))),vt=r.div(Sn||(Sn=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center; /* Center the content vertically */
  padding: 20px;
  background-color: `,`;
  color: `,`;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
  font-family: "Poppins", sans-serif;
  text-align: center;
  border: `,`;
  width: 100%; /* Ensure it takes the full width of the grid cell */
  height: 100%; /* Set a fixed height for all cards */

  &:hover {
    transform: translateY(-10px);
  }

  @media (min-width: 992px) {
    height: 100%; /* Adjust height for larger screens if needed */
  }
`])),i=>i.bgColor,i=>i.color||"rgba(255, 255, 255, 1)",i=>i.border||"none"),wt=r.div(In||(In=o([`
  font-size: 18px;
  margin-top: 10px;
`])));function _t(){const i=[{id:1,bgColor:"rgba(182, 120, 38, 1)",text:"Representatividade estudantil",icon:ne.faGraduationCap,link:"/eixos#representatividade-estudantil"},{id:2,bgColor:"rgba(0, 0, 0, 1)",text:"Capacity Building",icon:Zn.faBook,link:"/eixos#construcao-de-habilidades"},{id:3,bgColor:"#FFFFFF",text:"Educação Médica",icon:oe.faHospital,color:"#000",border:"2px solid #000",link:"/eixos#educacao-medica"},{id:4,bgColor:"rgba(220, 0, 0, 1)",text:"Promoção de Saúde",icon:te.faHeartbeat,link:"/eixos#promocao-de-saude"},{id:5,bgColor:"rgba(0, 150, 60, 1)",text:"Humanização",icon:ee.faHandsHelping,link:"/eixos#humanizacao"},{id:6,bgColor:"rgba(0, 80, 140, 1)",text:"Mobilidade Estudantil",icon:ie.faUniversity,link:"/eixos#mobilidade-academica"},{id:7,bgColor:"rgba(128, 128, 128, 1)",text:"Pesquisa e Extensão",icon:re.faSearch,link:"/eixos#pesquisa"}];return n.jsxs(ft,{children:[n.jsx(bt,{children:"Nossos eixos de atuação"}),n.jsx(jt,{children:i.map(t=>n.jsx("a",{href:t.link,style:{textDecoration:"none"},children:n.jsxs(vt,{bgColor:t.bgColor,color:t.color,border:t.border,children:[n.jsx(k,{icon:t.icon,size:"3x"}),n.jsx(wt,{children:t.text})]})},t.id))})]})}var Mn,Pn;const yt=r(Ie)(Mn||(Mn=o([`
  display: flex;
  flex-direction: column;
  margin: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
  border-radius: 10px;

  &:hover {
    transform: translateY(-5px);
  }

  @media (min-width: 600px) {
    flex-direction: row;
  }
`]))),kt=r(Me)(Pn||(Pn=o([`
  width: 100%;
  height: auto;

  @media (min-width: 600px) {
    width: 160px !important;
    height: auto;
    object-fit: cover;
    margin-left: auto;
  }
`]))),Ot=i=>{let{post:t}=i;return n.jsxs(yt,{children:[n.jsxs(Pe,{style:{flex:1},children:[n.jsx(j,{component:"h2",variant:"h5",gutterBottom:!0,children:t.title}),n.jsx(j,{variant:"subtitle1",color:"text.secondary",children:t.author}),n.jsx(j,{variant:"subtitle2",color:"text.secondary",gutterBottom:!0,children:t.date?new Date(t.date).toLocaleDateString():""}),n.jsx(j,{variant:"body1",paragraph:!0,children:t.summary})]}),n.jsx(kt,{component:"img",image:t.imageLink,alt:"Blog image"})]})},Ct={ç:"c",Ç:"C",á:"a",Á:"A",é:"e",É:"E",í:"i",Í:"I",ó:"o",Ó:"O",ú:"u",Ú:"U",à:"a",À:"A",ã:"a",Ã:"A",õ:"o",Õ:"O"},Et=i=>i.split("").map(t=>Ct[t]||t).join(""),zt=i=>Et(i).toLowerCase().replace(/[^a-z0-9]+/g,"-");var An,Ln;const St=r.section(An||(An=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
`]))),It=r.h2(Ln||(Ln=o([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Mt=i=>{let{posts:t,loading:a}=i;if(a)return n.jsx(se,{});const d=c=>c.sort((p,u)=>u["dia-mes-ano"]-p["dia-mes-ano"]),s=function(c){let p=arguments.length>1&&arguments[1]!==void 0?arguments[1]:4;const u=d(c),v=u.filter(w=>w["forcar-pagina-inicial"]);if(v.length>=p)return v;const g=u.filter(w=>!w["forcar-pagina-inicial"]);return v.concat(g.slice(0,p-v.length))}(t);return n.jsxs(St,{children:[n.jsx(It,{children:"Últimas Notícias"}),n.jsx(H,{maxWidth:"lg",children:n.jsx(z,{container:!0,spacing:4,children:s.map((c,p)=>n.jsx(z,{item:!0,xs:12,sm:6,children:n.jsx(m,{to:"/arquivo/".concat(c.id,"/").concat(zt(c.title)),children:n.jsx(Ot,{post:c})})},p))})})]})},Pt="/assets/background-image-YkmHsWZG.webp";var Fn,Tn,$n,Bn,Rn,qn,Dn;function At(i){let{message:t,title:a,buttonUrl:d,buttonText:e,toggleButton:s,toggleMessage:c,onClose:p,forceOpen:u,isOpen:v,setIsOpen:g}=i;l.useEffect(()=>{u&&g(!0)},[u]);const O=()=>{p&&p()};return!v&&!u?null:n.jsx(Ft,{children:n.jsxs(Tt,{children:[n.jsxs($t,{onClick:O,children:[n.jsx(Lt,{}),n.jsx("span",{className:"sr-only",children:"Close"})]}),n.jsxs(Bt,{children:[n.jsx(Rt,{children:a}),c?n.jsx(qt,{children:t}):null,s?n.jsx(m,{to:d,target:"_blank",rel:"noopener noreferrer",children:n.jsx(Dt,{children:e})}):null]})]})})}function Lt(i){return n.jsxs("svg",{...i,xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[n.jsx("path",{d:"M18 6 6 18"}),n.jsx("path",{d:"m6 6 12 12"})]})}const Ft=r.div(Fn||(Fn=o([`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`]))),Tt=r.div(Tn||(Tn=o([`
  background-color: hsl(142, 86%, 28%);
  padding: 2rem 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  max-width: 42rem;
  position: relative;
`]))),$t=r.button($n||($n=o([`
  position: absolute;
  top: 1rem;
  right: 1rem;
  color: hsl(356, 29%, 98%);
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 0.25rem;

  &:hover {
    color: rgba(356, 29%, 98%, 0.8);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`]))),Bt=r.div(Bn||(Bn=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`]))),Rt=r.h2(Rn||(Rn=o([`
  font-size: 1.875rem;
  font-weight: bold;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1rem;
`]))),qt=r.p(qn||(qn=o([`
  font-size: 1.125rem;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1.5rem;
`]))),Dt=r.a(Dn||(Dn=o([`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem 1.5rem;
  border-radius: 0.25rem;
  background-color: hsl(356, 29%, 98%);
  color: hsl(142, 86%, 28%);
  font-weight: 500;
  text-decoration: none;

  &:hover {
    background-color: rgba(356, 29%, 98%, 0.9);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`])));var Hn,Nn,Vn,Un,Gn,Qn;const Ht=r.div(Hn||(Hn=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  overflow: hidden;
`]))),Nt=r.div(Nn||(Nn=o([`
  width: 100%;
  height: 100vh;
  background-image: url(`,`);
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  text-align: center;
  padding: 20px;
  background-color: rgba(0, 0, 0, 0.5);
`])),Pt),Vt=r.h1(Vn||(Vn=o([`
  font-size: 3rem;
  font-weight: 700;
  padding: 0 20px;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
`]))),Ut=r.button(Un||(Un=o([`
  margin-top: 20px;
  padding: 12px 24px;
  font-size: 1rem;
  font-weight: bold;
  color: #00508c;
  background-color: #fac800;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: translateY(-3px);
    background-color: #e6b800;
    color: #004080;
  }
`]))),Gt=r.button(Gn||(Gn=o([`
  position: fixed;
  bottom: 20px;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: white;
  border: none;
  cursor: pointer;
  display: `,`;
  justify-content: center;
  align-items: center;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
  }

  svg {
    width: 24px;
    height: 24px;
    fill: #00508c;
  }
`])),i=>{let{show:t}=i;return t?"flex":"none"}),Qt=r.div(Qn||(Qn=o([`
  width: 100%;
  padding: 60px 20px;
  background-color: white;
  text-align: center;
  color: #333;

  h2 {
    font-size: 2rem;
    margin-bottom: 20px;
  }

  p {
    max-width: 800px;
    margin: 0 auto;
    line-height: 1.6;
  }
`]))),Wt=()=>{const[i,t]=l.useState([]),[a,d]=l.useState(null),[e,s]=l.useState(null),[c,p]=l.useState(!1),[u,v]=l.useState(null),g=W.get("alertHash"),[O,w]=l.useState(!0),[ae,N]=l.useState(!0),[le,A]=l.useState(!1),[L,V]=l.useState(!1),ce="https://api.ifmsabrazil.org/api/blogs/recent";l.useEffect(()=>{const F=(_,T,b,G,C,he)=>{const Q="".concat(_).concat(T).concat(b).concat(G).concat(C).concat(he);let I=0;for(let $=0;$<Q.length;$++){const ue=Q.charCodeAt($);I=(I<<5)-I+ue,I|=0}return I.toString()};(async()=>{try{const _=await Te.get(ce),{recentBlogs:T,alert:b}=_.data;if(t(T),b&&b.toggleDate&&qe(new Date,{start:X(b.dateStart),end:X(b.dateEnd)})){const C=F(b.message,b.title,b.buttonUrl,b.buttonText,b.toggleButton,b.toggleMessage);p(g!==C),A(g===C),d(b),v(C),s(b),(!g||g!==C)&&p(!0)}}catch(_){console.error("Error fetching posts:",_)}finally{w(!1)}})()},[]),l.useEffect(()=>{!c&&u&&!L&&W.set("alertHash",u,{expires:7})},[c,u,L]);const U=()=>{const F=window.scrollY,_=window.innerHeight*.7;F<_?N(!0):N(!1)},de=()=>{window.scrollTo({top:window.innerHeight,behavior:"smooth"})};l.useEffect(()=>(window.addEventListener("scroll",U),()=>{window.removeEventListener("scroll",U)}),[]);const me=()=>{A(!0),p(!1),V(!1)},pe=()=>{A(!1),p(!0),d(e),V(!0)};return n.jsxs(Ht,{children:[a&&n.jsx(At,{toggleMessage:a.toggleMessage,message:a.message,toggleButton:a.toggleButton,buttonText:a.buttonText,buttonUrl:a.buttonUrl,title:a.title,forceOpen:L,onClose:me,isOpen:c,setIsOpen:p}),n.jsxs(Nt,{children:[n.jsx(Vt,{children:"Estudantes de medicina que fazem a diferença"}),n.jsx(Ut,{onClick:()=>window.location.href="/filie-se",children:"Faça parte"}),n.jsx(Gt,{show:ae,onClick:de,children:n.jsx("svg",{viewBox:"0 0 24 24",children:n.jsx("path",{d:"M12 16.5l-7-7 1.41-1.41L12 13.67l5.59-5.58L19 9.5l-7 7z"})})})]}),n.jsxs(Qt,{children:[n.jsx("h2",{children:"Breve Introdução"}),n.jsx("p",{children:"Fundada em 1991 como primeira associação da América Latina vinculada à International Federation of Medical Students’ Association (IFMSA), a IFMSA Brazil interliga estudantes de medicina de todo o país para fazer a diferença na sociedade e na formação médica."})]}),n.jsx(gt,{}),n.jsx(_t,{}),n.jsx(Mt,{posts:i,loading:O}),n.jsx(ct,{showNotification:le,onAlertReopen:pe})]})},Yt=Ae({typography:{fontFamily:"Poppins, Arial, sans-serif"},components:{MuiCssBaseline:{styleOverrides:`
        @font-face {
          font-family: 'Poppins';
          font-style: normal;
          font-display: swap;
          font-weight: 400;
          src: local('Poppins'), local('Poppins-Regular'), url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap') format('woff2');
          unicodeRange: U+0000-00FF; /* Latin characters */
        }
      `}}}),Wn=l.lazy(()=>f(()=>import("./MarkdownPage-bREgTZA-.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25]))),Xt=l.lazy(()=>f(()=>import("./GeradorLink-BvzLFz8y.js"),__vite__mapDeps([26,1,2,6,7,8,9,10,11,12,13]))),Jt=l.lazy(()=>f(()=>import("./Arquivos-_iLfxw24.js"),__vite__mapDeps([27,1,2,17,18,9,10,19,4,28,20,21,6,7,8,11,12,13,14,15,16,22,23,24]))),Kt=l.lazy(()=>f(()=>import("./Estrutura-D2QeCl0k.js"),__vite__mapDeps([29,1,2,4,30,31,6,7,8,9,10,11,12,13,32,21,33,34,35,36,3,5,25,16,14,15,17,18,19,20,22,23,24]))),Yn=l.lazy(()=>f(()=>import("./Filiacao-CZ0cuTkg.js"),__vite__mapDeps([37,1,2,17,18,9,10,19,23,6,7,8,11,12,13,4,38,36,3,5,25,16,14,15,20,21,22,24]))),Zt=l.lazy(()=>f(()=>import("./NotFound-DjpsNUeh.js"),__vite__mapDeps([39,1,2,17,18,9,10,19,16,12,13,14,15,20,21,6,7,8,11,4,22,23,24]))),no=l.lazy(()=>f(()=>import("./Noticias-ConqDetI.js"),__vite__mapDeps([40,1,2,17,18,9,10,19,16,12,13,14,15,28,20,21,6,7,8,11,4,22,23,24]))),eo=l.lazy(()=>f(()=>import("./Institucional-CqBadN7M.js"),__vite__mapDeps([41,1,2,36,3,5,6,7,8,9,10,11,12,13,25,16,14,15,17,18,19,20,21,4,22,23,24]))),to=l.lazy(()=>f(()=>import("./AcoesETematicas-C2q4Nw7n.js"),__vite__mapDeps([42,1,2,36,3,5,6,7,8,9,10,11,12,13,25,16,14,15,17,18,19,20,21,4,22,23,24]))),oo=l.lazy(()=>f(()=>import("./SocialPrograms-BTDze6rF.js"),__vite__mapDeps([43,1,2,36,3,5,6,7,8,9,10,11,12,13,25,16,14,15,17,18,19,20,21,4,22,23,24]))),io=l.lazy(()=>f(()=>import("./Eixos-D94FvlQN.js"),__vite__mapDeps([44,1,2,36,3,5,6,7,8,9,10,11,12,13,25,14,15]))),ro=l.lazy(()=>f(()=>import("./Eventos-BhVtkaDV.js"),__vite__mapDeps([45,1,2,36,3,5,6,7,8,9,10,11,12,13,25,16,14,15,17,18,19,20,21,4,22,23,24]))),so=l.lazy(()=>f(()=>import("./MemoriaInstitucional-BJUdPq4t.js"),__vite__mapDeps([46,1,2,36,3,5,6,7,8,9,10,11,12,13,25,16,14,15,17,18,19,20,21,4,22,23,24]))),ao=l.lazy(()=>f(()=>import("./Regulamento-B2PUvoij.js"),__vite__mapDeps([47,1,2,36,3,5,6,7,8,9,10,11,12,13,25]))),lo=l.lazy(()=>f(()=>import("./OutrosIntercambios-CGTohQ1h.js"),__vite__mapDeps([48,1,2,36,3,5,6,7,8,9,10,11,12,13,25]))),co=l.lazy(()=>f(()=>import("./IntercambioInternacional-C46sCKfl.js"),__vite__mapDeps([49,1,2,36,3,5,6,7,8,9,10,11,12,13,25]))),mo=l.lazy(()=>f(()=>import("./IntercambioNacional--hY0w_YM.js"),__vite__mapDeps([50,1,2,36,3,5,6,7,8,9,10,11,12,13,25]))),po=()=>n.jsx(Le,{theme:Yt,children:n.jsxs(be,{children:[n.jsx(Ke,{}),n.jsx(Fe,{}),n.jsx(Je,{}),n.jsx(l.Suspense,{fallback:n.jsx(se,{}),children:n.jsxs(De,{children:[n.jsx(h,{path:"/",element:n.jsx(Wt,{})}),n.jsx(h,{path:"/arquivo/:id/:title",element:n.jsx(Wn,{needsExternal:!0})}),n.jsx(h,{path:"/gerarlink",element:n.jsx(Xt,{})}),n.jsx(h,{path:"/filie-se",element:n.jsx(Yn,{})}),n.jsx(h,{path:"/estrutura",element:n.jsx(Kt,{})}),n.jsx(h,{path:"/filiacao",element:n.jsx(Yn,{})}),n.jsx(h,{path:"/noticias",element:n.jsx(no,{})}),n.jsx(h,{path:"/institucional",element:n.jsx(eo,{})}),n.jsx(h,{path:"/acoes",element:n.jsx(to,{})}),n.jsx(h,{path:"/arquivos/:type",element:n.jsx(Jt,{})}),n.jsx(h,{path:"/social-programs",element:n.jsx(oo,{})}),n.jsx(h,{path:"/eixos",element:n.jsx(io,{})}),n.jsx(h,{path:"/eventos",element:n.jsx(ro,{})}),n.jsx(h,{path:"/regulamento",element:n.jsx(ao,{})}),n.jsx(h,{path:"/outras-modalidades",element:n.jsx(lo,{})}),n.jsx(h,{path:"/memoria",element:n.jsx(so,{})}),n.jsx(h,{path:"/intercambio_nacional",element:n.jsx(mo,{})}),n.jsx(h,{path:"/intercambio_internacional",element:n.jsx(co,{})}),n.jsx(h,{path:"/tutorial",element:n.jsx(Wn,{needsExternal:!1,filepath:"/markdown/pagina.md"})}),n.jsx(h,{path:"*",element:n.jsx(Zt,{})})," "]})}),n.jsx(et,{})]})}),xo=document.getElementById("root"),ho=fe(xo);ho.render(n.jsx(ge.StrictMode,{children:n.jsx(po,{})}));export{se as L,o as _,f as a,zt as g};
