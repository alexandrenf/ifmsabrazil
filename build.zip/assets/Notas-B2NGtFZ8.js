import{j as o}from"./react-DaPl5ws4.js";import{M as e}from"./MarkdownContent-CQ6Z632h.js";import{s as t,C as a,T as r}from"./@mui-BqBmPETx.js";import"./@babel-CNkBngnk.js";import"./markdown-to-jsx-CXBEPAoT.js";import"./prismjs-DEnDlMkx.js";/* empty css                   */import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./react-transition-group-cLDJx4Bm.js";import"./react-dom-CWF6clnO.js";import"./scheduler-CzFDRTuY.js";const n=t(a)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),i=t(r)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),b=()=>o.jsxs(n,{children:[o.jsx(i,{variant:"h4",children:"Notas de Posicionamento"}),o.jsx(e,{content:`

Nota Oficial é a ferramenta pela qual a IFMSA Brazil pode se expressar à sociedade a respeito de acontecimentos específicos, não contemplados total ou parcialmente pelas Declarações de Políticas vigentes, e cuja urgência demandada não permite discussão ampla para deliberação de posicionamento em plenária de Assembléia Geral.


`})]});export{b as default};
