import{_ as o}from"./index-CH7SBxad.js";import{j as t}from"./react-DaPl5ws4.js";import{p as n}from"./styled-components-D58U5FK1.js";import{L as a}from"./react-router-dom-BFBG7k2k.js";import"./react-dom-CWF6clnO.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./react-cookie-consent-xWEKRR8T.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./@mui-Decc1woQ.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";import"./axios-B4uVmeYG.js";import"./js-cookie-Cz0CWeBA.js";import"./react-icons-BQxfTaxZ.js";import"./date-fns-X50TK9oK.js";import"./react-router-B_WJkAv4.js";import"./@remix-run-B-RBrVrq.js";import"./tslib-wbdO-F7s.js";import"./stylis-DinRj2j6.js";var e,r,i,m,p;const s=n.div(e||(e=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  text-align: center;
  background-color: #f8f8f8;
  color: #333;
  padding: 20px;
`]))),c=n.h1(r||(r=o([`
  font-size: 4rem;
  margin-bottom: 16px;
`]))),l=n.h2(i||(i=o([`
  font-size: 2rem;
  margin-bottom: 16px;
`]))),d=n.p(m||(m=o([`
  font-size: 1.2rem;
  margin-bottom: 24px;
`]))),x=n(a)(p||(p=o([`
  font-size: 1.2rem;
  color: #00508c;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`]))),q=()=>t.jsxs(s,{children:[t.jsx(c,{children:"404"}),t.jsx(l,{children:"Page Not Found"}),t.jsx(d,{children:"Sorry, the page you are looking for does not exist."}),t.jsx(x,{to:"/",children:"Go to Home"})]});export{q as default};
