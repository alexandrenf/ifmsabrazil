import{j as e}from"./react-CLPtFgDq.js";import"./index-BxP-9qRJ.js";import{M as s}from"./MarkdownContent-BNKm4Bhr.js";import{s as a,C as o,T as i}from"./@mui-B86xCNSa.js";import"./@babel-f5lBRPU2.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-Am9psY4u.js";import"./react-router-BzRFIFMZ.js";import"./@remix-run-YI_hLLil.js";import"./styled-components-BY_vc4YD.js";import"./tslib-wbdO-F7s.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./@fortawesome-B6QlLdFu.js";import"./prop-types-1yzuAbYU.js";import"./webfontloader-DM8E560Z.js";import"./axios-B4uVmeYG.js";import"./react-icons-CrkDh4zl.js";import"./clsx-B-dksMZM.js";import"./react-transition-group-CLuBo2_z.js";import"./react-is-DcfIKM1A.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */const n=a(o)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),r=a(i)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),O=()=>e.jsxs(n,{children:[e.jsx(r,{variant:"h4",children:"Eventos e Workshops"}),e.jsx(s,{content:`

  ### Sumário
1. [Assembleias Gerais](#assembleias-gerais)
2. [Assembleias Regionais](#assembleias-regionais)
3. [Workshops](#workshops)

São considerados eventos oficiais da IFMSA Brazil as Assembleias Gerais, Assembleias Regionais, Workshops e o Congresso Brasileiro de Médico-Estudantil de Habilidades Médicas.

## Assembleias Gerais

### Quais são seus propósitos?

- Inspirar futuras gerações de acadêmicos e médicos;
- Transformar seus participantes em líderes em saúde ao debater promoção de saúde, educação médica, humanização, mobilidade estudantil, criticidade e representatividade;

### O que são?

- Maior espaço deliberativo da IFMSA Brazil;

- Reuniões de delegados de Comitês Locais, Diretoria Executiva, Alumni e Observadores Externos de todo o país;

### Quais são as vantagens de participar?

Treinamentos, apresentação de trabalhos e pesquisa, sessões dinâmicas de aprendizado nos nossos eixos temáticos, representatividade, networking, participar ativamente das deliberações da IFMSA Brazil.

### Quando acontecem?

Semestralmente.

### Quem pode ir?

Estudantes e médicos que se sintam representados pela IFMSA Brazil.

### Como participar?

Os nossos filiados recebem o convite para as Assembleias Gerais através de e-mail. Para mais informações, entre em contato com a sua escola médica filiada ou então através de atendimento@ifmsabrazil.org para mais informações.

## Assembleias Regionais

### Quais são seus propósitos?

- Inspirar futuras gerações de acadêmicos e médicos;

- Transformar seus participantes em líderes em saúde ao debater promoção de saúde, educação médica, humanização, mobilidade estudantil, criticidade e representatividade;

### O que são?

Espaços de discussão e reuniões entre Comitês Locais, Diretoria Executiva, Alumni e Observadores Externos de regionais da IFMSA Brazil num evento organizado pelo Coordenador Regional, em parceria com os assistentes dos Times Nacionais.

### Quais são as vantagens de participar?

Treinamentos, apresentação de trabalhos e pesquisa, sessões dinâmicas de aprendizado nos nossos eixos temáticos, representatividade, networking.

### Quando acontecem?

Anualmente.

### Quem pode ir?

Estudantes e médicos que se sintam representados pela IFMSA Brazil pertencentes a cada regional.

### Como participar?

Os nossos filiados recebem o convite para as Assembleias Regionais através de e-mail. Para mais informações, entre em contato com a sua escola médica filiada ou então através de atendimento@ifmsabrazil.org para mais informações.

## Workshops:

Os workshops são uma imersão no universo do Capacity Building da IFMSA Brazil, onde os participantes entram em uma vivência intensa de capacitações. Os eventos podem ser para formação de treinadores em habilidades básicas, ou especializados em temáticas específicas que envolvem os comitês permanentes de atividades da Federação.

Alguns dos workshops da IFMSA que são realizados na IFMSA Brazil que formam treinadores:

- Training New Trainers (TNT)*
- Training Medical Education Trainers (TMET)*
- Training New Human Rights Trainers (TNHRT)*
- Public Health Leadership Training (PHLT)*
- International Peer Education Training (Ipet)*
- Women’s Reproductive Health and Access to Safe Abortion Training (Ipas)*

A IFMSA Brazil por sua vez desenvolveu um workshop na temática de publicação, pesquisa & extensão, na qual os Diretores Nacionais de Capacity Building e Publicação e Pesquisa trabalham juntos para estimular o crescimento do eixo entre os coordenadores locais.

- Training New Research Trainers (TNRT) 

Existem workshops que servem apenas para capacitar os coordenadores locais, não sendo capazes de formar treinadores. Isso porque o conhecimento passado não é capaz de formar ou muitas vezes sendo um evento apenas de reciclagem de treinadores.

- Professional and Research Exchange Training (PRET)
- Training Advanced Trainers (TAT)
- Training Old Trainers (TOT)
- Simulação da OMS

Os eventos acima contam com 24 horas de treinamentos, divididas em 3 dias. Suas agendas variam de acordo com a temática do evento e organização dos treinadores selecionados para facilitarem o evento.


`})]});export{O as default};
