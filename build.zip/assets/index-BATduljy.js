const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/MarkdownPage-MCRVW7dk.js","assets/react-DaPl5ws4.js","assets/@babel-CNkBngnk.js","assets/markdown-to-jsx-CXBEPAoT.js","assets/axios-B4uVmeYG.js","assets/prismjs-DEnDlMkx.js","assets/@mui-D3p2DSY1.js","assets/clsx-B-dksMZM.js","assets/react-is-DcfIKM1A.js","assets/@emotion-Clztb9Oy.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/react-transition-group-cLDJx4Bm.js","assets/react-dom-CWF6clnO.js","assets/scheduler-CzFDRTuY.js","assets/react-router-B_WJkAv4.js","assets/@remix-run-B-RBrVrq.js","assets/react-router-dom-BFBG7k2k.js","assets/styled-components-BD7m8TR7.js","assets/tslib-wbdO-F7s.js","assets/@fortawesome-BOOXKGIM.js","assets/prop-types-15ULSoSZ.js","assets/js-cookie-Cz0CWeBA.js","assets/react-icons-BQxfTaxZ.js","assets/date-fns-X50TK9oK.js","assets/codeStyles-vPv1o2UF.css","assets/GeradorLink-BvzLFz8y.js","assets/Arquivos-D1rfPR0B.js","assets/BlogPostListItem-BhqIjVzk.js","assets/Estrutura-O8YR7pw2.js","assets/react-multi-carousel-BYLf87Xc.js","assets/react-multi-carousel-C0HCKJ4u.css","assets/react-simple-maps-s3X3tYH8.js","assets/topojson-client-DzWSY_RA.js","assets/d3-geo-eEO7UCrt.js","assets/d3-array-BweefaKS.js","assets/MarkdownContent-Bk-obxsC.js","assets/Filiacao-ZS9DwNgG.js","assets/papaparse-RALpPLFu.js","assets/NotFound-DHFLx8nU.js","assets/Noticias-chHlra7O.js","assets/Institucional-BDK1t-OM.js","assets/AcoesETematicas-DTRC3E8o.js","assets/SocialPrograms-CFT5LM88.js","assets/Eixos-DSabklUb.js","assets/Eventos-JxRDzJIB.js","assets/Regulamento-B2PUvoij.js","assets/IntercambioNacional--hY0w_YM.js"])))=>i.map(i=>d[i]);
import{r as l,j as n,a as ue}from"./react-DaPl5ws4.js";import{c as ge}from"./react-dom-CWF6clnO.js";import{L as m,B as fe}from"./react-router-dom-BFBG7k2k.js";import{p as r,h as be,f as Yn}from"./styled-components-BD7m8TR7.js";import{l as D,f as Xn,a as Jn,F as k,b as je,c as ve,d as we,e as ye,g as _e,h as Kn,i as Zn,j as ne,k as ee,m as te,n as oe,o as ie}from"./@fortawesome-BOOXKGIM.js";import{j as ke,a as Ce,G as Oe}from"./@emotion-Clztb9Oy.js";import{s as z,I as Se,C as H,G as E,T as j,a as Ee,b as ze,c as Me,d as Ie,e as Pe,f as Ae,g as Fe}from"./@mui-D3p2DSY1.js";import{a as Le}from"./axios-B4uVmeYG.js";import{a as W}from"./js-cookie-Cz0CWeBA.js";import{F as $e,a as Y,b as Be,c as Te}from"./react-icons-BQxfTaxZ.js";import{i as Re,p as X}from"./date-fns-X50TK9oK.js";import{d as qe,e as g}from"./react-router-B_WJkAv4.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./@remix-run-B-RBrVrq.js";import"./tslib-wbdO-F7s.js";import"./prop-types-15ULSoSZ.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";(function(){const i=document.createElement("link").relList;if(i&&i.supports&&i.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))d(e);new MutationObserver(e=>{for(const s of e)if(s.type==="childList")for(const c of s.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&d(c)}).observe(document,{childList:!0,subtree:!0});function a(e){const s={};return e.integrity&&(s.integrity=e.integrity),e.referrerPolicy&&(s.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?s.credentials="include":e.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function d(e){if(e.ep)return;e.ep=!0;const s=a(e);fetch(e.href,s)}})();const De="modulepreload",He=function(o){return"/"+o},J={},b=function(i,a,d){let e=Promise.resolve();if(a&&a.length>0){document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),c=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));e=Promise.all(a.map(p=>{if(p=He(p),p in J)return;J[p]=!0;const h=p.endsWith(".css"),v=h?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${p}"]${v}`))return;const u=document.createElement("link");if(u.rel=h?"stylesheet":De,h||(u.as="script",u.crossOrigin=""),u.href=p,c&&u.setAttribute("nonce",c),document.head.appendChild(u),h)return new Promise((C,w)=>{u.addEventListener("load",C),u.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${p}`)))})}))}return e.then(()=>i()).catch(s=>{const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=s,window.dispatchEvent(c),!c.defaultPrevented)throw s})};function t(o,i){return i||(i=o.slice(0)),Object.freeze(Object.defineProperties(o,{raw:{value:Object.freeze(i)}}))}const Ne="/assets/logo-fundo-azul-CVrwm-yG.png";var K,Z,nn,en,tn,on,rn,sn,an,ln,cn,dn;D.add(Xn.faBars,Jn.faTimes);const Ve=r.nav(K||(K=t([`
  background: #00508c;
  padding: 0.5rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  z-index: 10;
`]))),Ue=r.img(Z||(Z=t([`
  height: 50px;
`]))),Ge=r.div(nn||(nn=t([`
  display: flex;
  align-items: center;

  @media screen and (max-width: 1040px) {
    display: none;
  }
`]))),S=r.div(en||(en=t([`
  position: relative;
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 0 1rem;
  cursor: pointer;
  transition: color 0.3s;
  white-space: nowrap;

  &:hover {
    color: #fac800;
  }

  @media screen and (max-width: 1200px) {
    font-size: 1rem;
  }

  & > a {
    color: inherit;
    text-decoration: none;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`]))),I=r.div(tn||(tn=t([`
  display: `,`;
  position: absolute;
  top: 100%;
  left: 0;
  background: #00508c;
  padding: 1rem;
  border-radius: 5px;
  z-index: 20;

  & a {
    display: block;
    color: white;
    margin: 0.5rem 0;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`])),o=>{let{$isOpen:i}=o;return i?"block":"none"}),Qe=r(m)(on||(on=t([`
  background: #28a745;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  margin-left: 1rem;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #218838;
  }
`]))),We=r.div(rn||(rn=t([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: block;
    color: white;
    font-size: 1.8rem;
    cursor: pointer;
    z-index: 11; /* Ensure it is above the mobile menu */
  }
`]))),Ye=r.div(sn||(sn=t([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: `,`;
    flex-direction: column;
    align-items: center;
    position: absolute;
    top: 70px;
    left: 0;
    width: 100%;
    background: #00508c;
    padding: 1rem 0;
    z-index: 9;
  }
`])),o=>{let{$isOpen:i}=o;return i?"flex":"none"}),P=r.div(an||(an=t([`
  width: 100%;
  text-align: center;
`]))),_=r(m)(ln||(ln=t([`
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 1rem 0;
  cursor: pointer;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),x=r(m)(cn||(cn=t([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),T=r.div(dn||(dn=t([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),Xe=()=>{const[o,i]=l.useState(!1),[a,d]=l.useState(""),e=()=>{o==!0&&d(""),i(!o)},s=c=>{d(a===c?"":c)};return n.jsxs(Ve,{children:[n.jsx(m,{to:"/",children:n.jsx(Ue,{src:Ne,alt:"Logo"})}),n.jsx(We,{onClick:e,children:n.jsx(k,{icon:o?Jn.faTimes:Xn.faBars})}),n.jsxs(Ge,{children:[n.jsxs(S,{onMouseEnter:()=>d("quemSomos"),onMouseLeave:()=>d(""),onClick:()=>s("quemSomosMobile"),children:["Quem Somos",n.jsxs(I,{$isOpen:a==="quemSomos"||a==="quemSomosMobile",children:[n.jsx(m,{to:"/institucional",children:"Institucional"}),n.jsx(m,{to:"/estrutura",children:"Estrutura"}),n.jsx(m,{to:"/filiacao",children:"Filiação"}),n.jsx(m,{to:"/memoria",children:"Memória Institucional"})]})]}),n.jsxs(S,{onMouseEnter:()=>d("oQueFazemos"),onMouseLeave:()=>d(""),onClick:()=>s("oQueFazemosMobile"),children:["O Que Fazemos",n.jsxs(I,{$isOpen:a==="oQueFazemos"||a==="oQueFazemosMobile",children:[n.jsx(m,{to:"/eixos",children:"Eixos de Atuação"}),n.jsx(m,{to:"/acoes",children:"Ações e Temáticas"}),n.jsx(m,{to:"/eventos",children:"Eventos e Workshops"})]})]}),n.jsxs(S,{onMouseEnter:()=>d("mobilidade"),onMouseLeave:()=>d(""),onClick:()=>s("mobilidadeMobile"),children:["Intercâmbios",n.jsxs(I,{$isOpen:a==="mobilidade"||a==="mobilidadeMobile",children:[n.jsx(m,{to:"/intercambio_nacional",children:"Intercâmbios Nacionais"}),n.jsx(m,{to:"/intercambio_internacional",children:"Intercâmbios Internacionais"}),n.jsx(m,{to:"/regulamento",children:"Regulamento de Intercâmbios"}),n.jsx(m,{to:"/outras-modalidades",children:"Outras Modalidades de Intercâmbio"}),n.jsx(m,{to:"/social-programs",children:"Social Programs"})]})]}),n.jsxs(S,{onMouseEnter:()=>d("midias"),onMouseLeave:()=>d(""),onClick:()=>s("midiasMobile"),children:["Mídias e Documentos",n.jsxs(I,{$isOpen:a==="midias"||a==="midiasMobile",children:[n.jsx(m,{to:"/arquivos/ressonancia-poetica",children:"Ressonância Poética"}),n.jsx(m,{to:"/arquivos/informa-susi",children:"Informa SUSi"}),n.jsx(m,{to:"/arquivos/bms",children:"Brazilian Medical Students"}),n.jsx(m,{to:"/arquivos/relatorios",children:"Relatórios"}),n.jsx(m,{to:"/arquivos/notas-de-posicionamento",children:"Notas de Posicionamento"}),n.jsx(m,{to:"/arquivos/declaracoes-de-politica",children:"Declarações de Política"}),n.jsx(m,{to:"/arquivos/intercambio-nacional",children:"Intercâmbio Nacional"}),n.jsx(m,{to:"/arquivos/intercambio-internacional",children:"Intercâmbio Internacional"}),n.jsx(m,{to:"/arquivos/regulamento-intercambios",children:"Regulamento de Intercâmbios"})]})]}),n.jsx(S,{children:n.jsx(m,{to:"/noticias",children:"Notícias"})}),n.jsxs(S,{onMouseEnter:()=>d("membros"),onMouseLeave:()=>d(""),onClick:()=>s("membrosMobile"),children:["Membros",n.jsxs(I,{$isOpen:a==="membros"||a==="membrosMobile",children:[n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"}),n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"}),n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})]})]}),n.jsx(Qe,{to:"/filie-se",children:"FILIE-SE"})]}),n.jsxs(Ye,{$isOpen:o,children:[n.jsxs(P,{children:[n.jsx(_,{onClick:()=>s("quemSomosMobile"),children:"Quem Somos"}),a==="quemSomosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/institucional",onClick:e,children:"Institucional"}),n.jsx(x,{to:"/estrutura",onClick:e,children:"Estrutura"}),n.jsx(x,{to:"/filiacao",onClick:e,children:"Filiação"}),n.jsx(x,{to:"/memoria",onClick:e,children:"Memória Institucional"})]})]}),n.jsxs(P,{children:[n.jsx(_,{onClick:()=>s("oQueFazemosMobile"),children:"O Que Fazemos"}),a==="oQueFazemosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/eixos",onClick:e,children:"Eixos de Atuação"}),n.jsx(x,{to:"/acoes",onClick:e,children:"Ações e Temáticas"}),n.jsx(x,{to:"/eventos",onClick:e,children:"Eventos e Workshops"})]})]}),n.jsxs(P,{children:[n.jsx(_,{onClick:()=>s("mobilidadeMobile"),children:"Intercâmbios"}),a==="mobilidadeMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/intercambio_nacional",onClick:e,children:"Intercâmbios Nacionais"}),n.jsx(x,{to:"/intercambio_internacional",onClick:e,children:"Intercâmbios Internacionais"}),n.jsx(x,{to:"/regulamento",onClick:e,children:"Regulamento de Intercâmbios"}),n.jsx(x,{to:"/outras-modalidades",onClick:e,children:"Outras Modalidades de Intercâmbio"}),n.jsx(x,{to:"/social-programs",onClick:e,children:"Social Programs"})]})]}),n.jsxs(P,{children:[n.jsx(_,{onClick:()=>s("midiasMobile"),children:"Mídias e Documentos"}),a==="midiasMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(x,{to:"/arquivos/ressonancia-poetica",onClick:e,children:"Ressonância Poética"}),n.jsx(x,{to:"/arquivos/informa-susi",onClick:e,children:"Informa SUSi"}),n.jsx(x,{to:"/arquivos/bms",onClick:e,children:"Brazilian Medical Students"}),n.jsx(x,{to:"/arquivos/relatorios",onClick:e,children:"Relatórios"}),n.jsx(x,{to:"/arquivos/notas-de-posicionamento",onClick:e,children:"Notas de Posicionamento"}),n.jsx(x,{to:"/arquivos/declaracoes-de-politica",onClick:e,children:"Declarações de Política"}),n.jsx(x,{to:"/arquivos/intercambio-nacional",onClick:e,children:"Intercâmbio Nacional"}),n.jsx(x,{to:"/arquivos/intercambio-internacional",onClick:e,children:"Intercâmbio Internacional"}),n.jsx(x,{to:"/arquivos/regulamento-intercambios",onClick:e,children:"Regulamento de Intercâmbios"})]})]}),n.jsx(_,{to:"/noticias",onClick:e,children:"Notícias"}),n.jsxs(P,{children:[n.jsx(_,{onClick:()=>s("membrosMobile"),children:"Membros"}),a==="membrosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(T,{onClick:e,children:n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"})}),n.jsx(T,{onClick:e,children:n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"})}),n.jsx(T,{onClick:e,children:n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})})]})]}),n.jsx(_,{to:"/filie-se",onClick:e,children:"FILIE-SE"})]})]})};var mn;const Je=()=>ke(Oe,{styles:Ce(mn||(mn=t([`
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap");

      html,
      body,
      body1,
      #root,
      #__next {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif !important;
        background-color: #f0f0f0;
        color: rgba(0, 0, 0, 0.87);
        font-weight: 400;
        font-size: 1rem;
        line-height: 1.5;
        letter-spacing: 0.00938em;
      }

      *,
      *::before,
      *::after {
        box-sizing: inherit;
      }

      a {
        text-decoration: none;
        color: inherit;
      }

      h1,
      h6,
      h2 {
        margin: 0;
      }

      button {
        outline: none;
      }

      .carousel-container {
        max-width: 1200px;
        margin: 0 auto;
      }

      .carousel .slide {
        background: none;
      }

      /* CSS for BrazilMap component */
      .container {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: flex-start;
        width: 100%;
        margin: 0;
        padding: 20px;
        box-sizing: border-box;
      }

      .map-container {
        flex: 1;
        min-width: 300px;
        max-width: 600px;
        margin: 0 20px; /* Medium margin on the left and right sides */
      }

      .legend-container {
        display: flex;
        flex-direction: column;
        margin-left: 20px;
      }

      .legend-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
      }

      .color-box {
        width: 20px;
        height: 20px;
        margin-right: 10px;
      }

      /* Media query for mobile view */
      @media (max-width: 768px) {
        .container {
          flex-direction: column;
          align-items: center;
        }
        .map-container {
          margin: 0; /* Remove margins on mobile */
        }
        .legend-container {
          flex-direction: row;
          flex-wrap: wrap;
          justify-content: center;
          margin-left: 0;
          margin-top: 20px; /* Space between map and legend */
        }
        .legend-item {
          margin: 5px; /* Adjust margin for horizontal layout */
        }
      }
    `])))});var pn;be(pn||(pn=t([`
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');

  body {
    font-family: 'Poppins', sans-serif;
  }
`])));D.add(je.faTwitter,ve.faInstagram,we.faMapMarkerAlt,ye.faEnvelope,_e.faPhone);const Ke=z("footer")({backgroundColor:"#00508C",color:"white",padding:"20px 0",textAlign:"center"}),R=z("div")({display:"flex",alignItems:"center",margin:"5px 0",justifyContent:"center","& svg":{marginRight:"10px"}}),Ze=z("div")({marginTop:"10px"}),xn=z(Se)({color:"white",margin:"0 10px",fontSize:"1.5rem",transition:"color 0.3s","&:hover":{color:"#FAC800"}}),nt=()=>n.jsx(Ke,{children:n.jsx(H,{maxWidth:"lg",children:n.jsxs(E,{container:!0,spacing:4,children:[n.jsxs(E,{item:!0,xs:12,md:4,children:[n.jsx(j,{variant:"h6",gutterBottom:!0,children:"Endereço"}),n.jsxs(R,{children:[n.jsx(k,{icon:"map-marker-alt"}),n.jsx(j,{variant:"body1",children:"Avenida Paulista nº 1765 - 7º Andar"})]}),n.jsx(j,{variant:"body1",children:"Boa Vista, São Paulo/SP - Brasil"})]}),n.jsxs(E,{item:!0,xs:12,md:4,children:[n.jsx(j,{variant:"h6",gutterBottom:!0,children:"Contato"}),n.jsxs(R,{children:[n.jsx(k,{icon:"envelope"}),n.jsx(j,{variant:"body1",children:"atendimento@ifmsabrazil.org"})]}),n.jsxs(R,{children:[n.jsx(k,{icon:"phone"}),n.jsx(j,{variant:"body1",children:"Tel: + 55 11 3170-3251"})]})]}),n.jsxs(E,{item:!0,xs:12,md:4,children:[n.jsx(j,{variant:"h6",gutterBottom:!0,children:"Siga-nos"}),n.jsxs(Ze,{children:[n.jsx(xn,{href:"https://twitter.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(k,{icon:["fab","twitter"]})}),n.jsx(xn,{href:"https://instagram.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(k,{icon:["fab","instagram"]})})]})]})]})})}),et=z(H)({display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh"}),tt=z(j)({marginTop:"16px",color:"#00508C"}),re=()=>n.jsxs(et,{children:[n.jsx(Ee,{}),n.jsx(tt,{variant:"h6",children:"Carregando..."})]});var hn,un,gn,fn,bn,jn;const ot=Yn(hn||(hn=t([`
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
`]))),it=Yn(un||(un=t([`
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.8);
  }
`]))),rt=r.div(gn||(gn=t([`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #00508c;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  cursor: pointer;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease-in-out;
  z-index: 1000;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 46px;
    height: 46px;
  }
`]))),st=r.div(fn||(fn=t([`
  position: absolute;
  top: -1px;
  right: -1px;
  background-color: #00963c;
  font-weight: bold;
  color: white;
  border-radius: 50%;
  width: 16px;
  height: 16px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 10px;
`]))),at=r.div(bn||(bn=t([`
  position: fixed;
  bottom: 80px;
  right: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 1000;
  transition: all 0.2s ease-in-out;
  animation: `,` 0.2s forwards;

  @media (max-width: 768px) {
    bottom: 76px;
    right: 16px;
  }
`])),o=>o.isOpen?ot:it),q=r.a(jn||(jn=t([`
  color: #00508c;
  text-decoration: none;
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 8px 0;
  width: 100%;
  transition: all 0.2s ease-in-out;

  &:hover {
    color: #003366;
  }

  svg {
    margin-right: 10px;
  }
`]))),lt=o=>{let{showNotification:i,onAlertReopen:a}=o;const[d,e]=l.useState(!1),s=()=>{a(),c()},c=()=>{e(!d)};return n.jsxs(n.Fragment,{children:[n.jsxs(rt,{onClick:c,children:[d?n.jsx($e,{size:24}):n.jsx(Y,{size:24}),i&&!d&&n.jsx(st,{children:"1"})]}),d&&n.jsxs(at,{isOpen:d,children:[n.jsxs(q,{href:"mailto:atendimento@ifmsabrazil.org",children:[n.jsx(Y,{size:20}),"atendimento@ifmsabrazil.org"]}),n.jsxs(q,{href:"https://instagram.com/ifmsabrazil",target:"_blank",children:[n.jsx(Be,{size:20}),"@ifmsabrazil"]}),i&&n.jsxs(q,{onClick:s,children:[n.jsx(Te,{size:20}),"Ver aviso novamente"]})]})]})};var vn,wn,yn,_n,kn,Cn;const ct=r.section(vn||(vn=t([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #FFFFFF;
  text-align: center;
`]))),dt=r.h2(wn||(wn=t([`
  font-family: 'Poppins', sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),mt=r.div(yn||(yn=t([`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
`]))),pt=r.div(_n||(_n=t([`
  flex: 1 1 30%;
  max-width: 30%;
  display: flex;
  justify-content: center;

  @media (max-width: 991px) {
    flex: 1 1 45%;
    max-width: 45%;
  }

  @media (max-width: 600px) {
    flex: 1 1 100%;
    max-width: 100%;
  }
`]))),xt=r.div(kn||(kn=t([`
  position: relative;
  height: auto;
  font-family: 'Poppins', sans-serif;
  color: rgba(255, 255, 255, 1);
  text-align: center;
  background-color: `,`;
  flex-grow: 1;
  width: 100%;
  align-self: stretch;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`])),o=>o.bgColor),ht=r.div(Cn||(Cn=t([`
  font-size: 24px;
`])));function ut(){const o=[{id:1,bgColor:"rgba(0, 80, 140, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Em 26 Estados"}),n.jsx("br",{}),n.jsx("strong",{children:"+ Distrito Federal"})]})},{id:2,bgColor:"rgba(250, 200, 0, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Temos +11000"}),n.jsx("br",{}),n.jsx("strong",{children:"membros filiados"})]})},{id:3,bgColor:"rgba(0, 150, 60, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Presentes em +220"}),n.jsx("br",{}),n.jsx("strong",{children:"escolas médicas"})]})}];return n.jsxs(ct,{children:[n.jsx(dt,{children:"Nossa abrangência"}),n.jsx(mt,{children:o.map(i=>n.jsx(pt,{children:n.jsx(xt,{bgColor:i.bgColor,children:n.jsx(ht,{children:i.text})})},i.id))})]})}var On,Sn,En,zn,Mn;D.add(Kn.faBook,Zn.faGraduationCap,ne.faHandsHelping,ee.faHeartbeat,te.faHospital,oe.faUniversity,ie.faSearch);const gt=r.section(On||(On=t([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
  text-align: center;
`]))),ft=r.h2(Sn||(Sn=t([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),bt=r.div(En||(En=t([`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 20px;
  justify-content: center;

  @media (max-width: 991px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    & > :nth-child(5) {
      grid-column: span 2;
    }
  }
`]))),jt=r.div(zn||(zn=t([`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: `,`;
  color: `,`;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
  font-family: "Poppins", sans-serif;
  text-align: center;
  border: `,`;

  &:hover {
    transform: translateY(-10px);
  }
`])),o=>o.bgColor,o=>o.color||"rgba(255, 255, 255, 1)",o=>o.border||"none"),vt=r.div(Mn||(Mn=t([`
  font-size: 18px;
  margin-top: 10px;
`])));function wt(){const o=[{id:1,bgColor:"rgba(182, 120, 38, 1)",text:"Representatividade estudantil",icon:Zn.faGraduationCap},{id:2,bgColor:"rgba(0, 0, 0, 1)",text:"Capacity Building",icon:Kn.faBook},{id:3,bgColor:"#FFFFFF",text:"Educação Médica",icon:te.faHospital,color:"#000",border:"2px solid #000"},{id:4,bgColor:"rgba(220, 0, 0, 1)",text:"Promoção de Saúde",icon:ee.faHeartbeat},{id:5,bgColor:"rgba(0, 150, 60, 1)",text:"Humanização",icon:ne.faHandsHelping},{id:6,bgColor:"rgba(0, 80, 140, 1)",text:"Mobilidade Estudantil",icon:oe.faUniversity},{id:7,bgColor:"rgba(128, 128, 128, 1)",text:"Pesquisa e Extensão",icon:ie.faSearch}];return n.jsxs(gt,{children:[n.jsx(ft,{children:"Nossos eixos de atuação"}),n.jsx(bt,{children:o.map(i=>n.jsxs(jt,{bgColor:i.bgColor,color:i.color,border:i.border,children:[n.jsx(k,{icon:i.icon,size:"3x"}),n.jsx(vt,{children:i.text})]},i.id))})]})}var In,Pn;const yt=r(ze)(In||(In=t([`
  display: flex;
  flex-direction: column;
  margin: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
  border-radius: 10px;

  &:hover {
    transform: translateY(-5px);
  }

  @media (min-width: 600px) {
    flex-direction: row;
  }
`]))),_t=r(Me)(Pn||(Pn=t([`
  width: 100%;
  height: auto;

  @media (min-width: 600px) {
    width: 160px !important;
    height: auto;
    object-fit: cover;
    margin-left: auto;
  }
`]))),kt=o=>{let{post:i}=o;return n.jsxs(yt,{children:[n.jsxs(Ie,{style:{flex:1},children:[n.jsx(j,{component:"h2",variant:"h5",gutterBottom:!0,children:i.title}),n.jsx(j,{variant:"subtitle1",color:"text.secondary",children:i.author}),n.jsx(j,{variant:"subtitle2",color:"text.secondary",gutterBottom:!0,children:i.date?new Date(i.date).toLocaleDateString():""}),n.jsx(j,{variant:"body1",paragraph:!0,children:i.summary})]}),n.jsx(_t,{component:"img",image:i.imageLink,alt:"Blog image"})]})},Ct={ç:"c",Ç:"C",á:"a",Á:"A",é:"e",É:"E",í:"i",Í:"I",ó:"o",Ó:"O",ú:"u",Ú:"U",à:"a",À:"A",ã:"a",Ã:"A",õ:"o",Õ:"O"},Ot=o=>o.split("").map(i=>Ct[i]||i).join(""),St=o=>Ot(o).toLowerCase().replace(/[^a-z0-9]+/g,"-");var An,Fn;const Et=r.section(An||(An=t([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
`]))),zt=r.h2(Fn||(Fn=t([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Mt=o=>{let{posts:i,loading:a}=o;if(a)return n.jsx(re,{});const d=c=>c.sort((p,h)=>h["dia-mes-ano"]-p["dia-mes-ano"]),s=function(c){let p=arguments.length>1&&arguments[1]!==void 0?arguments[1]:4;const h=d(c),v=h.filter(w=>w["forcar-pagina-inicial"]);if(v.length>=p)return v;const u=h.filter(w=>!w["forcar-pagina-inicial"]);return v.concat(u.slice(0,p-v.length))}(i);return n.jsxs(Et,{children:[n.jsx(zt,{children:"Últimas Notícias"}),n.jsx(H,{maxWidth:"lg",children:n.jsx(E,{container:!0,spacing:4,children:s.map((c,p)=>n.jsx(E,{item:!0,xs:12,sm:6,children:n.jsx(m,{to:"/arquivo/".concat(c.id,"/").concat(St(c.title)),children:n.jsx(kt,{post:c})})},p))})})]})},It="/assets/background-image-YkmHsWZG.webp";var Ln,$n,Bn,Tn,Rn,qn,Dn;function Pt(o){let{message:i,title:a,buttonUrl:d,buttonText:e,toggleButton:s,toggleMessage:c,onClose:p,forceOpen:h,isOpen:v,setIsOpen:u}=o;l.useEffect(()=>{h&&u(!0)},[h]);const C=()=>{p&&p()};return!v&&!h?null:n.jsx(Ft,{children:n.jsxs(Lt,{children:[n.jsxs($t,{onClick:C,children:[n.jsx(At,{}),n.jsx("span",{className:"sr-only",children:"Close"})]}),n.jsxs(Bt,{children:[n.jsx(Tt,{children:a}),c?n.jsx(Rt,{children:i}):null,s?n.jsx(m,{to:d,target:"_blank",rel:"noopener noreferrer",children:n.jsx(qt,{children:e})}):null]})]})})}function At(o){return n.jsxs("svg",{...o,xmlns:"http://www.w3.org/2000/svg",width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round",children:[n.jsx("path",{d:"M18 6 6 18"}),n.jsx("path",{d:"m6 6 12 12"})]})}const Ft=r.div(Ln||(Ln=t([`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`]))),Lt=r.div($n||($n=t([`
  background-color: hsl(142, 86%, 28%);
  padding: 2rem 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  max-width: 42rem;
  position: relative;
`]))),$t=r.button(Bn||(Bn=t([`
  position: absolute;
  top: 1rem;
  right: 1rem;
  color: hsl(356, 29%, 98%);
  background: none;
  border: none;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 0.25rem;

  &:hover {
    color: rgba(356, 29%, 98%, 0.8);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`]))),Bt=r.div(Tn||(Tn=t([`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`]))),Tt=r.h2(Rn||(Rn=t([`
  font-size: 1.875rem;
  font-weight: bold;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1rem;
`]))),Rt=r.p(qn||(qn=t([`
  font-size: 1.125rem;
  color: hsl(356, 29%, 98%);
  margin-bottom: 1.5rem;
`]))),qt=r.a(Dn||(Dn=t([`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.75rem 1.5rem;
  border-radius: 0.25rem;
  background-color: hsl(356, 29%, 98%);
  color: hsl(142, 86%, 28%);
  font-weight: 500;
  text-decoration: none;

  &:hover {
    background-color: rgba(356, 29%, 98%, 0.9);
  }

  &:focus {
    outline: 2px solid hsl(142, 86%, 28%);
    outline-offset: 2px;
  }
`])));var Hn,Nn,Vn,Un,Gn,Qn;const Dt=r.div(Hn||(Hn=t([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  overflow: hidden;
`]))),Ht=r.div(Nn||(Nn=t([`
  width: 100%;
  height: 100vh;
  background-image: url(`,`);
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  text-align: center;
  padding: 20px;
  background-color: rgba(0, 0, 0, 0.5);
`])),It),Nt=r.h1(Vn||(Vn=t([`
  font-size: 3rem;
  font-weight: 700;
  padding: 0 20px;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
`]))),Vt=r.button(Un||(Un=t([`
  margin-top: 20px;
  padding: 12px 24px;
  font-size: 1rem;
  font-weight: bold;
  color: #00508c;
  background-color: #fac800;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: translateY(-3px);
    background-color: #e6b800;
    color: #004080;
  }
`]))),Ut=r.button(Gn||(Gn=t([`
  position: fixed;
  bottom: 20px;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: white;
  border: none;
  cursor: pointer;
  display: `,`;
  justify-content: center;
  align-items: center;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
  }

  svg {
    width: 24px;
    height: 24px;
    fill: #00508c;
  }
`])),o=>{let{show:i}=o;return i?"flex":"none"}),Gt=r.div(Qn||(Qn=t([`
  width: 100%;
  padding: 60px 20px;
  background-color: white;
  text-align: center;
  color: #333;

  h2 {
    font-size: 2rem;
    margin-bottom: 20px;
  }

  p {
    max-width: 800px;
    margin: 0 auto;
    line-height: 1.6;
  }
`]))),Qt=()=>{const[o,i]=l.useState([]),[a,d]=l.useState(null),[e,s]=l.useState(null),[c,p]=l.useState(!1),[h,v]=l.useState(null),u=W.get("alertHash"),[C,w]=l.useState(!0),[se,N]=l.useState(!0),[ae,A]=l.useState(!1),[F,V]=l.useState(!1),le="https://api.ifmsabrazil.org/api/blogs/recent";l.useEffect(()=>{const L=(y,$,f,G,O,xe)=>{const Q="".concat(y).concat($).concat(f).concat(G).concat(O).concat(xe);let M=0;for(let B=0;B<Q.length;B++){const he=Q.charCodeAt(B);M=(M<<5)-M+he,M|=0}return M.toString()};(async()=>{try{const y=await Le.get(le),{recentBlogs:$,alert:f}=y.data;if(i($),f&&f.toggleDate&&Re(new Date,{start:X(f.dateStart),end:X(f.dateEnd)})){const O=L(f.message,f.title,f.buttonUrl,f.buttonText,f.toggleButton,f.toggleMessage);p(u!==O),A(u===O),d(f),v(O),s(f),(!u||u!==O)&&p(!0)}}catch(y){console.error("Error fetching posts:",y)}finally{w(!1)}})()},[]),l.useEffect(()=>{!c&&h&&!F&&W.set("alertHash",h,{expires:7})},[c,h,F]);const U=()=>{const L=window.scrollY,y=window.innerHeight*.7;L<y?N(!0):N(!1)},ce=()=>{window.scrollTo({top:window.innerHeight,behavior:"smooth"})};l.useEffect(()=>(window.addEventListener("scroll",U),()=>{window.removeEventListener("scroll",U)}),[]);const de=()=>{A(!0),p(!1),V(!1)},me=()=>{A(!1),p(!0),d(e),V(!0)};return n.jsxs(Dt,{children:[a&&n.jsx(Pt,{toggleMessage:a.toggleMessage,message:a.message,toggleButton:a.toggleButton,buttonText:a.buttonText,buttonUrl:a.buttonUrl,title:a.title,forceOpen:F,onClose:de,isOpen:c,setIsOpen:p}),n.jsxs(Ht,{children:[n.jsx(Nt,{children:"Estudantes de medicina que fazem a diferença"}),n.jsx(Vt,{children:"Faça parte"}),n.jsx(Ut,{show:se,onClick:ce,children:n.jsx("svg",{viewBox:"0 0 24 24",children:n.jsx("path",{d:"M12 16.5l-7-7 1.41-1.41L12 13.67l5.59-5.58L19 9.5l-7 7z"})})})]}),n.jsxs(Gt,{children:[n.jsx("h2",{children:"Breve Introdução"}),n.jsx("p",{children:"Fundada em 1991 como primeira associação da América Latina vinculada à International Federation of Medical Students’ Association (IFMSA), a IFMSA Brazil interliga estudantes de medicina de todo o país para fazer a diferença na sociedade e na formação médica."})]}),n.jsx(ut,{}),n.jsx(wt,{}),n.jsx(Mt,{posts:o,loading:C}),n.jsx(lt,{showNotification:ae,onAlertReopen:me})]})},Wt=Pe({typography:{fontFamily:"Poppins, Arial, sans-serif"},components:{MuiCssBaseline:{styleOverrides:`
        @font-face {
          font-family: 'Poppins';
          font-style: normal;
          font-display: swap;
          font-weight: 400;
          src: local('Poppins'), local('Poppins-Regular'), url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap') format('woff2');
          unicodeRange: U+0000-00FF; /* Latin characters */
        }
      `}}}),Wn=l.lazy(()=>b(()=>import("./MarkdownPage-MCRVW7dk.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]))),Yt=l.lazy(()=>b(()=>import("./GeradorLink-BvzLFz8y.js"),__vite__mapDeps([25,1,2,6,7,8,9,10,11,12,13]))),Xt=l.lazy(()=>b(()=>import("./Arquivos-D1rfPR0B.js"),__vite__mapDeps([26,1,2,17,18,9,10,4,27,19,20,6,7,8,11,12,13,14,15,16,21,22,23]))),Jt=l.lazy(()=>b(()=>import("./Estrutura-O8YR7pw2.js"),__vite__mapDeps([28,1,2,4,29,30,6,7,8,9,10,11,12,13,31,20,32,33,34,35,3,5,24,16,14,15,17,18,19,21,22,23]))),Kt=l.lazy(()=>b(()=>import("./Filiacao-ZS9DwNgG.js"),__vite__mapDeps([36,1,2,17,18,9,10,22,6,7,8,11,12,13,4,37,35,3,5,24,16,14,15,19,20,21,23]))),Zt=l.lazy(()=>b(()=>import("./NotFound-DHFLx8nU.js"),__vite__mapDeps([38,1,2,17,18,9,10,16,12,13,14,15,19,20,6,7,8,11,4,21,22,23]))),no=l.lazy(()=>b(()=>import("./Noticias-chHlra7O.js"),__vite__mapDeps([39,1,2,17,18,9,10,16,12,13,14,15,27,19,20,6,7,8,11,4,21,22,23]))),eo=l.lazy(()=>b(()=>import("./Institucional-BDK1t-OM.js"),__vite__mapDeps([40,1,2,35,3,5,6,7,8,9,10,11,12,13,24,16,14,15,17,18,19,20,4,21,22,23]))),to=l.lazy(()=>b(()=>import("./AcoesETematicas-DTRC3E8o.js"),__vite__mapDeps([41,1,2,35,3,5,6,7,8,9,10,11,12,13,24,16,14,15,17,18,19,20,4,21,22,23]))),oo=l.lazy(()=>b(()=>import("./SocialPrograms-CFT5LM88.js"),__vite__mapDeps([42,1,2,35,3,5,6,7,8,9,10,11,12,13,24,16,14,15,17,18,19,20,4,21,22,23]))),io=l.lazy(()=>b(()=>import("./Eixos-DSabklUb.js"),__vite__mapDeps([43,1,2,35,3,5,6,7,8,9,10,11,12,13,24,16,14,15,17,18,19,20,4,21,22,23]))),ro=l.lazy(()=>b(()=>import("./Eventos-JxRDzJIB.js"),__vite__mapDeps([44,1,2,35,3,5,6,7,8,9,10,11,12,13,24,16,14,15,17,18,19,20,4,21,22,23]))),so=l.lazy(()=>b(()=>import("./Regulamento-B2PUvoij.js"),__vite__mapDeps([45,1,2,35,3,5,6,7,8,9,10,11,12,13,24]))),ao=l.lazy(()=>b(()=>import("./IntercambioNacional--hY0w_YM.js"),__vite__mapDeps([46,1,2,35,3,5,6,7,8,9,10,11,12,13,24]))),lo=()=>n.jsx(Ae,{theme:Wt,children:n.jsxs(fe,{children:[n.jsx(Je,{}),n.jsx(Fe,{}),n.jsx(Xe,{}),n.jsx(l.Suspense,{fallback:n.jsx(re,{}),children:n.jsxs(qe,{children:[n.jsx(g,{path:"/",element:n.jsx(Qt,{})}),n.jsx(g,{path:"/arquivo/:id/:title",element:n.jsx(Wn,{needsExternal:!0})}),n.jsx(g,{path:"/gerarlink",element:n.jsx(Yt,{})}),n.jsx(g,{path:"/estrutura",element:n.jsx(Jt,{})}),n.jsx(g,{path:"/filiacao",element:n.jsx(Kt,{})}),n.jsx(g,{path:"/noticias",element:n.jsx(no,{})}),n.jsx(g,{path:"/institucional",element:n.jsx(eo,{})}),n.jsx(g,{path:"/acoes",element:n.jsx(to,{})}),n.jsx(g,{path:"/arquivos/:type",element:n.jsx(Xt,{})}),n.jsx(g,{path:"/social-programs",element:n.jsx(oo,{})}),n.jsx(g,{path:"/eixos",element:n.jsx(io,{})}),n.jsx(g,{path:"/eventos",element:n.jsx(ro,{})}),n.jsx(g,{path:"/regulamento",element:n.jsx(so,{})}),n.jsx(g,{path:"/intercambio_nacional",element:n.jsx(ao,{})}),n.jsx(g,{path:"/tutorial",element:n.jsx(Wn,{needsExternal:!1,filepath:"/markdown/pagina.md"})}),n.jsx(g,{path:"*",element:n.jsx(Zt,{})})," "]})}),n.jsx(nt,{})]})}),co=document.getElementById("root"),mo=ge(co);mo.render(n.jsx(ue.StrictMode,{children:n.jsx(lo,{})}));export{re as L,t as _,b as a,St as g};
