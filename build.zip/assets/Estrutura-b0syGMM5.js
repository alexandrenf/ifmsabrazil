import{r as d,j as o}from"./react-CLPtFgDq.js";import{L as h}from"./index-HEFPyKRz.js";import{a as C}from"./axios-B4uVmeYG.js";import{C as u}from"./react-multi-carousel-BkRiOElf.js";import{s as r,C as v,j as b,A,T as l}from"./@mui-B86xCNSa.js";import{C as j,G as S,a as F}from"./react-simple-maps-DEBQupZu.js";import{M as E}from"./MarkdownContent-DFTCqHCR.js";import"./@babel-f5lBRPU2.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-Am9psY4u.js";import"./react-router-BzRFIFMZ.js";import"./@remix-run-YI_hLLil.js";import"./styled-components-BY_vc4YD.js";import"./tslib-wbdO-F7s.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./@fortawesome-B6QlLdFu.js";import"./prop-types-1yzuAbYU.js";import"./webfontloader-DM8E560Z.js";import"./react-icons-CrkDh4zl.js";import"./clsx-B-dksMZM.js";import"./react-transition-group-CLuBo2_z.js";import"./react-is-DcfIKM1A.js";import"./topojson-client-DzWSY_RA.js";import"./d3-geo-eEO7UCrt.js";import"./d3-array-BweefaKS.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */const R=u.default?u.default:u,w=r(v)({paddingLeft:"24px",paddingRight:"24px",paddingTop:"24px",paddingBottom:"24px",backgroundColor:"#FFFFFF",color:"#333",position:"relative"}),y=r(b)({padding:"16px",margin:"8px",backgroundColor:"#f9f9f9",borderRadius:"8px",boxShadow:"0 4px 8px rgba(0, 0, 0, 0.1)",textAlign:"center",transition:"transform 0.3s ease","&:hover":{transform:"scale(1.05)"},display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center",height:"auto",minHeight:"300px",overflow:"hidden"}),D=r(A)({width:"120px",height:"120px",marginBottom:"16px",borderRadius:"12px",boxShadow:"0 4px 10px rgba(0, 0, 0, 0.2)"}),N=r(l)({textOverflow:"ellipsis",overflow:"hidden",whiteSpace:"normal",wordWrap:"break-word",width:"100%",display:"block"}),M=r(l)({color:"#1976d2",marginBottom:"8px",textOverflow:"ellipsis",overflow:"hidden",whiteSpace:"normal",wordWrap:"break-word",width:"100%",display:"block"}),k=r(l)({color:"#333",textOverflow:"ellipsis",overflow:"hidden",whiteSpace:"normal",wordWrap:"break-word",width:"100%",display:"block"}),g=n=>{let{url:c,nameOnPage:s}=n;const[a,t]=d.useState([]),[p,m]=d.useState(!0);if(d.useEffect(()=>{(async()=>{try{const i=await C.get(c);t(i.data)}catch(i){console.error("Error fetching EB members:",i)}finally{m(!1)}})()},[]),p)return o.jsx(h,{});const x={superLargeDesktop:{breakpoint:{max:4e3,min:1024},items:3},desktop:{breakpoint:{max:1024,min:768},items:2},tablet:{breakpoint:{max:768,min:464},items:2},mobile:{breakpoint:{max:464,min:0},items:1}};return o.jsxs(w,{children:[o.jsx(l,{variant:"h4",align:"center",gutterBottom:!0,children:s}),o.jsx(R,{responsive:x,ssr:!0,infinite:!0,autoPlay:!1,autoPlaySpeed:3e3,keyBoardControl:!0,showDots:!1,children:a.map((e,i)=>o.jsxs(y,{children:[o.jsx(D,{src:e.imageLink,alt:e.name}),o.jsx(N,{variant:"h6",children:e.name}),o.jsxs(M,{variant:"body1",children:[e.role," ",e.acronym?"("+e.acronym+")":null]}),o.jsx(k,{variant:"body2",children:e.email})]},i))})]})},f=[{name:"Norte 1",states:["Acre","Rondônia","Amazonas","Roraima"],color:"#1f77b4"},{name:"Norte 2",states:["Pará","Amapá"],color:"#aec7e8"},{name:"Nordeste 1",states:["Maranhão","Piauí","Ceará"],color:"#2ca02c"},{name:"Nordeste 2",states:["Rio Grande do Norte","Paraíba","Pernambuco"],color:"#98df8a"},{name:"Nordeste 3",states:["Alagoas","Sergipe","Bahia"],color:"#ffbb78"},{name:"Leste",states:["Minas Gerais","Espírito Santo","Rio de Janeiro"],color:"#ff7f0e"},{name:"Oeste",states:["Distrito Federal","Tocantins","Goiás","Mato Grosso","Mato Grosso do Sul"],color:"#d62728"},{name:"Paulista",states:["São Paulo"],color:"#9467bd"},{name:"Sul",states:["Paraná","Santa Catarina","Rio Grande do Sul"],color:"#8c564b"}],P=()=>{const[n,c]=d.useState(null);return d.useEffect(()=>{(async()=>{try{const a=await C.get("https://cdn.jsdelivr.net/gh/alexandrenf/ifmsabrazil/src/assets/brazilstates.json");c(a.data)}catch(a){console.error("Error fetching TopoJSON data:",a)}})()},[]),o.jsx("div",{className:"container",children:n?o.jsxs(o.Fragment,{children:[o.jsx("div",{className:"map-container",children:o.jsx(j,{projection:"geoMercator",projectionConfig:{scale:750,center:[-54,-15]},style:{width:"100%",height:"auto"},children:o.jsx(S,{geography:n,children:s=>{let{geographies:a}=s;return a.map(t=>{const p=t.properties.nome,m=f.find(e=>e.states.includes(p)),x=m?m.color:"#EEE";return o.jsx(F,{geography:t,fill:x,style:{default:{outline:"none"},hover:{outline:"none"},pressed:{outline:"none"}}},t.rsmKey)})}})})}),o.jsx("div",{className:"legend-container",children:f.map((s,a)=>o.jsxs("div",{className:"legend-item",children:[o.jsx("div",{className:"color-box",style:{backgroundColor:s.color}}),o.jsx("span",{children:s.name})]},a))})]}):o.jsx(h,{})})},B=r(v)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),O=r(l)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),uo=()=>o.jsxs(B,{children:[o.jsx(O,{variant:"h4",children:"Estrutura da IFMSA Brazil"}),o.jsx(E,{content:`

  ## Nossa Composição

A estrutura da IFMSA Brazil é composta por:

- Diretoria Executiva (EB);
- Coordenadores Regionais (CRs);
- Times Nacionais;
- Coordenadores Nacionais de Programas (CNPs);
- Comitês Locais (LCs) → escolas médicas filiadas;
- Coordenadores Locais (CLs) → estudantes de medicina filiados;
- Alumni;
- Conselho Supervisor (SupCo);
- Comissão de Reforma e Elaboração de Documentos (CRED).

## Diretoria Executiva Nacional

A Diretoria Executiva é composta por 21 cargos a nível nacional, responsável por:

- Captar recursos e finanças;
- Gerir o marketing e relações externas;
- Administrar, desenvolver e apoiar os Comitês Locais;
- Desenvolvimento de atividades centrais em seis principais campos da saúde:
  - Saúde pública;
  - Educação médica;
  - Saúde e direitos sexuais e reprodutivos incluindo HIV e AIDS;
  - Direitos Humanos e Paz;
  - Intercâmbios nacional e internacional clínico-cirúrgicos ou de pesquisa.

`}),o.jsx(g,{url:"https://api.ifmsabrazil.org/api/ebs",nameOnPage:"Diretoria Executiva"}),o.jsx(E,{content:`
## Coordenação Regional

### O que fazem os Coordenadores Regionais?

Os Coordenadores Regionais prestam assistência à Diretoria Executiva em tarefas a nível regional; desenvolve competência de nossos eixos de atuação em Escolas Médicas de cada região; promove oportunidades, como Assembleias Regionais, espaços de representatividade de nossos coordenadores locais.

As Regionais da IFMSA Brazil são: Norte 1 (AC, RO, AM, RR), Norte 2 (PA, AP), Nordeste 1 (MA, PI, CE), Nordeste 2 (RN, PB, PE), Nordeste 3 (AL, SE, BA), Leste (MG, ES, RJ), Oeste (TO, GO, MT, MS), Paulista (SP), Sul (PR, SC, RS).
`}),o.jsx(P,{}),o.jsx(g,{url:"https://api.ifmsabrazil.org/api/crs",nameOnPage:"Coordenadores Regionais"}),o.jsx(E,{content:`
## Times Nacionais

Os Times Nacionais da IFMSA Brazil são divisões de suporte ao trabalho dos Diretores Nacionais e dos Coordenadores Regionais, tendo sua organização interna e funções específicas definidas caso a caso pelo Diretor Nacional responsável e também regionalizadas de acordo com as demandas dos comitês locais.

## Conselho Supervisor

O Conselho Supervisor supervisiona ações e decisões tomadas pela Diretoria Executiva e cria estratégias para garantir imparcialidade e objetividade em investigações internas.

## Conselho de Reforma e Elaboração de Documentos (CRED)

O Conselho de Reforma e Elaboração de Documentos é responsável por revisar documentos internos e promover reuniões com participação de todos os membros para definir alterações nesses documentos.

## Alumni

Os alumni são médicos filiados à IFMSA Brazil que foram Coordenadores Locais (membros de comitês locais) em suas instituições de ensino superior de origem.

### Como me tornar alumni?

É um processo interno que ocorre quando um Coordenador Local pede desfiliação ao Vice-Presidente para Assuntos Internos, declarando interesse em se tornar alumnus ou alumna da IFMSA Brazil. A partir disso, nosso Diretor Nacional de Alumni entrará em contato com o interessado, para que entenda seu novo papel.
`})]});export{uo as default};
