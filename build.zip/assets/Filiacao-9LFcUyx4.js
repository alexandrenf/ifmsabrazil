import{j as e,r as l}from"./react-CLPtFgDq.js";import{_ as i,L as H}from"./index-BsSGgSqj.js";import{p as c}from"./styled-components-BY_vc4YD.js";import{c as W,F as Q}from"./react-icons-CrkDh4zl.js";import{k as J,l as X,m as K,P as Y,n as Z,o as j,p as ee,q as oe,j as ae,f as ne,F as te,g as se,S as re,O as ie,M as C,L as w,s as R,C as ce,T as de}from"./@mui-B86xCNSa.js";import{a as le}from"./axios-B4uVmeYG.js";import{P as me}from"./papaparse-D8JlQIm0.js";import{M as pe}from"./MarkdownContent-DFTCqHCR.js";import"./@babel-f5lBRPU2.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-Am9psY4u.js";import"./react-router-BzRFIFMZ.js";import"./@remix-run-YI_hLLil.js";import"./@fortawesome-B6QlLdFu.js";import"./prop-types-1yzuAbYU.js";import"./webfontloader-DM8E560Z.js";import"./tslib-wbdO-F7s.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./clsx-B-dksMZM.js";import"./react-transition-group-CLuBo2_z.js";import"./react-is-DcfIKM1A.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */var F,P,A,S,L;const xe=c.div(F||(F=i([`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 1000;
  color: white;
`]))),ue=c.div(P||(P=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
`]))),Ee=c(W)(A||(A=i([`
  font-size: 3rem;
  margin-bottom: 10px;
`]))),he=c.p(S||(S=i([`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  margin-bottom: 20px;
`]))),ge=c.button(L||(L=i([`
  background-color: white;
  color: #003366;
  border: none;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;

  &:hover {
    background-color: transparent;
    color: white;
  }
`]))),fe=s=>{let{onClose:t}=s;return e.jsx(xe,{children:e.jsxs(ue,{children:[e.jsx(Ee,{}),e.jsx(he,{children:"Por favor, gire seu dispositivo para o modo paisagem"}),e.jsx(ge,{onClick:t,children:e.jsx(Q,{size:24})})]})})};var M,y,z,T;const be=c(J)(M||(M=i([`
  background-color: #00508c;
  & th {
    color: #fff;
    font-weight: bold;
    white-space: nowrap;
  }
`]))),ve=c(X)(y||(y=i([`
  width: 100%;
  overflow-x: auto;
  position: relative;
`]))),r=c(K)(z||(z=i([`
  min-width: 150px;
`]))),je=c.div(T||(T=i([`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.7);
  z-index: 999;
`]))),Ce=s=>{let{displayedMembers:t,filteredMembersLength:m,page:h,rowsPerPage:n,handleChangePage:g,handleChangeRowsPerPage:f,showPrompt:p,onClosePrompt:u}=s;return e.jsxs(ve,{component:Y,children:[p&&e.jsx(je,{}),p&&e.jsx(fe,{onClose:u}),e.jsxs(Z,{children:[e.jsx(be,{children:e.jsxs(j,{children:[e.jsx(r,{children:"Comitê Local"}),e.jsx(r,{children:"Nome da EM"}),e.jsx(r,{children:"Regional"}),e.jsx(r,{children:"Cidade"}),e.jsx(r,{children:"UF"}),e.jsx(r,{children:"Status"})]})}),e.jsx(ee,{children:t.map((d,E)=>e.jsxs(j,{children:[e.jsx(r,{children:d["Comitê Local"]}),e.jsx(r,{children:d["Nome da EM"]}),e.jsx(r,{children:d.Regional}),e.jsx(r,{children:d.Cidade}),e.jsx(r,{children:d.UF}),e.jsx(r,{children:d.Status})]},E))})]}),e.jsx(oe,{component:"div",count:m,page:h,onPageChange:g,rowsPerPage:n,onRowsPerPageChange:f,rowsPerPageOptions:[10,25,50,100,{label:"Todos",value:m}],labelRowsPerPage:"Itens por página"})]})};var I,O,B;const we=c.h1(I||(I=i([`
  font-family: "Poppins", sans-serif;
  font-size: 1.5rem;
  color: #333;
  text-align: center;
  margin-bottom: 10px;
`]))),Fe=c.section(O||(O=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #fafafa;
`]))),Pe=c(ae)(B||(B=i([`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 1200px;
  flex-wrap: wrap;

  @media (max-width: 768px) {
    flex-direction: column;
    align-items: stretch;
  }
`]))),Ae=s=>{let{members:t}=s;const[m,h]=l.useState(""),[n,g]=l.useState({regional:"",cidade:"",uf:"",status:""}),[f,p]=l.useState([]),[u,d]=l.useState(0),[E,k]=l.useState(10),[q,v]=l.useState(!1);l.useEffect(()=>{const a=()=>{const o=window.innerWidth<=768,x=window.innerHeight>window.innerWidth;v(o&&x)};return window.addEventListener("resize",a),a(),()=>{window.removeEventListener("resize",a)}},[]),l.useEffect(()=>{p(N(t))},[t,m,n]);const D=a=>{h(a.target.value)},_=a=>{const{name:o,value:x}=a.target;g(b=>({...b,[o]:x}))},U=(a,o)=>{d(o)},V=a=>{k(parseInt(a.target.value,10)),d(0)},N=a=>a.filter(o=>{const x=o["Comitê Local"].toLowerCase().includes(m.toLowerCase())||o["Nome da EM"].toLowerCase().includes(m.toLowerCase()),b=(!n.regional||o.Regional===n.regional)&&(!n.cidade||o.Cidade===n.cidade)&&(!n.uf||o.UF===n.uf)&&(!n.status||o.Status===n.status);return x&&b}).sort((o,x)=>o["Comitê Local"].localeCompare(x["Comitê Local"])),$=a=>[...new Set(t.map(o=>o[a]))].sort(),G=f.slice(u*E,u*E+E);return e.jsxs(Fe,{children:[e.jsx(we,{children:"Lista de Comitês Locais Filiados"}),e.jsxs(Pe,{children:[e.jsx(ne,{label:"Buscar",variant:"outlined",value:m,onChange:D,style:{marginBottom:"20px",flexGrow:1}}),["Regional","Cidade","UF","Status"].map(a=>e.jsxs(te,{variant:"outlined",style:{minWidth:200,marginBottom:"20px"},children:[e.jsx(se,{children:a}),e.jsxs(re,{name:a.toLowerCase(),value:n[a.toLowerCase()],onChange:_,input:e.jsx(ie,{label:a}),renderValue:o=>o||"Todos",children:[e.jsx(C,{value:"",children:e.jsx(w,{primary:"Todos"})}),$(a).map(o=>e.jsx(C,{value:o,children:e.jsx(w,{primary:o})},o))]})]},a))]}),e.jsx(Ce,{displayedMembers:G,filteredMembersLength:f.length,page:u,rowsPerPage:E,handleChangePage:U,handleChangeRowsPerPage:V,showPrompt:q,onClosePrompt:()=>v(!1)})]})},Se=R(ce)(s=>{let{theme:t}=s;return{padding:"24px",backgroundColor:"#FFFFFF",color:"#333",[t.breakpoints.down("sm")]:{padding:"16px"}}}),Le=R(de)(s=>{let{theme:t}=s;return{color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center",[t.breakpoints.down("sm")]:{fontSize:"1.5rem"}}}),ao=()=>{const s="https://docs.google.com/spreadsheets/d/1PF7Lqb0jq1ULQBmHzFxOif5UvGwsVLqM2LESq7JVh6c/export?gid=1583477648&format=csv",[t,m]=l.useState([]),[h,n]=l.useState(!0);l.useEffect(()=>{(async()=>{try{const p=await le.get(s),d=me.parse(p.data,{header:!0}).data;m(d)}catch(p){console.error("Error fetching spreadsheet:",p)}finally{n(!1)}})()},[s]);const g=`

## Como posso me filiar à IFMSA Brazil?

Para se filiar, é necessário que sua escola médica tenha um comitê local da IFMSA Brazil e manifestar seu interesse a ele.

## Como eu posso fundar um comitê local?

Basta mandar um e-mail para vpi@ifmsabrazil.org contendo o nome da sua instituição de ensino, demonstrando interesse em fundar um comitê local.
Por lá, podemos começar um processo de filiação.
Confira essa página com atenção para ver as informações sobre a filiação!

## Como funciona o processo de filiação?

### Em cinco etapas!

- **Etapa I:** Você receberá alguns documentos sobre a IFMSA Brazil e será orientado a constituir um grupo de no mínimo 5 pessoas para dar seguimento.
- **Etapa II:** Um contrato de autorização deverá ser assinado pelo coordenador do curso e pelo grupo que foi formado por você juntamente com algumas informações essenciais sobre a faculdade.
- **Etapa III:** Consiste na deliberação da Diretoria Executiva Nacional sobre a viabilidade de, naquele momento, vocês serem filiados
- **Etapa IV:** Vocês serão orientados por Coordenadores Regionais e membros da Diretoria Executiva a realizarem uma atividade de cunho social obedecendo algumas regras e preenchendo as fichas de submissão de atividade.
- **Etapa V:** Ao ser executada cada etapa, um novo processo de avaliação será feito pelos Coordenadores Regionais e Diretoria Executiva e, caso vocês a executem bem, serão convidados a estar conosco em nossa próxima Assembleia Geral para defender a não plenitude da sua faculdade perante a plenária da IFMSA Brazil.

## Como funciona a Assembleia Geral?

É o espaço de deliberação máxima na IFMSA Brazil, onde ocorrem paralelamente sessões, workshops, treinamentos, palestras, entre outros eventos, dentre os quais está a apresentação de sua candidatura à não plenitude.
Caso vocês recebam a carta convite para apresentar a não-plenitude, será necessário no mínimo um representante presente.

## Quanto tempo esse processo demora?

Em média, 1 ano para ser finalizado.
O processo pode durar menos de acordo com cada comitê aspirante.

## Há algum custo para ser filiado?

### Não!

Não há nenhuma taxa de filiação ou taxa para se manter filiado.

O único custo é a ida até a Assembleia Geral, que deve ser custeada pelo grupo fundador. A inscrição no evento inclui alimentação, hospedagem e o evento em si, e outros custos envolvem o transporte até o evento.
Durante o ciclo de capacitações sobre a atividade, vocês irão aprender estratégias para fazer uma atividade financeiramente sustentável, e conseguir patrocínios e parcerias (inclusive com a coordenação do curso), que podem ajudar com esse custo!

## E quanto aos intercâmbios?

Após o processo de não-plenitude, vocês precisarão começar o processo de plenitude que no geral dura cerca de mais um ano após a primeira ida à Assembléia Geral.

## O que é a plenitude?

Um comitê pleno é um comitê considerado capacitado para estabelecimento de direitos plenos dentro da Federação, tendo como base a atuação perante nosso eixos. Tem direito de voz e voto, e pode realizar intercâmbios.
O processo de plenitude envolve comitês bem estruturados, com um contrato de intercâmbio assinado, e vagas declaradas.

## Minha faculdade não tem IFMSA Brazil, posso fazer intercâmbio por vocês?

Não! Apenas alunos de faculdades filiadas podem fazer intercâmbios.

## Quando iremos aprender mais informações sobre a IFMSA Brazil?

Todos os aprovados na etapa III passam por capacitações sobre planejamento de atividades, metodologia de impacto, e outros assuntos pertinentes à filiação.
Após a filiação em si, todos os novos comitês não-plenos passam por um ciclo de capacitações sobre todos os eixos da IFMSA Brazil.


`;return h?e.jsx(H,{}):e.jsxs(Se,{children:[e.jsx(Le,{variant:"h4",children:"Processo de Filiação e Comitês Filiados"}),e.jsx(pe,{content:g}),e.jsx(Ae,{members:t})]})};export{ao as default};
