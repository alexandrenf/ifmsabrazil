const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Alert-Djlsjerp.js","assets/react-DaPl5ws4.js","assets/@babel-CNkBngnk.js","assets/styled-components-CIxqPc4V.js","assets/tslib-wbdO-F7s.js","assets/@emotion-Clztb9Oy.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/react-dom-CWF6clnO.js","assets/scheduler-CzFDRTuY.js","assets/react-router-dom-BFBG7k2k.js","assets/react-router-B_WJkAv4.js","assets/@remix-run-B-RBrVrq.js","assets/@fortawesome-BOOXKGIM.js","assets/prop-types-15ULSoSZ.js","assets/webfontloader-ozkfuRsT.js","assets/@mui-BqBmPETx.js","assets/clsx-B-dksMZM.js","assets/react-is-DcfIKM1A.js","assets/react-transition-group-cLDJx4Bm.js","assets/axios-B4uVmeYG.js","assets/react-icons-vpqwEHyG.js","assets/date-fns-X50TK9oK.js","assets/MarkdownPage-B7NvwP4R.js","assets/markdown-to-jsx-CXBEPAoT.js","assets/prismjs-DEnDlMkx.js","assets/codeStyles-vPv1o2UF.css","assets/GeradorLink-BphYFTKn.js","assets/Arquivos-DMc1UhkL.js","assets/BlogPostListItem-CXyVND0V.js","assets/Estrutura-DIhAc2iX.js","assets/react-multi-carousel-BYLf87Xc.js","assets/react-multi-carousel-C0HCKJ4u.css","assets/react-simple-maps-s3X3tYH8.js","assets/topojson-client-DzWSY_RA.js","assets/d3-geo-eEO7UCrt.js","assets/d3-array-BweefaKS.js","assets/MarkdownContent-CQ6Z632h.js","assets/Filiacao--2vDal1g.js","assets/papaparse-RALpPLFu.js","assets/NotFound-CnTVFUZ8.js","assets/Noticias-D9mPJ9VA.js","assets/Institucional-BTzTCIzJ.js","assets/AcoesETematicas-tV0Ad2dM.js","assets/SocialPrograms-Dzaz0vnC.js","assets/Eixos-Cpb0LW8T.js","assets/Eventos-lljknhGy.js","assets/Regulamento-uE1MojF7.js","assets/IntercambioNacional-cd8j8lRw.js"])))=>i.map(i=>d[i]);
import{r as c,j as n,a as $n}from"./react-DaPl5ws4.js";import{c as Rn}from"./react-dom-CWF6clnO.js";import{L as l,B as qn}from"./react-router-dom-BFBG7k2k.js";import{p as a,f as On}from"./styled-components-CIxqPc4V.js";import{l as A,f as zn,a as Sn,F as w,b as Dn,c as Hn,d as Nn,e as Vn,g as Gn,h as Mn,i as In,j as Pn,k as An,m as Fn,n as Ln,o as Tn}from"./@fortawesome-BOOXKGIM.js";import{j as Un,a as Qn,G as Wn}from"./@emotion-Clztb9Oy.js";import{W as Yn}from"./webfontloader-ozkfuRsT.js";import{s as C,I as Xn,C as F,G as k,T as f,a as Jn,b as Kn,c as Zn,d as ne,e as ee}from"./@mui-BqBmPETx.js";import{a as te}from"./axios-B4uVmeYG.js";import{F as oe,a as L,b as ie}from"./react-icons-vpqwEHyG.js";import{i as re,p as T}from"./date-fns-X50TK9oK.js";import{d as ae,e as h}from"./react-router-B_WJkAv4.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./@remix-run-B-RBrVrq.js";import"./tslib-wbdO-F7s.js";import"./prop-types-15ULSoSZ.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))x(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const d of r.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&x(d)}).observe(document,{childList:!0,subtree:!0});function s(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?r.credentials="include":e.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function x(e){if(e.ep)return;e.ep=!0;const r=s(e);fetch(e.href,r)}})();const se="modulepreload",le=function(t){return"/"+t},B={},u=function(o,s,x){let e=Promise.resolve();if(s&&s.length>0){document.getElementsByTagName("link");const r=document.querySelector("meta[property=csp-nonce]"),d=(r==null?void 0:r.nonce)||(r==null?void 0:r.getAttribute("nonce"));e=Promise.all(s.map(p=>{if(p=le(p),p in B)return;B[p]=!0;const b=p.endsWith(".css"),v=b?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${p}"]${v}`))return;const g=document.createElement("link");if(g.rel=b?"stylesheet":se,b||(g.as="script",g.crossOrigin=""),g.href=p,d&&g.setAttribute("nonce",d),document.head.appendChild(g),b)return new Promise((E,j)=>{g.addEventListener("load",E),g.addEventListener("error",()=>j(new Error(`Unable to preload CSS for ${p}`)))})}))}return e.then(()=>o()).catch(r=>{const d=new Event("vite:preloadError",{cancelable:!0});if(d.payload=r,window.dispatchEvent(d),!d.defaultPrevented)throw r})};function i(t,o){return o||(o=t.slice(0)),Object.freeze(Object.defineProperties(t,{raw:{value:Object.freeze(o)}}))}const ce="/assets/logo-fundo-azul-CVrwm-yG.png";var $,R,q,D,H,N,V,G,U,Q,W,Y;A.add(zn.faBars,Sn.faTimes);const de=a.nav($||($=i([`
  background: #00508c;
  padding: 0.5rem 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  z-index: 10;
`]))),me=a.img(R||(R=i([`
  height: 50px;
`]))),xe=a.div(q||(q=i([`
  display: flex;
  align-items: center;

  @media screen and (max-width: 1040px) {
    display: none;
  }
`]))),y=a.div(D||(D=i([`
  position: relative;
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 0 1rem;
  cursor: pointer;
  transition: color 0.3s;
  white-space: nowrap;

  &:hover {
    color: #fac800;
  }

  @media screen and (max-width: 1200px) {
    font-size: 1rem;
  }

  & > a {
    color: inherit;
    text-decoration: none;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`]))),z=a.div(H||(H=i([`
  display: `,`;
  position: absolute;
  top: 100%;
  left: 0;
  background: #00508c;
  padding: 1rem;
  border-radius: 5px;
  z-index: 20;

  & a {
    display: block;
    color: white;
    margin: 0.5rem 0;
    transition: color 0.3s;

    &:hover {
      color: #fac800;
    }
  }
`])),t=>{let{$isOpen:o}=t;return o?"block":"none"}),pe=a(l)(N||(N=i([`
  background: #28a745;
  color: white;
  font-weight: bold;
  padding: 0.5rem 1rem;
  margin-left: 1rem;
  border-radius: 5px;
  text-align: center;
  cursor: pointer;
  transition: background 0.3s;

  &:hover {
    background: #218838;
  }
`]))),he=a.div(V||(V=i([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: block;
    color: white;
    font-size: 1.8rem;
    cursor: pointer;
    z-index: 11; /* Ensure it is above the mobile menu */
  }
`]))),ue=a.div(G||(G=i([`
  display: none;

  @media screen and (max-width: 1040px) {
    display: `,`;
    flex-direction: column;
    align-items: center;
    position: absolute;
    top: 70px;
    left: 0;
    width: 100%;
    background: #00508c;
    padding: 1rem 0;
    z-index: 9;
  }
`])),t=>{let{$isOpen:o}=t;return o?"flex":"none"}),S=a.div(U||(U=i([`
  width: 100%;
  text-align: center;
`]))),_=a(l)(Q||(Q=i([`
  color: white;
  font-weight: 500;
  font-size: 1.2rem;
  margin: 1rem 0;
  cursor: pointer;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),m=a(l)(W||(W=i([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),I=a.div(Y||(Y=i([`
  display: block;
  color: white;
  margin: 0.5rem 0;
  transition: color 0.3s;

  &:hover {
    color: #fac800;
  }
`]))),ge=()=>{const[t,o]=c.useState(!1),[s,x]=c.useState(""),e=()=>{t==!0&&x(""),o(!t)},r=d=>{x(s===d?"":d)};return n.jsxs(de,{children:[n.jsx(l,{to:"/",children:n.jsx(me,{src:ce,alt:"Logo"})}),n.jsx(he,{onClick:e,children:n.jsx(w,{icon:t?Sn.faTimes:zn.faBars})}),n.jsxs(xe,{children:[n.jsxs(y,{onMouseEnter:()=>x("quemSomos"),onMouseLeave:()=>x(""),onClick:()=>r("quemSomosMobile"),children:["Quem Somos",n.jsxs(z,{$isOpen:s==="quemSomos"||s==="quemSomosMobile",children:[n.jsx(l,{to:"/institucional",children:"Institucional"}),n.jsx(l,{to:"/estrutura",children:"Estrutura"}),n.jsx(l,{to:"/filiacao",children:"Filiação"}),n.jsx(l,{to:"/memoria",children:"Memória Institucional"})]})]}),n.jsxs(y,{onMouseEnter:()=>x("oQueFazemos"),onMouseLeave:()=>x(""),onClick:()=>r("oQueFazemosMobile"),children:["O Que Fazemos",n.jsxs(z,{$isOpen:s==="oQueFazemos"||s==="oQueFazemosMobile",children:[n.jsx(l,{to:"/eixos",children:"Eixos de Atuação"}),n.jsx(l,{to:"/acoes",children:"Ações e Temáticas"}),n.jsx(l,{to:"/eventos",children:"Eventos e Workshops"})]})]}),n.jsxs(y,{onMouseEnter:()=>x("mobilidade"),onMouseLeave:()=>x(""),onClick:()=>r("mobilidadeMobile"),children:["Intercâmbios",n.jsxs(z,{$isOpen:s==="mobilidade"||s==="mobilidadeMobile",children:[n.jsx(l,{to:"/intercambio_nacional",children:"Intercâmbios Nacionais"}),n.jsx(l,{to:"/intercambio_internacional",children:"Intercâmbios Internacionais"}),n.jsx(l,{to:"/regulamento",children:"Regulamento de Intercâmbios"}),n.jsx(l,{to:"/outras-modalidades",children:"Outras Modalidades de Intercâmbio"}),n.jsx(l,{to:"/social-programs",children:"Social Programs"})]})]}),n.jsxs(y,{onMouseEnter:()=>x("midias"),onMouseLeave:()=>x(""),onClick:()=>r("midiasMobile"),children:["Mídias e Documentos",n.jsxs(z,{$isOpen:s==="midias"||s==="midiasMobile",children:[n.jsx(l,{to:"/arquivos/ressonancia-poetica",children:"Ressonância Poética"}),n.jsx(l,{to:"/arquivos/informa-susi",children:"Informa SUSi"}),n.jsx(l,{to:"/arquivos/bms",children:"Brazilian Medical Students"}),n.jsx(l,{to:"/arquivos/relatorios",children:"Relatórios"}),n.jsx(l,{to:"/arquivos/notas-de-posicionamento",children:"Notas de Posicionamento"}),n.jsx(l,{to:"/arquivos/declaracoes-de-politica",children:"Declarações de Política"}),n.jsx(l,{to:"/arquivos/intercambio-nacional",children:"Intercâmbio Nacional"}),n.jsx(l,{to:"/arquivos/intercambio-internacional",children:"Intercâmbio Internacional"}),n.jsx(l,{to:"/arquivos/regulamento-intercambios",children:"Regulamento de Intercâmbios"})]})]}),n.jsx(y,{children:n.jsx(l,{to:"/noticias",children:"Notícias"})}),n.jsxs(y,{onMouseEnter:()=>x("membros"),onMouseLeave:()=>x(""),onClick:()=>r("membrosMobile"),children:["Membros",n.jsxs(z,{$isOpen:s==="membros"||s==="membrosMobile",children:[n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"}),n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"}),n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})]})]}),n.jsx(pe,{to:"/filie-se",children:"FILIE-SE"})]}),n.jsxs(ue,{$isOpen:t,children:[n.jsxs(S,{children:[n.jsx(_,{onClick:()=>r("quemSomosMobile"),children:"Quem Somos"}),s==="quemSomosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/institucional",onClick:e,children:"Institucional"}),n.jsx(m,{to:"/estrutura",onClick:e,children:"Estrutura"}),n.jsx(m,{to:"/filiacao",onClick:e,children:"Filiação"}),n.jsx(m,{to:"/memoria",onClick:e,children:"Memória Institucional"})]})]}),n.jsxs(S,{children:[n.jsx(_,{onClick:()=>r("oQueFazemosMobile"),children:"O Que Fazemos"}),s==="oQueFazemosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/eixos",onClick:e,children:"Eixos de Atuação"}),n.jsx(m,{to:"/acoes",onClick:e,children:"Ações e Temáticas"}),n.jsx(m,{to:"/eventos",onClick:e,children:"Eventos e Workshops"})]})]}),n.jsxs(S,{children:[n.jsx(_,{onClick:()=>r("mobilidadeMobile"),children:"Intercâmbios"}),s==="mobilidadeMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/intercambio_nacional",onClick:e,children:"Intercâmbios Nacionais"}),n.jsx(m,{to:"/intercambio_internacional",onClick:e,children:"Intercâmbios Internacionais"}),n.jsx(m,{to:"/regulamento",onClick:e,children:"Regulamento de Intercâmbios"}),n.jsx(m,{to:"/outras-modalidades",onClick:e,children:"Outras Modalidades de Intercâmbio"}),n.jsx(m,{to:"/social-programs",onClick:e,children:"Social Programs"})]})]}),n.jsxs(S,{children:[n.jsx(_,{onClick:()=>r("midiasMobile"),children:"Mídias e Documentos"}),s==="midiasMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(m,{to:"/arquivos/ressonancia-poetica",onClick:e,children:"Ressonância Poética"}),n.jsx(m,{to:"/arquivos/informa-susi",onClick:e,children:"Informa SUSi"}),n.jsx(m,{to:"/arquivos/bms",onClick:e,children:"Brazilian Medical Students"}),n.jsx(m,{to:"/arquivos/relatorios",onClick:e,children:"Relatórios"}),n.jsx(m,{to:"/arquivos/notas-de-posicionamento",onClick:e,children:"Notas de Posicionamento"}),n.jsx(m,{to:"/arquivos/declaracoes-de-politica",onClick:e,children:"Declarações de Política"}),n.jsx(m,{to:"/arquivos/intercambio-nacional",onClick:e,children:"Intercâmbio Nacional"}),n.jsx(m,{to:"/arquivos/intercambio-internacional",onClick:e,children:"Intercâmbio Internacional"}),n.jsx(m,{to:"/arquivos/regulamento-intercambios",onClick:e,children:"Regulamento de Intercâmbios"})]})]}),n.jsx(_,{to:"/noticias",onClick:e,children:"Notícias"}),n.jsxs(S,{children:[n.jsx(_,{onClick:()=>r("membrosMobile"),children:"Membros"}),s==="membrosMobile"&&n.jsxs(n.Fragment,{children:[n.jsx(I,{onClick:e,children:n.jsx("a",{href:"https://solar.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"SOLAR"})}),n.jsx(I,{onClick:e,children:n.jsx("a",{href:"https://database.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"DATABASE"})}),n.jsx(I,{onClick:e,children:n.jsx("a",{href:"https://exchange.ifmsabrazil.org",target:"_blank",rel:"noopener noreferrer",children:"EXCHANGE"})})]})]}),n.jsx(_,{to:"/filie-se",onClick:e,children:"FILIE-SE"})]})]})};var X;const fe=()=>Un(Wn,{styles:Qn(X||(X=i([`
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700&display=swap");

      html,
      body,
      #root,
      #__next {
        margin: 0;
        padding: 0;
        height: 100%;
        width: 100%;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif !important;
        background-color: #f0f0f0;
        color: rgba(0, 0, 0, 0.87);
        font-weight: 400;
        font-size: 1rem;
        line-height: 1.5;
        letter-spacing: 0.00938em;
      }

      *,
      *::before,
      *::after {
        box-sizing: inherit;
      }

      a {
        text-decoration: none;
        color: inherit;
      }

      h1,
      h2 {
        margin: 0;
      }

      button {
        outline: none;
      }

      .carousel-container {
        max-width: 1200px;
        margin: 0 auto;
      }

      .carousel .slide {
        background: none;
      }

      /* CSS for BrazilMap component */
      .container {
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: flex-start;
        width: 100%;
        margin: 0;
        padding: 20px;
        box-sizing: border-box;
      }

      .map-container {
        flex: 1;
        min-width: 300px;
        max-width: 600px;
        margin: 0 20px; /* Medium margin on the left and right sides */
      }

      .legend-container {
        display: flex;
        flex-direction: column;
        margin-left: 20px;
      }

      .legend-item {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
      }

      .color-box {
        width: 20px;
        height: 20px;
        margin-right: 10px;
      }

      /* Media query for mobile view */
      @media (max-width: 768px) {
        .container {
          flex-direction: column;
          align-items: center;
        }
        .map-container {
          margin: 0; /* Remove margins on mobile */
        }
        .legend-container {
          flex-direction: row;
          flex-wrap: wrap;
          justify-content: center;
          margin-left: 0;
          margin-top: 20px; /* Space between map and legend */
        }
        .legend-item {
          margin: 5px; /* Adjust margin for horizontal layout */
        }
      }
    `])))});Yn.load({google:{families:["Poppins:300,400,500,700","sans-serif"]}});A.add(Dn.faTwitter,Hn.faInstagram,Nn.faMapMarkerAlt,Vn.faEnvelope,Gn.faPhone);const be=C("footer")({backgroundColor:"#00508C",color:"white",padding:"20px 0",textAlign:"center"}),P=C("div")({display:"flex",alignItems:"center",margin:"5px 0",justifyContent:"center","& svg":{marginRight:"10px"}}),je=C("div")({marginTop:"10px"}),J=C(Xn)({color:"white",margin:"0 10px",fontSize:"1.5rem",transition:"color 0.3s","&:hover":{color:"#FAC800"}}),ve=()=>n.jsx(be,{children:n.jsx(F,{maxWidth:"lg",children:n.jsxs(k,{container:!0,spacing:4,children:[n.jsxs(k,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Endereço"}),n.jsxs(P,{children:[n.jsx(w,{icon:"map-marker-alt"}),n.jsx(f,{variant:"body1",children:"Avenida Paulista nº 1765 - 7º Andar"})]}),n.jsx(f,{variant:"body1",children:"Boa Vista, São Paulo/SP - Brasil"})]}),n.jsxs(k,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Contato"}),n.jsxs(P,{children:[n.jsx(w,{icon:"envelope"}),n.jsx(f,{variant:"body1",children:"atendimento@ifmsabrazil.org"})]}),n.jsxs(P,{children:[n.jsx(w,{icon:"phone"}),n.jsx(f,{variant:"body1",children:"Tel: + 55 11 3170-3251"})]})]}),n.jsxs(k,{item:!0,xs:12,md:4,children:[n.jsx(f,{variant:"h6",gutterBottom:!0,children:"Siga-nos"}),n.jsxs(je,{children:[n.jsx(J,{href:"https://twitter.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(w,{icon:["fab","twitter"]})}),n.jsx(J,{href:"https://instagram.com/ifmsabrazil",target:"_blank",rel:"noopener noreferrer",children:n.jsx(w,{icon:["fab","instagram"]})})]})]})]})})}),_e=C(F)({display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100vh"}),we=C(f)({marginTop:"16px",color:"#00508C"}),Bn=()=>n.jsxs(_e,{children:[n.jsx(Jn,{}),n.jsx(we,{variant:"h6",children:"Carregando..."})]});var K,Z,nn,en,tn;const ye=On(K||(K=i([`
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
`]))),ke=On(Z||(Z=i([`
  from {
    opacity: 1;
    transform: scale(1);
  }
  to {
    opacity: 0;
    transform: scale(0.8);
  }
`]))),Ce=a.div(nn||(nn=i([`
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #00508c;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  display: flex;
  justify-content: center;
  align-items: center;
  color: white;
  cursor: pointer;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  transition: all 0.2s ease-in-out;
  z-index: 1000;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 46px;
    height: 46px;
  }
`]))),Ee=a.div(en||(en=i([`
  position: fixed;
  bottom: 80px;
  right: 20px;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 1000;
  transition: all 0.2s ease-in-out;
  animation: `,` 0.2s forwards;

  @media (max-width: 768px) {
    bottom: 76px;
    right: 16px;
  }
`])),t=>t.isOpen?ye:ke),on=a.a(tn||(tn=i([`
  color: #00508c;
  text-decoration: none;
  display: flex;
  align-items: center;
  padding: 8px 0;
  width: 100%;
  transition: all 0.2s ease-in-out;

  &:hover {
    color: #003366;
  }

  svg {
    margin-right: 10px;
  }
`]))),Oe=()=>{const[t,o]=c.useState(!1),s=()=>{o(!t)};return n.jsxs(n.Fragment,{children:[n.jsx(Ce,{onClick:s,children:t?n.jsx(oe,{size:24}):n.jsx(L,{size:24})}),t&&n.jsxs(Ee,{isOpen:t,children:[n.jsxs(on,{href:"mailto:atendimento@ifmsabrazil.org",children:[n.jsx(L,{size:20}),"atendimento@ifmsabrazil.org"]}),n.jsxs(on,{href:"https://instagram.com/ifmsabrazil",target:"_blank",children:[n.jsx(ie,{size:20}),"@ifmsabrazil"]})]})]})};var rn,an,sn,ln,cn,dn;const ze=a.section(rn||(rn=i([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #FFFFFF;
  text-align: center;
`]))),Se=a.h2(an||(an=i([`
  font-family: 'Poppins', sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Me=a.div(sn||(sn=i([`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
`]))),Ie=a.div(ln||(ln=i([`
  flex: 1 1 30%;
  max-width: 30%;
  display: flex;
  justify-content: center;

  @media (max-width: 991px) {
    flex: 1 1 45%;
    max-width: 45%;
  }

  @media (max-width: 600px) {
    flex: 1 1 100%;
    max-width: 100%;
  }
`]))),Pe=a.div(cn||(cn=i([`
  position: relative;
  height: auto;
  font-family: 'Poppins', sans-serif;
  color: rgba(255, 255, 255, 1);
  text-align: center;
  background-color: `,`;
  flex-grow: 1;
  width: 100%;
  align-self: stretch;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
`])),t=>t.bgColor),Ae=a.div(dn||(dn=i([`
  font-size: 24px;
`])));function Fe(){const t=[{id:1,bgColor:"rgba(0, 80, 140, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Em 26 Estados"}),n.jsx("br",{}),n.jsx("strong",{children:"+ Distrito Federal"})]})},{id:2,bgColor:"rgba(250, 200, 0, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Temos +11000"}),n.jsx("br",{}),n.jsx("strong",{children:"membros filiados"})]})},{id:3,bgColor:"rgba(0, 150, 60, 1)",text:n.jsxs(n.Fragment,{children:[n.jsx("strong",{children:"Presentes em +220"}),n.jsx("br",{}),n.jsx("strong",{children:"escolas médicas"})]})}];return n.jsxs(ze,{children:[n.jsx(Se,{children:"Nossa abrangência"}),n.jsx(Me,{children:t.map(o=>n.jsx(Ie,{children:n.jsx(Pe,{bgColor:o.bgColor,children:n.jsx(Ae,{children:o.text})})},o.id))})]})}var mn,xn,pn,hn,un;A.add(Mn.faBook,In.faGraduationCap,Pn.faHandsHelping,An.faHeartbeat,Fn.faHospital,Ln.faUniversity,Tn.faSearch);const Le=a.section(mn||(mn=i([`
  display: flex;
  flex-direction: column;
  position: relative;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
  text-align: center;
`]))),Te=a.h2(xn||(xn=i([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Be=a.div(pn||(pn=i([`
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 20px;
  justify-content: center;

  @media (max-width: 991px) {
    grid-template-columns: repeat(2, 1fr);
  }

  @media (max-width: 600px) {
    grid-template-columns: repeat(2, 1fr);
    & > :nth-child(5) {
      grid-column: span 2;
    }
  }
`]))),$e=a.div(hn||(hn=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  background-color: `,`;
  color: `,`;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s ease;
  font-family: "Poppins", sans-serif;
  text-align: center;
  border: `,`;

  &:hover {
    transform: translateY(-10px);
  }
`])),t=>t.bgColor,t=>t.color||"rgba(255, 255, 255, 1)",t=>t.border||"none"),Re=a.div(un||(un=i([`
  font-size: 18px;
  margin-top: 10px;
`])));function qe(){const t=[{id:1,bgColor:"rgba(182, 120, 38, 1)",text:"Representatividade estudantil",icon:In.faGraduationCap},{id:2,bgColor:"rgba(0, 0, 0, 1)",text:"Capacity Building",icon:Mn.faBook},{id:3,bgColor:"#FFFFFF",text:"Educação Médica",icon:Fn.faHospital,color:"#000",border:"2px solid #000"},{id:4,bgColor:"rgba(220, 0, 0, 1)",text:"Promoção de Saúde",icon:An.faHeartbeat},{id:5,bgColor:"rgba(0, 150, 60, 1)",text:"Humanização",icon:Pn.faHandsHelping},{id:6,bgColor:"rgba(0, 80, 140, 1)",text:"Mobilidade Estudantil",icon:Ln.faUniversity},{id:7,bgColor:"rgba(128, 128, 128, 1)",text:"Pesquisa e Extensão",icon:Tn.faSearch}];return n.jsxs(Le,{children:[n.jsx(Te,{children:"Nossos eixos de atuação"}),n.jsx(Be,{children:t.map(o=>n.jsxs($e,{bgColor:o.bgColor,color:o.color,border:o.border,children:[n.jsx(w,{icon:o.icon,size:"3x"}),n.jsx(Re,{children:o.text})]},o.id))})]})}var gn,fn;const De=a(Kn)(gn||(gn=i([`
  display: flex;
  flex-direction: column;
  margin: 16px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  transition: transform 0.3s;
  border-radius: 10px;

  &:hover {
    transform: translateY(-5px);
  }

  @media (min-width: 600px) {
    flex-direction: row;
  }
`]))),He=a(Zn)(fn||(fn=i([`
  width: 100%;
  height: auto;

  @media (min-width: 600px) {
    width: 160px !important;
    height: auto;
    object-fit: cover;
    margin-left: auto;
  }
`]))),Ne=t=>{let{post:o}=t;return n.jsxs(De,{children:[n.jsxs(ne,{style:{flex:1},children:[n.jsx(f,{component:"h2",variant:"h5",gutterBottom:!0,children:o.title}),n.jsx(f,{variant:"subtitle1",color:"text.secondary",children:o.author}),n.jsx(f,{variant:"subtitle2",color:"text.secondary",gutterBottom:!0,children:o.date?new Date(o.date).toLocaleDateString():""}),n.jsx(f,{variant:"body1",paragraph:!0,children:o.summary})]}),n.jsx(He,{component:"img",image:o.imageLink,alt:"Blog image"})]})},Ve={ç:"c",Ç:"C",á:"a",Á:"A",é:"e",É:"E",í:"i",Í:"I",ó:"o",Ó:"O",ú:"u",Ú:"U",à:"a",À:"A",ã:"a",Ã:"A",õ:"o",Õ:"O"},Ge=t=>t.split("").map(o=>Ve[o]||o).join(""),Ue=t=>Ge(t).toLowerCase().replace(/[^a-z0-9]+/g,"-");var bn,jn;const Qe=a.section(bn||(bn=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #ffffff;
`]))),We=a.h2(jn||(jn=i([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 20px;
`]))),Ye=t=>{let{posts:o,loading:s}=t;if(s)return n.jsx(Bn,{});const x=d=>d.sort((p,b)=>b["dia-mes-ano"]-p["dia-mes-ano"]),r=function(d){let p=arguments.length>1&&arguments[1]!==void 0?arguments[1]:4;const b=x(d),v=b.filter(j=>j["forcar-pagina-inicial"]);if(v.length>=p)return v;const g=b.filter(j=>!j["forcar-pagina-inicial"]);return v.concat(g.slice(0,p-v.length))}(o);return n.jsxs(Qe,{children:[n.jsx(We,{children:"Últimas Notícias"}),n.jsx(F,{maxWidth:"lg",children:n.jsx(k,{container:!0,spacing:4,children:r.map((d,p)=>n.jsx(k,{item:!0,xs:12,sm:6,children:n.jsx(l,{to:"/arquivo/".concat(d.id,"/").concat(Ue(d.title)),children:n.jsx(Ne,{post:d})})},p))})})]})},Xe="/assets/background-image-YkmHsWZG.webp";var vn,_n,wn,yn,kn,Cn;const Je=c.lazy(()=>u(()=>import("./Alert-Djlsjerp.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]))),Ke=a.div(vn||(vn=i([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  overflow: hidden;
`]))),Ze=a.div(_n||(_n=i([`
  width: 100%;
  height: 100vh;
  background-image: url(`,`);
  background-size: cover;
  background-position: center;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
  text-align: center;
  padding: 20px;
  background-color: rgba(0, 0, 0, 0.5);
`])),Xe),nt=a.h1(wn||(wn=i([`
  font-size: 3rem;
  font-weight: 700;
  padding: 0 20px;

  @media (max-width: 768px) {
    font-size: 2rem;
  }
`]))),et=a.button(yn||(yn=i([`
  margin-top: 20px;
  padding: 12px 24px;
  font-size: 1rem;
  font-weight: bold;
  color: #00508c;
  background-color: #fac800;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: translateY(-3px);
    background-color: #e6b800;
    color: #004080;
  }
`]))),tt=a.button(kn||(kn=i([`
  position: fixed;
  bottom: 20px;
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: white;
  border: none;
  cursor: pointer;
  display: `,`;
  justify-content: center;
  align-items: center;
  transition: all 0.3s ease-in-out;

  &:hover {
    transform: scale(1.1);
  }

  @media (max-width: 768px) {
    width: 40px;
    height: 40px;
  }

  svg {
    width: 24px;
    height: 24px;
    fill: #00508c;
  }
`])),t=>{let{show:o}=t;return o?"flex":"none"}),ot=a.div(Cn||(Cn=i([`
  width: 100%;
  padding: 60px 20px;
  background-color: white;
  text-align: center;
  color: #333;

  h2 {
    font-size: 2rem;
    margin-bottom: 20px;
  }

  p {
    max-width: 800px;
    margin: 0 auto;
    line-height: 1.6;
  }
`]))),it=()=>{const[t,o]=c.useState([]),[s,x]=c.useState(null),[e,r]=c.useState(!0),[d,p]=c.useState(!0),b="https://api.ifmsabrazil.org/api/blogs/recent";c.useEffect(()=>{(async()=>{try{const j=await te.get(b),{recentBlogs:M,alert:O}=j.data;o(M),O&&O.toggleDate&&re(new Date,{start:T(O.dateStart),end:T(O.dateEnd)})&&x(O)}catch(j){console.error("Error fetching posts:",j)}finally{r(!1)}})()},[]);const v=()=>{const E=window.scrollY,M=window.innerHeight*.7;E<M?p(!0):p(!1)},g=()=>{window.scrollTo({top:window.innerHeight,behavior:"smooth"})};return c.useEffect(()=>(window.addEventListener("scroll",v),()=>{window.removeEventListener("scroll",v)}),[]),n.jsxs(Ke,{children:[s&&n.jsx(Je,{toggleMessage:s.toggleMessage,message:s.message,toggleButton:s.toggleButton,buttonText:s.buttonText,buttonUrl:s.buttonUrl,title:s.title}),n.jsxs(Ze,{children:[n.jsx(nt,{children:"Estudantes de medicina que fazem a diferença"}),n.jsx(et,{children:"Faça parte"}),n.jsx(tt,{show:d,onClick:g,children:n.jsx("svg",{viewBox:"0 0 24 24",children:n.jsx("path",{d:"M12 16.5l-7-7 1.41-1.41L12 13.67l5.59-5.58L19 9.5l-7 7z"})})})]}),n.jsxs(ot,{children:[n.jsx("h2",{children:"Breve Introdução"}),n.jsx("p",{children:"Fundada em 1991 como primeira associação da América Latina vinculada à International Federation of Medical Students’ Association (IFMSA), a IFMSA Brazil interliga estudantes de medicina de todo o país para fazer a diferença na sociedade e na formação médica."})]}),n.jsx(Fe,{}),n.jsx(qe,{}),n.jsx(Ye,{posts:t,loading:e}),n.jsx(Oe,{})]})},En=c.lazy(()=>u(()=>import("./MarkdownPage-B7NvwP4R.js"),__vite__mapDeps([22,1,2,23,19,24,15,16,17,5,6,18,7,8,10,11,9,3,4,12,13,14,20,21,25]))),rt=c.lazy(()=>u(()=>import("./GeradorLink-BphYFTKn.js"),__vite__mapDeps([26,1,2,15,16,17,5,6,18,7,8]))),at=c.lazy(()=>u(()=>import("./Arquivos-DMc1UhkL.js"),__vite__mapDeps([27,1,2,3,4,5,6,19,28,12,13,15,16,17,18,7,8,10,11,9,14,20,21]))),st=c.lazy(()=>u(()=>import("./Estrutura-DIhAc2iX.js"),__vite__mapDeps([29,1,2,19,30,31,15,16,17,5,6,18,7,8,32,13,33,34,35,36,23,24,25,9,10,11,3,4,12,14,20,21]))),lt=c.lazy(()=>u(()=>import("./Filiacao--2vDal1g.js"),__vite__mapDeps([37,1,2,3,4,5,6,20,15,16,17,18,7,8,19,38,36,23,24,25,9,10,11,12,13,14,21]))),ct=c.lazy(()=>u(()=>import("./NotFound-CnTVFUZ8.js"),__vite__mapDeps([39,1,2,3,4,5,6,9,7,8,10,11,12,13,14,15,16,17,18,19,20,21]))),dt=c.lazy(()=>u(()=>import("./Noticias-D9mPJ9VA.js"),__vite__mapDeps([40,1,2,3,4,5,6,9,7,8,10,11,28,12,13,15,16,17,18,19,14,20,21]))),mt=c.lazy(()=>u(()=>import("./Institucional-BTzTCIzJ.js"),__vite__mapDeps([41,1,2,36,23,24,15,16,17,5,6,18,7,8,25,9,10,11,3,4,12,13,14,19,20,21]))),xt=c.lazy(()=>u(()=>import("./AcoesETematicas-tV0Ad2dM.js"),__vite__mapDeps([42,1,2,36,23,24,15,16,17,5,6,18,7,8,25,9,10,11,3,4,12,13,14,19,20,21]))),pt=c.lazy(()=>u(()=>import("./SocialPrograms-Dzaz0vnC.js"),__vite__mapDeps([43,1,2,36,23,24,15,16,17,5,6,18,7,8,25,9,10,11,3,4,12,13,14,19,20,21]))),ht=c.lazy(()=>u(()=>import("./Eixos-Cpb0LW8T.js"),__vite__mapDeps([44,1,2,36,23,24,15,16,17,5,6,18,7,8,25,9,10,11,3,4,12,13,14,19,20,21]))),ut=c.lazy(()=>u(()=>import("./Eventos-lljknhGy.js"),__vite__mapDeps([45,1,2,36,23,24,15,16,17,5,6,18,7,8,25,9,10,11,3,4,12,13,14,19,20,21]))),gt=c.lazy(()=>u(()=>import("./Regulamento-uE1MojF7.js"),__vite__mapDeps([46,1,2,36,23,24,15,16,17,5,6,18,7,8,25]))),ft=c.lazy(()=>u(()=>import("./IntercambioNacional-cd8j8lRw.js"),__vite__mapDeps([47,1,2,36,23,24,15,16,17,5,6,18,7,8,25]))),bt=()=>n.jsxs(qn,{children:[n.jsx(fe,{}),n.jsx(ee,{}),n.jsx(ge,{}),n.jsx(c.Suspense,{fallback:n.jsx(Bn,{}),children:n.jsxs(ae,{children:[n.jsx(h,{path:"/",element:n.jsx(it,{})}),n.jsx(h,{path:"/arquivo/:id/:title",element:n.jsx(En,{needsExternal:!0})}),n.jsx(h,{path:"/gerarlink",element:n.jsx(rt,{})}),n.jsx(h,{path:"/estrutura",element:n.jsx(st,{})}),n.jsx(h,{path:"/filiacao",element:n.jsx(lt,{})}),n.jsx(h,{path:"/noticias",element:n.jsx(dt,{})}),n.jsx(h,{path:"/institucional",element:n.jsx(mt,{})}),n.jsx(h,{path:"/acoes",element:n.jsx(xt,{})}),n.jsx(h,{path:"/arquivos/:type",element:n.jsx(at,{})}),n.jsx(h,{path:"/social-programs",element:n.jsx(pt,{})}),n.jsx(h,{path:"/eixos",element:n.jsx(ht,{})}),n.jsx(h,{path:"/eventos",element:n.jsx(ut,{})}),n.jsx(h,{path:"/regulamento",element:n.jsx(gt,{})}),n.jsx(h,{path:"/intercambio_nacional",element:n.jsx(ft,{})}),n.jsx(h,{path:"/tutorial",element:n.jsx(En,{needsExternal:!1,filepath:"/markdown/pagina.md"})}),n.jsx(h,{path:"*",element:n.jsx(ct,{})})," "]})}),n.jsx(ve,{})]}),jt=document.getElementById("root"),vt=Rn(jt);vt.render(n.jsx($n.StrictMode,{children:n.jsx(bt,{})}));export{Bn as L,i as _,u as a,Ue as g};
