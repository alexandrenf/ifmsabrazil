import{_ as o}from"./index-B0Y-DpxM.js";import{j as t}from"./react-CLPtFgDq.js";import{p as n}from"./styled-components-BY_vc4YD.js";import{L as a}from"./react-router-dom-Am9psY4u.js";import"./react-dom-DvAKqnPy.js";import"./@babel-f5lBRPU2.js";import"./scheduler-CzFDRTuY.js";import"./@fortawesome-B6QlLdFu.js";import"./prop-types-1yzuAbYU.js";import"./webfontloader-DM8E560Z.js";import"./@mui-B86xCNSa.js";import"./clsx-B-dksMZM.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./react-transition-group-CLuBo2_z.js";import"./react-is-DcfIKM1A.js";import"./axios-B4uVmeYG.js";import"./react-icons-CrkDh4zl.js";import"./react-router-BzRFIFMZ.js";import"./@remix-run-YI_hLLil.js";import"./tslib-wbdO-F7s.js";var e,r,i,m,p;const s=n.div(e||(e=o([`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  text-align: center;
  background-color: #f8f8f8;
  color: #333;
  padding: 20px;
`]))),c=n.h1(r||(r=o([`
  font-size: 4rem;
  margin-bottom: 16px;
`]))),l=n.h2(i||(i=o([`
  font-size: 2rem;
  margin-bottom: 16px;
`]))),d=n.p(m||(m=o([`
  font-size: 1.2rem;
  margin-bottom: 24px;
`]))),x=n(a)(p||(p=o([`
  font-size: 1.2rem;
  color: #00508c;
  text-decoration: none;
  &:hover {
    text-decoration: underline;
  }
`]))),P=()=>t.jsxs(s,{children:[t.jsx(c,{children:"404"}),t.jsx(l,{children:"Page Not Found"}),t.jsx(d,{children:"Sorry, the page you are looking for does not exist."}),t.jsx(x,{to:"/",children:"Go to Home"})]});export{P as default};
