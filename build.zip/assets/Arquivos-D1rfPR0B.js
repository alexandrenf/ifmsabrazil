const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/Revista-C_B6Usm8.js","assets/react-DaPl5ws4.js","assets/@babel-CNkBngnk.js","assets/MarkdownContent-Bk-obxsC.js","assets/markdown-to-jsx-CXBEPAoT.js","assets/prismjs-DEnDlMkx.js","assets/@mui-D3p2DSY1.js","assets/clsx-B-dksMZM.js","assets/react-is-DcfIKM1A.js","assets/@emotion-Clztb9Oy.js","assets/hoist-non-react-statics-DQogQWOa.js","assets/react-transition-group-cLDJx4Bm.js","assets/react-dom-CWF6clnO.js","assets/scheduler-CzFDRTuY.js","assets/codeStyles-vPv1o2UF.css","assets/Ressonancia-DY9YuyjY.js","assets/Declaracoes-DhxT2pWe.js","assets/Notas-DfvcpL3F.js","assets/NotFound-DHFLx8nU.js","assets/index-BATduljy.js","assets/react-router-dom-BFBG7k2k.js","assets/react-router-B_WJkAv4.js","assets/@remix-run-B-RBrVrq.js","assets/styled-components-BD7m8TR7.js","assets/tslib-wbdO-F7s.js","assets/@fortawesome-BOOXKGIM.js","assets/prop-types-15ULSoSZ.js","assets/axios-B4uVmeYG.js","assets/js-cookie-Cz0CWeBA.js","assets/react-icons-BQxfTaxZ.js","assets/date-fns-X50TK9oK.js","assets/index-DkNmx6u9.css"])))=>i.map(i=>d[i]);
import{_ as l,L as z,a as m}from"./index-BATduljy.js";import{r as o,j as e}from"./react-DaPl5ws4.js";import{p as c}from"./styled-components-BD7m8TR7.js";import{a as F}from"./axios-B4uVmeYG.js";import{B as V}from"./BlogPostListItem-BhqIjVzk.js";import{f as N}from"./react-router-B_WJkAv4.js";import{h as M,F as G,i as Z,S as U,O as W,M as H,j as J,L as K,k as Q,B as p,l as w,D as X}from"./@mui-D3p2DSY1.js";import"./react-dom-CWF6clnO.js";import"./@babel-CNkBngnk.js";import"./scheduler-CzFDRTuY.js";import"./react-router-dom-BFBG7k2k.js";import"./@remix-run-B-RBrVrq.js";import"./@fortawesome-BOOXKGIM.js";import"./prop-types-15ULSoSZ.js";import"./@emotion-Clztb9Oy.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./js-cookie-Cz0CWeBA.js";import"./react-icons-BQxfTaxZ.js";import"./date-fns-X50TK9oK.js";import"./tslib-wbdO-F7s.js";import"./clsx-B-dksMZM.js";import"./react-is-DcfIKM1A.js";import"./react-transition-group-cLDJx4Bm.js";var v,_,g,A,y,D;const Y=o.lazy(()=>m(()=>import("./Revista-C_B6Usm8.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),$=o.lazy(()=>m(()=>import("./Ressonancia-DY9YuyjY.js"),__vite__mapDeps([15,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),ee=o.lazy(()=>m(()=>import("./Declaracoes-DhxT2pWe.js"),__vite__mapDeps([16,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),te=o.lazy(()=>m(()=>import("./Notas-DfvcpL3F.js"),__vite__mapDeps([17,1,2,3,4,5,6,7,8,9,10,11,12,13,14]))),re=o.lazy(()=>m(()=>import("./NotFound-DHFLx8nU.js"),__vite__mapDeps([18,19,1,2,12,13,20,21,22,23,24,9,10,25,26,6,7,8,11,27,28,29,30,31]))),oe=[{href:"notas",label:"Arquivos de Nota de Posicionamento",file:"1",ref:"notas-de-posicionamento"},{href:"susi",label:"Informa SUSi",file:"",ref:"informa-susi"},{href:"rp",label:"Edições da Ressonância Poética",file:"3",ref:"ressonancia-poetica"},{href:"bms",label:"Edições de Brazilian Medical Students",file:"4",ref:"bms"},{href:"relatorios",label:"Relatórios",file:"",ref:"relatorios"},{href:"dps",label:"Arquivos de Declarações de Política",file:"6",ref:"declaracoes-de-politica"},{href:"intercambio_nac",label:"Intercâmbio Nacional",file:"",ref:"intercambio-nacional"},{href:"intercambio_inter",label:"Intercâmbio Internacional",file:"",ref:"intercambio-internacional"},{href:"regulamento",label:"Regulamento de Intercâmbios",file:"",ref:"regulamento-intercambios"}],ie=f=>{switch(f){case"1":return e.jsx(te,{});case"3":return e.jsx($,{});case"4":return e.jsx(Y,{});case"6":return e.jsx(ee,{});default:return null}},ne=c.section(v||(v=l([`
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  padding: 30px 20px;
  background-color: #f0f2f5;
`]))),se=c.h2(_||(_=l([`
  font-family: "Poppins", sans-serif;
  font-size: 2rem;
  color: #333;
  text-align: center;
  margin-bottom: 30px;
`]))),ae=c.div(g||(g=l([`
  width: 100%;
  max-width: 1200px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
`]))),le=c(w)(A||(A=l([`
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
`]))),ce=c(X)(y||(y=l([`
  margin: 0 20px;
`]))),de=c(w)(D||(D=l([`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  width: 100%;
  max-width: 1200px;
`]))),Pe=()=>{const{type:f}=N(),[x,E]=o.useState([]),[q,S]=o.useState(!0),[b,u]=o.useState("dateDesc"),[h,L]=o.useState(""),[d,O]=o.useState([]),[I,T]=o.useState([]),s=oe.find(t=>t.ref===f);if(console.log(s),!s)return e.jsx(re,{});const j="https://api.ifmsabrazil.org/api/arquivos/".concat(s.href),C=s?s.label:"Publicações";o.useEffect(()=>{(async()=>{try{const i=(await F.get(j)).data;if(!Array.isArray(i))throw new Error("Arquivos data is not an array");E(i)}catch(r){console.error("Error fetching arquivos:",r)}finally{S(!1)}})()},[j]),o.useEffect(()=>{T(k(x))},[x,b,h,d]);const P=(t,r)=>{const i=[...t];return r==="dateAsc"?i.sort((n,a)=>new Date(n.date)-new Date(a.date)):r==="dateDesc"?i.sort((n,a)=>new Date(a.date)-new Date(n.date)):r==="titleAsc"?i.sort((n,a)=>n.title.localeCompare(a.title)):r==="titleDesc"&&i.sort((n,a)=>a.title.localeCompare(n.title)),i},R=t=>t.filter(r=>{const i=r.title.toLowerCase().includes(h.toLowerCase()),n=d.length===0||d.includes(r.author);return i&&n}),k=t=>{const r=P(t,b);return R(r)};if(q)return e.jsx(z,{});const B=[...new Set(x.map(t=>t.author))];return e.jsxs(e.Fragment,{children:[ie(s==null?void 0:s.file),e.jsxs(ne,{children:[e.jsx(se,{children:C}),e.jsxs(de,{children:[e.jsx(M,{label:"Buscar por Título",variant:"outlined",value:h,onChange:t=>L(t.target.value),style:{marginRight:"20px",flexGrow:1}}),e.jsxs(G,{variant:"outlined",style:{minWidth:200},children:[e.jsx(Z,{children:"Filtrar por Autor"}),e.jsx(U,{multiple:!0,value:d,onChange:t=>O(t.target.value),input:e.jsx(W,{label:"Filtrar por Autor"}),renderValue:t=>t.join(", "),children:B.map(t=>e.jsxs(H,{value:t,children:[e.jsx(J,{checked:d.indexOf(t)>-1}),e.jsx(K,{primary:t})]},t))})]})]}),e.jsx(le,{children:e.jsxs(Q,{variant:"outlined",color:"primary",children:[e.jsx(p,{onClick:()=>u("dateDesc"),children:"Data (mais recentes)"}),e.jsx(p,{onClick:()=>u("dateAsc"),children:"Data (mais antigas)"}),e.jsx(ce,{orientation:"vertical",flexItem:!0}),e.jsx(p,{onClick:()=>u("titleAsc"),children:"Título (A-Z)"}),e.jsx(p,{onClick:()=>u("titleDesc"),children:"Título (Z-A)"})]})}),e.jsx(ae,{children:I.map((t,r)=>e.jsx("a",{href:t.fileLink,style:{textDecoration:"none"},target:"_blank",rel:"noopener noreferrer",children:e.jsx(V,{post:t})},r))})]})]})};export{Pe as default};
