import{j as o}from"./react-CLPtFgDq.js";import{M as e}from"./MarkdownContent-BNKm4Bhr.js";import{s as t,C as a,T as r}from"./@mui-B86xCNSa.js";import"./@babel-f5lBRPU2.js";import"./markdown-to-jsx-hEv6XCia.js";import"./prismjs-D-bn_D2K.js";/* empty css                   */import"./clsx-B-dksMZM.js";import"./@emotion-B2RCLeMm.js";import"./hoist-non-react-statics-DQogQWOa.js";import"./stylis-FDnFs_-n.js";import"./react-transition-group-CLuBo2_z.js";import"./react-dom-DvAKqnPy.js";import"./scheduler-CzFDRTuY.js";import"./react-is-DcfIKM1A.js";const n=t(a)({padding:"24px",backgroundColor:"#FFFFFF",color:"#333"}),i=t(r)({color:"#00508C",marginBottom:"16px",fontWeight:"bold",textAlign:"center"}),k=()=>o.jsxs(n,{children:[o.jsx(i,{variant:"h4",children:"Notas de Posicionamento"}),o.jsx(e,{content:`

Nota Oficial é a ferramenta pela qual a IFMSA Brazil pode se expressar à sociedade a respeito de acontecimentos específicos, não contemplados total ou parcialmente pelas Declarações de Políticas vigentes, e cuja urgência demandada não permite discussão ampla para deliberação de posicionamento em plenária de Assembléia Geral.


`})]});export{k as default};
